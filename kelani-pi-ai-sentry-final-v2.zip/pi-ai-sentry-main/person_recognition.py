#!/usr/bin/env python3
"""Compatibility layer around the durable identity manager.

The old repository stored a single flattened grayscale face image per person.
This module keeps the public functions used by the rest of the application but
stores observations/samples in SQLite through identity_manager instead.
"""
import datetime
import json
import os
import sqlite3
import uuid
import cv2
import numpy as np

from config import DB_PATH
from identity_manager import (
    init_identity_db, create_unknown_profile, record_observation,
    get_profile, associate_name_with_person, request_identity_question,
    answer_identity_question, get_recent_person_candidates, pending_identity_question,
    match_sample, cache_name_mention, extract_name_candidates,
)


def init_person_db():
    init_identity_db()
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS persons (
            id TEXT PRIMARY KEY, name TEXT, first_seen TEXT, last_seen TEXT,
            face_encoding TEXT, voice_profile TEXT, mannerisms TEXT,
            total_interactions INTEGER DEFAULT 0)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS person_conversations (
            id TEXT PRIMARY KEY, person_id TEXT, timestamp TEXT,
            message TEXT, role TEXT, FOREIGN KEY(person_id) REFERENCES persons(id))""")


def extract_face_encoding(frame, face_box=None):
    """Fallback OpenCV descriptor used only when Qengineering is unavailable."""
    try:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        if face_box is None:
            cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
            faces = cascade.detectMultiScale(gray, 1.1, 4, minSize=(48, 48))
            if len(faces) == 0:
                return None
            x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
        else:
            x, y, w, h = face_box
        crop = gray[max(0,y):y+h, max(0,x):x+w]
        if crop.size == 0:
            return None
        crop = cv2.resize(crop, (64, 64), interpolation=cv2.INTER_AREA)
        # Normalize lighting before creating the fallback descriptor.
        crop = cv2.equalizeHist(crop)
        return (crop.astype(np.float32).reshape(-1) / 255.0).tolist()
    except Exception as e:
        print(f"Face descriptor error: {e}")
        return None


def extract_voice_features(audio_file):
    try:
        import wave
        wf = wave.open(audio_file, 'rb')
        frames = wf.readframes(wf.getnframes())
        rate = wf.getframerate()
        wf.close()
        data = np.frombuffer(frames, dtype=np.int16).astype(np.float32)
        if data.size == 0:
            return None
        centered = data - np.mean(data)
        crossings = np.sum(np.diff(np.signbit(centered)) != 0)
        duration = data.size / max(rate, 1)
        rms = float(np.sqrt(np.mean(centered ** 2)))
        return {
            'mean_amplitude': float(np.mean(np.abs(centered))),
            'std_amplitude': float(np.std(centered)),
            'max_amplitude': float(np.max(np.abs(centered))),
            'zero_crossings': float(crossings),
            'duration': float(duration),
            'rms': rms,
            'sample_rate': int(rate),
        }
    except Exception as e:
        print(f"Voice feature extraction error: {e}")
        return None


def compare_face_encodings(enc1, enc2, threshold=0.30):
    if enc1 is None or enc2 is None:
        return False
    a, b = np.asarray(enc1, dtype=np.float32), np.asarray(enc2, dtype=np.float32)
    if a.shape != b.shape:
        return False
    return float(np.linalg.norm(a-b) / max(np.sqrt(a.size), 1.0)) < threshold


def compare_voice_features(voice1, voice2, threshold=0.25):
    if not voice1 or not voice2:
        return False
    keys = ('mean_amplitude', 'std_amplitude', 'max_amplitude', 'zero_crossings', 'duration', 'rms')
    try:
        a = np.array([float(voice1.get(k, 0.0)) for k in keys], dtype=float)
        b = np.array([float(voice2.get(k, 0.0)) for k in keys], dtype=float)
        scale = np.maximum(np.maximum(np.abs(a), np.abs(b)), 1e-6)
        return float(np.mean(np.abs(a-b)/scale)) < threshold
    except Exception:
        return False


def register_person(name=None, face_encoding=None, voice_profile=None):
    modality = 'face' if face_encoding is not None else 'voice'
    sample = face_encoding if face_encoding is not None else voice_profile
    person_id = create_unknown_profile(modality, sample, 0.65, 'manual_or_legacy_register')
    now = datetime.datetime.now().isoformat()
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("INSERT OR REPLACE INTO persons(id,name,first_seen,last_seen,face_encoding,voice_profile,total_interactions) VALUES(?,?,?,?,?,?,0)",
                     (person_id, name, now, now, json.dumps(face_encoding) if face_encoding is not None else None,
                      json.dumps(voice_profile) if voice_profile is not None else None))
    if name:
        associate_name_with_person(person_id, name, 'manual_registration', 1.0, True)
    return person_id


def identify_person(face_encoding, voice_features=None):
    if face_encoding is None:
        return (None, None)
    arr = np.asarray(face_encoding, dtype=float)
    # Qengineering ArcFace descriptors are normally compact float vectors.
    # Use its cosine-similarity convention when the descriptor is not the old
    # 64x64 OpenCV fallback.
    if arr.size <= 2048:
        def cosine_distance(a, b):
            a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
            if a.shape != b.shape: raise ValueError('shape mismatch')
            denom = np.linalg.norm(a) * np.linalg.norm(b)
            if denom <= 1e-12: return 1.0
            return float(1.0 - (np.dot(a, b) / denom))
        person_id, confidence = match_sample('face', face_encoding, cosine_distance, 0.50)
    else:
        person_id, confidence = match_sample('face', face_encoding,
            lambda a,b: float(np.linalg.norm(np.asarray(a,dtype=float)-np.asarray(b,dtype=float)) / max(np.sqrt(len(a)),1.0)),
            0.30)
    if person_id:
        record_observation(person_id, 'face', confidence, {'backend':'qengineering_arcface' if arr.size <= 2048 else 'opencv_fallback'},
                           'face_recognition', face_encoding, confidence)
    return (person_id, confidence)

def identify_voice(voice_features):
    """Match either a Vosk speaker vector or the lightweight audio-feature fallback."""
    if voice_features is None:
        return (None, None)
    # Vosk speaker model returns a numeric x-vector. Prefer cosine similarity.
    if isinstance(voice_features, (list, tuple, np.ndarray)):
        vec = np.asarray(voice_features, dtype=float).reshape(-1)
        if vec.size:
            def cosine_distance(a, b):
                a = np.asarray(a, dtype=float).reshape(-1)
                b = np.asarray(b, dtype=float).reshape(-1)
                if a.shape != b.shape or not a.size:
                    raise ValueError('speaker-vector shape mismatch')
                denom = np.linalg.norm(a) * np.linalg.norm(b)
                return 1.0 if denom <= 1e-12 else float(1.0 - np.dot(a, b) / denom)
            person_id, confidence = match_sample('voice', vec.tolist(), cosine_distance, 0.35)
            if person_id:
                record_observation(person_id, 'voice', confidence,
                                   {'backend':'vosk_speaker_vector'}, 'vosk_speaker', vec.tolist(), confidence)
            return person_id, confidence

    if isinstance(voice_features, dict):
        keys = ('mean_amplitude','std_amplitude','max_amplitude','zero_crossings','duration','rms')
        def distance(a,b):
            va=np.array([float(a.get(k,0)) for k in keys])
            vb=np.array([float(b.get(k,0)) for k in keys])
            scale=np.maximum(np.maximum(np.abs(va),np.abs(vb)),1e-6)
            return float(np.mean(np.abs(va-vb)/scale))
        person_id, confidence = match_sample('voice', voice_features, distance, 0.25)
        if person_id:
            record_observation(person_id, 'voice', confidence, {'backend':'basic_voice_fallback'}, 'voice_fallback', voice_features, confidence)
            return person_id, confidence
        person_id, confidence = match_sample('voice_basic', voice_features, distance, 0.25)
        if person_id:
            record_observation(person_id, 'voice', confidence, {'backend':'basic_voice_fallback'}, 'voice_fallback', voice_features, confidence)
        return person_id, confidence
    return (None, None)


def ensure_person_profile_from_face(face_encoding, quality=0.7):
    person_id, confidence = identify_person(face_encoding)
    if person_id:
        return person_id, confidence, False
    person_id = create_unknown_profile('face', face_encoding, quality, 'opencv_face_detector')
    return person_id, quality, True


def ensure_person_profile_from_voice(voice_features, quality=0.6):
    person_id, confidence = identify_voice(voice_features)
    if person_id:
        return person_id, confidence, False
    person_id = create_unknown_profile('voice', voice_features, quality, 'microphone')
    return person_id, quality, True


def update_person_last_seen(person_id):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("UPDATE identity_profiles SET last_seen=? WHERE person_id=?", (datetime.datetime.now(datetime.timezone.utc).isoformat(), person_id))
        conn.execute("UPDATE persons SET last_seen=? WHERE id=?", (datetime.datetime.now().isoformat(), person_id))


def get_person_conversation_history(person_id, limit=10):
    with sqlite3.connect(DB_PATH) as conn:
        rows = conn.execute("SELECT timestamp,message,role FROM person_conversations WHERE person_id=? ORDER BY timestamp DESC LIMIT ?", (person_id,limit)).fetchall()
    return [{"timestamp":r[0],"message":r[1],"role":r[2]} for r in reversed(rows)]


def log_person_conversation(person_id, message, role):
    now = datetime.datetime.now().isoformat()
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("INSERT INTO person_conversations(id,person_id,timestamp,message,role) VALUES(?,?,?,?,?)", (str(uuid.uuid4()),person_id,now,message,role))
        conn.execute("UPDATE persons SET total_interactions=total_interactions+1,last_seen=? WHERE id=?", (now,person_id))
        conn.execute("UPDATE identity_profiles SET last_seen=? WHERE person_id=?", (now,person_id))


def get_identity_profile(person_id):
    return get_profile(person_id)


def link_name_from_conversation(person_id, text, source='conversation'):
    candidates = list(extract_name_candidates(text))
    if not candidates:
        return []
    out=[]
    for name in candidates:
        out.append((name, associate_name_with_person(person_id,name,source,0.65,False,text)))
    return out


def note_unresolved_names(text, context=''):
    found=[]
    for name in extract_name_candidates(text):
        found.append(cache_name_mention(name,context))
    return found

if __name__ == '__main__':
    init_person_db()
    print('Identity database initialized.')
