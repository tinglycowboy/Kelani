import sqlite3,datetime
from config import DB_PATH
def search_memory(query,limit=8):
 try:
  c=sqlite3.connect(DB_PATH); rows=c.execute("SELECT m.id,m.created_at,'memory',m.content FROM memory_fts f JOIN memory_items m ON m.id=f.rowid WHERE memory_fts MATCH ? ORDER BY rank LIMIT ?",(query,limit)).fetchall()
  if not rows: rows=c.execute("SELECT id,timestamp,role,message FROM logs WHERE message LIKE ? ORDER BY timestamp DESC LIMIT ?",('%'+query+'%',limit)).fetchall()
  c.close(); return [{'id':r[0],'timestamp':r[1],'role':r[2],'message':r[3]} for r in rows]
 except Exception as e: print('Memory search error:',e); return []
def should_search_memory(p): return any(k in p.lower() for k in ['did we talk','discussed','remember','did i mention','do you recall','previous conversation','last time','what do you know about'])
def format_time_ago(x):
 try:
  s=(datetime.datetime.now()-datetime.datetime.fromisoformat(x)).total_seconds()
  return 'just now' if s<60 else f'{int(s/60)} minutes ago' if s<3600 else f'{int(s/3600)} hours ago' if s<86400 else f'{int(s/86400)} days ago'
 except: return 'some time ago'
