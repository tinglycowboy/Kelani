#!/usr/bin/env python3
"""Library Manager: Tracks book reading progress, chunking, and infinite reread cycles"""
import os
import sqlite3
import datetime
import random

from config import DB_PATH, BOOKS_DIR
LIBRARY_PATH = BOOKS_DIR

def init_library_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Main book tracking table
    c.execute("""CREATE TABLE IF NOT EXISTS library_books (
        book_id TEXT PRIMARY KEY,
        title TEXT,
        file_path TEXT,
        status TEXT DEFAULT 'unread', -- 'unread', 'reading', 'completed'
        current_offset INTEGER DEFAULT 0,
        file_size INTEGER DEFAULT 0,
        read_count INTEGER DEFAULT 0,
        added_date TEXT
    )""")
    
    # AI reflections on books (linked to specific read cycles)
    c.execute("""CREATE TABLE IF NOT EXISTS book_reflections (
        id TEXT PRIMARY KEY,
        book_id TEXT,
        read_cycle INTEGER,
        chunk_offset INTEGER,
        summary TEXT,
        ai_opinion TEXT,
        generated_content TEXT, -- story, joke, or advice
        content_type TEXT,
        timestamp TEXT,
        FOREIGN KEY (book_id) REFERENCES library_books(book_id)
    )""")
    
    conn.commit()
    conn.close()

def add_book_to_library(book_id, title, file_path):
    """Add a newly downloaded book to the queue"""
    if not os.path.exists(file_path):
        return
    
    file_size = os.path.getsize(file_path)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Check if already exists
    c.execute("SELECT book_id FROM library_books WHERE book_id = ?", (book_id,))
    if not c.fetchone():
        c.execute("""INSERT INTO library_books 
                     (book_id, title, file_path, status, current_offset, file_size, added_date)
                     VALUES (?, ?, ?, 'unread', 0, ?, ?)""",
                  (book_id, title, file_path, file_size, str(datetime.datetime.now())))
    
    conn.commit()
    conn.close()

def get_next_book_to_read():
    """
    Priority 1: Resume a book currently being read.
    Priority 2: Pick an 'unread' book.
    Priority 3: If all books are 'completed', pick a random 'completed' book to reread.
    """
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # 1. Resume interrupted book
    c.execute("SELECT book_id, title, file_path, current_offset, file_size, read_count FROM library_books WHERE status = 'reading' LIMIT 1")
    book = c.fetchone()
    
    if book:
        conn.close()
        return {
            "book_id": book[0], "title": book[1], "file_path": book[2],
            "offset": book[3], "file_size": book[4], "read_count": book[5],
            "is_reread": book[5] > 0
        }
    
    # 2. Pick an unread book
    c.execute("SELECT book_id, title, file_path, file_size FROM library_books WHERE status = 'unread' LIMIT 1")
    book = c.fetchone()
    
    if book:
        # Mark as reading
        c.execute("UPDATE library_books SET status = 'reading' WHERE book_id = ?", (book[0],))
        conn.commit()
        conn.close()
        return {
            "book_id": book[0], "title": book[1], "file_path": book[2],
            "offset": 0, "file_size": book[3], "read_count": 0, "is_reread": False
        }
    
    # 3. All books completed. Pick a random one to reread.
    c.execute("SELECT book_id, title, file_path, file_size, read_count FROM library_books WHERE status = 'completed' ORDER BY RANDOM() LIMIT 1")
    book = c.fetchone()
    
    if book:
        new_read_count = book[4] + 1
        c.execute("""UPDATE library_books 
                     SET status = 'reading', current_offset = 0, read_count = ? 
                     WHERE book_id = ?""", (new_read_count, book[0]))
        conn.commit()
        conn.close()
        return {
            "book_id": book[0], "title": book[1], "file_path": book[2],
            "offset": 0, "file_size": book[3], "read_count": new_read_count, "is_reread": True
        }
    
    conn.close()
    return None # Library is completely empty

def get_book_chunk(book_id, offset, chunk_size=2500):
    """Read a chunk of text and update the offset"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT file_path, file_size FROM library_books WHERE book_id = ?", (book_id,))
    row = c.fetchone()
    
    if not row:
        conn.close()
        return None, 0, True
    
    file_path, file_size = row
    
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            f.seek(offset)
            text = f.read(chunk_size)
            new_offset = f.tell()
            
            is_finished = new_offset >= file_size
            
            if is_finished:
                c.execute("UPDATE library_books SET status = 'completed', current_offset = ? WHERE book_id = ?", (new_offset, book_id))
            else:
                c.execute("UPDATE library_books SET current_offset = ? WHERE book_id = ?", (new_offset, book_id))
            
            conn.commit()
            return text, new_offset, is_finished
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return None, offset, True
    finally:
        conn.close()

def save_book_reflection(book_id, read_cycle, offset, summary, opinion, generated_content, content_type):
    """Save the AI's thoughts on a specific chunk"""
    import uuid
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""INSERT INTO book_reflections 
                 (id, book_id, read_cycle, chunk_offset, summary, ai_opinion, generated_content, content_type, timestamp)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
              (str(uuid.uuid4()), book_id, read_cycle, offset, summary, opinion, generated_content, content_type, str(datetime.datetime.now())))
    conn.commit()
    conn.close()

def get_book_stats():
    """Get current library statistics"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT status, COUNT(*) FROM library_books GROUP BY status")
    stats = {row[0]: row[1] for row in c.fetchall()}
    conn.close()
    return stats

if __name__ == "__main__":
    init_library_db()
    print("✅ Library Manager initialized.")
    print(f"📊 Current Stats: {get_book_stats()}")
