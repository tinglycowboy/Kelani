#!/usr/bin/env python3
"""Resumable Free Music Archive Small downloader (~7.2 GiB / 8,000 tracks)."""
import os, subprocess, sqlite3, hashlib, time
from config import MUSIC_DIR, DB_PATH

FMA_SMALL_URL = "https://os.unil.cloud.switch.ch/fma/fma_small.zip"
FMA_METADATA_URL = "https://os.unil.cloud.switch.ch/fma/fma_metadata.zip"
FMA_SMALL_SHA1 = "ade154f733639d52e35e32f5593efe5be76c6d70"
FMA_METADATA_SHA1 = "f0df49ffe5f2a6008d7dc83c6915b31835dfe733"

def init_fma_db():
    with sqlite3.connect(DB_PATH) as c:
        c.execute("""CREATE TABLE IF NOT EXISTS fma_download_status(
            id INTEGER PRIMARY KEY, dataset TEXT UNIQUE, status TEXT,
            bytes_downloaded INTEGER DEFAULT 0, message TEXT, updated_at TEXT)""")

def _sha1(path):
    h=hashlib.sha1()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def _download(url, dest):
    os.makedirs(os.path.dirname(dest),exist_ok=True)
    # -c makes a partial archive resumable after reboot/interruption.
    proc=subprocess.Popen(["wget","-c","--timeout=300","--tries=5","-O",dest,url])
    try:
        while proc.poll() is None:
            # User interaction preempts acquisition; -c resumes later.
            if os.path.exists(os.path.join(os.path.expanduser(os.environ.get("AI_SENTRY_HOME","~/ai_sentry")),".ai_busy")):
                proc.terminate()
                try: proc.wait(timeout=10)
                except subprocess.TimeoutExpired: proc.kill()
                return False
            time.sleep(2)
        return proc.returncode == 0
    finally:
        if proc.poll() is None: proc.kill()

def _extract(zip_path, dest):
    os.makedirs(dest,exist_ok=True)
    proc=subprocess.Popen(["unzip","-q","-o",zip_path,"-d",dest])
    busy=os.path.join(os.path.expanduser(os.environ.get("AI_SENTRY_HOME","~/ai_sentry")),".ai_busy")
    try:
        while proc.poll() is None:
            if os.path.exists(busy):
                proc.terminate()
                try: proc.wait(timeout=10)
                except subprocess.TimeoutExpired: proc.kill()
                return False
            time.sleep(2)
        return proc.returncode == 0
    finally:
        if proc.poll() is None: proc.kill()

def download_fma_small():
    """Return True only after the raw FMA Small library is completely present."""
    init_fma_db()
    root=os.path.join(MUSIC_DIR,"fma")
    marker=os.path.join(root,"DOWNLOAD_COMPLETE")
    if os.path.exists(marker):
        return True

    zip_path=os.path.join(MUSIC_DIR,"fma_small.zip")
    print("🎵 FMA Small: 8,000 30-second tracks (~7.2 GiB).")
    if not os.path.exists(zip_path):
        print("   Downloading with resume support...")
    if not _download(FMA_SMALL_URL,zip_path):
        return False
    print("   Verifying FMA Small SHA-1...")
    if _sha1(zip_path).lower()!=FMA_SMALL_SHA1:
        print("⚠️ FMA archive checksum mismatch; keeping partial/archive for retry.")
        return False
    print("   Extracting...")
    if not _extract(zip_path,MUSIC_DIR):
        return False

    # Metadata is useful to the later analyzer but is kept separate from audio.
    meta_zip=os.path.join(MUSIC_DIR,"fma_metadata.zip")
    meta_dir=os.path.join(MUSIC_DIR,"metadata")
    if not os.path.exists(os.path.join(meta_dir,"tracks.csv")):
        if not _download(FMA_METADATA_URL,meta_zip): return False
        if _sha1(meta_zip).lower()!=FMA_METADATA_SHA1: return False
        if not _extract(meta_zip,meta_dir): return False
    try: os.remove(zip_path)
    except OSError: pass
    try: os.remove(meta_zip)
    except OSError: pass
    open(marker,"w").write("FMA Small acquisition complete\n")
    return True

def download_fma_blocking():
    return download_fma_small()

if __name__=="__main__":
    raise SystemExit(0 if download_fma_small() else 1)
