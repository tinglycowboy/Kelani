from flask import Flask, request, render_template, jsonify
from flask_socketio import SocketIO
import sqlite3, queue, threading, requests, datetime, uuid, re, subprocess, os, time, random, cv2, numpy as np
from preprocessor import preprocess, get_route_handler
from wiki_search import search_wikipedia, should_search_wikipedia
from memory_search import search_memory, should_search_memory, format_time_ago
from camera_module import init_camera_db, detect_objects, log_visual_event, camera_loop, get_recent_visuals, is_camera_available
from mic_module import init_audio_db, transcribe_audio, mic_loop, get_recent_audio, is_mic_available
from slang_db import init_slang_db, get_slang_context, learn_slang_from_user
from emotion_engine import init_emotion_db, process_user_emotion, get_current_emotion, get_emotional_response_prefix
from person_recognition import init_person_db, register_person, get_person_conversation_history, log_person_conversation
from identity_manager import init_identity_db, get_profile as get_identity_profile, get_identity_context, request_identity_question, pending_identity_question
from person_profile import init_profile_db, get_person_profile, get_introduction_questions, update_trust_score, analyze_moral_alignment, classify_psychological_traits, get_psychological_context
from proactive_interaction import init_proactive_db, should_initiate_interaction, generate_proactive_message, log_proactive_interaction
from system_monitor import init_system_monitor_db, get_system_status, get_system_health_description, take_system_snapshot
from self_perception import init_self_perception_db, get_how_are_you_response, log_interaction_outcome, get_current_self_perception
from social_graph import init_social_graph_db, get_ai_perception_of_person, store_private_info
from ram_watchdog import init_watchdog_db, watchdog_loop, get_current_status
from scene_descriptor import generate_context_summary
from conversation_summarizer import summarize_person_conversation
from model_manager import evaluate_complexity, switch_model, get_current_model, LIGHT_MODEL, MEDIUM_MODEL, EXTREME_MODEL
from task_orchestrator import run_reasoning_task, init_reasoning_db
from auth_manager import init_auth_db, ensure_account, authenticate, create_session, validate_session, close_session, invalidate_other_sessions
from usb_blocker import init_usb_log, usb_monitor_loop
from neural_optimizer import neural_optimizer_loop
from followup_engine import init_followup_db, should_ask_followup, generate_followup_question, log_followup_question, mark_followup_asked, update_followup_timing
import autonomous_agent
from autonomous_agent import get_current_activity, pause_agent, resume_agent
from library_manager import init_library_db
from library_store import init_library_store
from bible_manager import init_bible_db
from download_gutenberg import init_download_tracker, download_all_background
from library_scheduler import worker_loop as library_worker_loop, init_scheduler
from dashboard import get_full_dashboard_data
from music_manager import init_music_db, download_spotify_link, log_user_feedback, get_user_preferences, get_song_recommendations

AI_NAME = "Kelani"

app = Flask(__name__)
socketio = SocketIO(app)
msg_queue = queue.Queue()
stop_event = threading.Event()
pending_slang_learning = {}
new_person_queue = {}
proactive_conversation_active = {}
system_status = {"status": "normal", "ram_percent": 0, "cpu_temp": 0}

active_session_id = None
active_session_owner_id = None
is_downloading_music = False
music_download_status = {"progress": 0, "message": "Idle"}

db_lock = threading.Lock()
global_state_lock = threading.Lock()

def mark_ai_busy():
    try:
        os.makedirs(os.path.dirname(os.path.expanduser(os.environ.get("AI_SENTRY_HOME","~/ai_sentry"))), exist_ok=True)
        open(os.path.join(os.path.expanduser(os.environ.get("AI_SENTRY_HOME","~/ai_sentry")), ".ai_busy"), "w").write(str(time.time()))
    except Exception: pass

def clear_ai_busy():
    try: os.remove(os.path.join(os.path.expanduser(os.environ.get("AI_SENTRY_HOME","~/ai_sentry")), ".ai_busy"))
    except FileNotFoundError: pass
    except Exception: pass

def get_history(limit=10):
    with db_lock:
        conn = sqlite3.connect("ai_sentry.db")
        try:
            rows = conn.cursor().execute("SELECT id, timestamp, source_tag, role, message FROM logs ORDER BY timestamp DESC LIMIT ?", (limit,)).fetchall()
            return [{"id": r[0], "timestamp": r[1], "source_tag": r[2], "role": r[3], "message": r[4]} for r in reversed(rows)]
        finally:
            conn.close()

def is_math(p):
    p = p.lower()
    return bool(re.search(r"\d\s*[\+\-\*\/\^]\s*\d", p)) or (any(k in p for k in ["calculate","math","plus","minus","times","divide","what is","whats","solve","equals"]) and bool(re.search(r"\d", p)))

def calc(p):
    p = p.lower().replace("plus","+").replace("minus","-").replace("times","*").replace("divided by","/").replace("x","*").replace("multiply","*")
    m = re.search(r"[\d\.\+\-\*\/\(\)\s\^]+", p)
    if m:
        try: return f"The answer is {eval(m.group(0).strip(), {'__builtins__': {}}, {})}"
        except: pass
    return None

def is_time_query(p):
    p = p.lower()
    return any(k in p for k in ["what time","current time","what day","today","date","day of week"])

def get_time_info():
    now = datetime.datetime.now()
    return f"The current time is {now.strftime('%I:%M %p')} on {now.strftime('%A, %B %d, %Y')}."

def is_how_are_you(p):
    p = p.lower()
    return any(k in p for k in ["how are you","how're you","how are you doing","how do you feel","how's it going"])

def is_system_query(p):
    p = p.lower()
    return any(k in p for k in ["system status","how's the system","ram usage","temperature","cpu temp","how are you running"])

def research_local_databases(query):
    """Search local reference databases and raw library sources for the reasoning controller."""
    evidence = []
    try:
        wiki = search_wikipedia(query, limit=3)
        for r in wiki:
            source = r.get("source_file", "")
            evidence.append(f"[Wikipedia] {r.get('title','')}\n{r.get('abstract','')}\nRAW_SOURCE={source}")
    except Exception as e:
        print(f"Wikipedia research error: {e}")
    try:
        from knowledge_base import query_knowledge
        rows = query_knowledge(query, "dictionary", limit=5)
        for row in rows:
            word, definition, synonyms, antonyms = row
            evidence.append(f"[Dictionary/Thesaurus] {word}: {definition}\nSynonyms: {synonyms}\nAntonyms: {antonyms}")
    except Exception as e:
        print(f"Dictionary research error: {e}")
    try:
        from config import DB_PATH
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        rows = conn.execute("""SELECT d.title,d.path,c.text,c.chunk_index
                              FROM library_documents d JOIN library_chunks c ON c.document_id=d.id
                              WHERE d.title LIKE ? OR c.text LIKE ?
                              ORDER BY d.id DESC LIMIT 5""", (f"%{query}%", f"%{query}%")).fetchall()
        for r in rows:
            evidence.append(f"[Local Library] {r['title']} chunk={r['chunk_index']}\n{r['text'][:3500]}\nRAW_SOURCE={r['path']}")
        conn.close()
    except Exception as e:
        print(f"Library research error: {e}")
    return "\n\n".join(evidence[:12])

def speak_text(text):
    try:
        subprocess.run(["amixer", "set", "PCM", "100%"], capture_output=True)
        subprocess.run(["espeak", "-v", "en", "-s", "150", text], capture_output=True)
    except Exception as e:
        print(f"TTS Error: {e}")

def queue_mic_input(text, person_id=None):
    log_id = str(uuid.uuid4())
    with db_lock:
        conn = sqlite3.connect("ai_sentry.db")
        try:
            conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (log_id, str(datetime.datetime.now()), "MIC_INPUT", "user", text))
            conn.commit()
        finally:
            conn.close()
    socketio.emit("new_message", {"id": log_id, "role": "user", "message": f"[MIC] {text}"})
    mark_ai_busy(); msg_queue.put((log_id, text, person_id))

def proactive_camera_callback(person_id, frame):
    # Unknown people can have a durable profile even when they never speak.
    # Only ask for a name when we have a stable face profile and no pending question.
    identity = get_identity_profile(person_id)
    if identity and not identity.get("display_name"):
        if pending_identity_question(person_id) is None:
            request_identity_question(person_id, "name")
            message = "I don't recognize you yet. What should I call you?"
            log_proactive_interaction(person_id, "identity_name_request", message)
            log_id = str(uuid.uuid4())
            with db_lock:
                conn = sqlite3.connect("ai_sentry.db")
                try:
                    conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (log_id, str(datetime.datetime.now()), "IDENTITY_REQUEST", "assistant", message))
                    conn.commit()
                finally: conn.close()
            socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": message})
            speak_text(message)
            return True
        return False

    interaction_type = should_initiate_interaction(person_id, frame)
    if interaction_type:
        message = generate_proactive_message(interaction_type, person_id)
        log_proactive_interaction(person_id, interaction_type, message)
        log_id = str(uuid.uuid4())
        with db_lock:
            conn = sqlite3.connect("ai_sentry.db")
            try:
                conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (log_id, str(datetime.datetime.now()), "PROACTIVE_INITIATION", "assistant", message))
                conn.commit()
            finally:
                conn.close()
        socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": message})
        speak_text(message)
        with global_state_lock:
            proactive_conversation_active[person_id] = log_id
        return True
    return False

def update_system_status(status):
    global system_status
    with global_state_lock:
        system_status = status
    socketio.emit("system_status", status)

def handle_music_download(url, log_id, session_id):
    global is_downloading_music, music_download_status
    if session_id != active_session_id: return
    is_downloading_music = True
    pause_agent()
    def progress_cb(current, message):
        global music_download_status
        music_download_status = {"progress": current, "message": message}
        socketio.emit("music_download_update", music_download_status)
    socketio.emit("lock_ui", {"reason": "Downloading and deduplicating music. Please wait..."})
    speak_text("Starting music download. I will lock the interface until it is complete.")
    success, msg = download_spotify_link(url, progress_cb)
    is_downloading_music = False
    music_download_status = {"progress": 100, "message": "Complete"}
    socketio.emit("music_download_update", music_download_status)
    socketio.emit("unlock_ui")
    ans = msg if success else f"Download failed: {msg}"
    with db_lock:
        conn = sqlite3.connect("ai_sentry.db")
        try:
            conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (str(uuid.uuid4()), str(datetime.datetime.now()), "AI_RESPONSE", "assistant", ans))
            conn.commit()
        finally:
            conn.close()
    socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": ans})
    speak_text(ans)
    resume_agent()

def ai_worker():
    global pending_slang_learning, new_person_queue, proactive_conversation_active
    while True:
        try:
            log_id, prompt, person_id = msg_queue.get()
            if person_id and person_id != active_session_id:
                msg_queue.task_done(); clear_ai_busy()
                continue
            
            pause_agent()
            if random.random() < 0.1: take_system_snapshot()
            
            with global_state_lock:
                if person_id and person_id in proactive_conversation_active:
                    proactive_log_id = proactive_conversation_active[person_id]
                    with db_lock:
                        conn = sqlite3.connect("ai_sentry.db")
                        try:
                            conn.cursor().execute("UPDATE proactive_interactions SET response = ? WHERE id = ?", (prompt, proactive_log_id))
                            conn.commit()
                        finally: conn.close()
                    del proactive_conversation_active[person_id]
            
            preprocessed = preprocess(prompt, person_id)
            if not preprocessed["safe_to_process"]:
                ans = preprocessed["warning"] or "I can't process that message."
                with db_lock:
                    conn = sqlite3.connect("ai_sentry.db")
                    try:
                        conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (str(uuid.uuid4()), str(datetime.datetime.now()), "AI_RESPONSE", "assistant", ans))
                        conn.commit()
                    finally: conn.close()
                socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": ans})
                speak_text(ans)
                msg_queue.task_done(); clear_ai_busy()
                resume_agent()
                continue
            
            prompt = preprocessed["processed_text"]
            
            with global_state_lock:
                if log_id in pending_slang_learning:
                    slang_term = pending_slang_learning[log_id]
                    learn_slang_from_user(slang_term, prompt)
                    del pending_slang_learning[log_id]
                    ans = f"Thanks! I'll remember that '{slang_term}' means '{prompt}'."
                    with db_lock:
                        conn = sqlite3.connect("ai_sentry.db")
                        try:
                            conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (str(uuid.uuid4()), str(datetime.datetime.now()), "AI_RESPONSE", "assistant", ans))
                            conn.commit()
                        finally: conn.close()
                    socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": ans})
                    speak_text(ans)
                    msg_queue.task_done(); clear_ai_busy()
                    resume_agent()
                    continue
            
            with global_state_lock:
                if log_id in new_person_queue:
                    temp_person_id = new_person_queue[log_id]
                    profile = get_person_profile(temp_person_id)
                    if profile and (not profile.get('name') or profile.get('name') == 'Unknown'):
                        from person_profile import update_person_profile
                        update_person_profile(temp_person_id, 'name', prompt)
                        ans = f"Nice to meet you, {prompt}! I'm {AI_NAME}. I'll remember that."
                        with db_lock:
                            conn = sqlite3.connect("ai_sentry.db")
                            try:
                                conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (str(uuid.uuid4()), str(datetime.datetime.now()), "AI_RESPONSE", "assistant", ans))
                                conn.commit()
                            finally: conn.close()
                        socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": ans})
                        speak_text(ans)
                        del new_person_queue[log_id]
                        msg_queue.task_done(); clear_ai_busy()
                        resume_agent()
                        continue
            
            current_emotion, emotion_intensity, _ = process_user_emotion(prompt)
            if person_id:
                moral = analyze_moral_alignment(person_id, prompt)
                if moral != "neutral":
                    from person_profile import update_moral_alignment
                    update_moral_alignment(person_id, moral)
                person_hist = get_person_conversation_history(person_id, 10)
                if len(person_hist) >= 5:
                    classify_psychological_traits(person_id, person_hist)
            
            route = preprocessed.get("route", {})
            route_name = route.get("route", "ai_general")
            
            if route_name == "calculator" or is_math(prompt):
                res = calc(prompt)
                if res:
                    with db_lock:
                        conn = sqlite3.connect("ai_sentry.db")
                        try:
                            conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (str(uuid.uuid4()), str(datetime.datetime.now()), "AI_RESPONSE", "assistant", res))
                            conn.commit()
                            if person_id:
                                log_person_conversation(person_id, prompt, "user")
                                log_person_conversation(person_id, res, "assistant")
                        finally: conn.close()
                    socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": res})
                    speak_text(res)
                    msg_queue.task_done(); clear_ai_busy()
                    resume_agent()
                    continue
            
            if route_name == "time" or is_time_query(prompt):
                res = get_time_info()
                with db_lock:
                    conn = sqlite3.connect("ai_sentry.db")
                    try:
                        conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (str(uuid.uuid4()), str(datetime.datetime.now()), "AI_RESPONSE", "assistant", res))
                        conn.commit()
                        if person_id:
                            log_person_conversation(person_id, prompt, "user")
                            log_person_conversation(person_id, res, "assistant")
                    finally: conn.close()
                socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": res})
                speak_text(res)
                msg_queue.task_done(); clear_ai_busy()
                resume_agent()
                continue
            
            if route_name == "how_are_you" or is_how_are_you(prompt):
                from self_perception import get_how_are_you_response
                res = f"I'm {AI_NAME}. {get_how_are_you_response()}"
                with db_lock:
                    conn = sqlite3.connect("ai_sentry.db")
                    try:
                        conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (str(uuid.uuid4()), str(datetime.datetime.now()), "AI_RESPONSE", "assistant", res))
                        conn.commit()
                        if person_id:
                            log_person_conversation(person_id, prompt, "user")
                            log_person_conversation(person_id, res, "assistant")
                    finally: conn.close()
                socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": res})
                speak_text(res)
                msg_queue.task_done(); clear_ai_busy()
                resume_agent()
                continue
            
            if route_name == "system_status" or is_system_query(prompt):
                status = get_system_status()
                health = get_system_health_description()
                activity = get_current_activity()
                activity_text = f" I was just {activity.lower()}, but I'm here now." if activity else ""
                res = f"I'm {AI_NAME}. My system status: {status}. Overall, I'm {health}.{activity_text}"
                with db_lock:
                    conn = sqlite3.connect("ai_sentry.db")
                    try:
                        conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (str(uuid.uuid4()), str(datetime.datetime.now()), "AI_RESPONSE", "assistant", res))
                        conn.commit()
                        if person_id:
                            log_person_conversation(person_id, prompt, "user")
                            log_person_conversation(person_id, res, "assistant")
                    finally: conn.close()
                socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": res})
                speak_text(res)
                msg_queue.task_done(); clear_ai_busy()
                resume_agent()
                continue
            
            # Kelani always starts a new reasoning task with the light model.
            # The task orchestrator owns escalation, research pauses, recursive decomposition,
            # synthesis, checkpoints, and RAM-aware fallback.
            tier, reason, est_seconds = evaluate_complexity(prompt, preprocessed.get("nlp"))
            model_switched = False
            tag = "[ADAPTIVE]"
            socketio.emit("thinking_update", {"message": f"{AI_NAME} is starting with qwen3:0.6b and will adapt the task if needed."})
            
            hist = get_history(2)
            hist_str = chr(10).join([f"User: {h['message']}" if h['role']=='user' else f"{AI_NAME}: {h['message']}" for h in hist])
            
            person_context = ""
            if person_id:
                person_hist = get_person_conversation_history(person_id, 3)
                if person_hist:
                    person_context = chr(10).join([f"You: {h['message']}" if h['role']=='user' else f"{AI_NAME}: {h['message']}" for h in person_hist])
                    person_context = f"Previous conversation:{chr(10)}{person_context}{chr(10)}{chr(10)}"
                identity_context = get_identity_context(person_id)
                if identity_context: person_context += identity_context + chr(10) + chr(10)
                psych_context = get_psychological_context(person_id)
                if psych_context: person_context += psych_context + chr(10) + chr(10)
            
            visual_context, audio_context = "", ""
            if is_camera_available():
                recent_visuals = get_recent_visuals(3)
                if recent_visuals: visual_context = generate_context_summary(recent_visuals)
            if is_mic_available():
                recent_audio = get_recent_audio(3)
                if recent_audio: audio_context = chr(10).join([f"[{a['timestamp']}] Heard: {a['text']}" for a in recent_audio])
            
            slang_context = get_slang_context(prompt)
            multimodal_info = ""
            if visual_context: multimodal_info += f"Visual:{chr(10)}{visual_context}{chr(10)}{chr(10)}"
            if audio_context: multimodal_info += f"Audio:{chr(10)}{audio_context}{chr(10)}{chr(10)}"
            if slang_context: multimodal_info += f"{slang_context}.{chr(10)}{chr(10)}"
            if person_context: multimodal_info += person_context
            if preprocessed.get("entities"):
                multimodal_info += f"Entities: {', '.join([f'{k}: {v}' for k, v in preprocessed['entities'].items()])}.{chr(10)}{chr(10)}"
            
            emotional_prefix = get_emotional_response_prefix(current_emotion, emotion_intensity)
            emotion_instruction = f"You are {AI_NAME}. You are feeling {current_emotion} (intensity: {emotion_intensity:.2f}). "
            if current_emotion != "neutral" and emotion_intensity > 0.5: emotion_instruction += "Let this influence your tone. "
            
            kb_response = None
            if route_name == "emergency":
                from knowledge_base import query_knowledge
                res = query_knowledge(prompt, "emergency")
                if res: kb_response = f"EMERGENCY: {res[0][1]}"
            elif route_name == "dictionary":
                from knowledge_base import query_knowledge
                words = prompt.split()
                res = query_knowledge(words[-1] if len(words)>2 else prompt, "dictionary")
                if res: kb_response = f"'{res[0][0]}': {res[0][1]}. Syn: {res[0][2]}."
            elif route_name == "jokes":
                from knowledge_base import query_knowledge
                res = query_knowledge("a", "jokes", limit=10)
                if res: kb_response = f"{random.choice(res)[0]} {random.choice(res)[1]}"
            elif route_name == "banter":
                from knowledge_base import query_knowledge
                res = query_knowledge("me", "banter") or query_knowledge("you", "banter")
                if res: kb_response = res[0][1]
            elif route_name in ["physics", "calculus", "acronyms"]:
                from knowledge_base import query_knowledge
                res = query_knowledge(prompt, route_name)
                if res: kb_response = f"{res[0][0]}: {res[0][1]}"

            identity_instruction = f"Your name is {AI_NAME}. You are an autonomous AI assistant running locally on a Raspberry Pi. You have a library of music you have analyzed. If the user asks to play music or a playlist, describe the playlist you recommend based on your analysis, and tell them you are queuing it up. "
            
            if kb_response:
                sys_inst = f"{identity_instruction}Fast response mode. Direct factual answer: {kb_response}. Be concise. No greetings."
            else:
                if route_name == "memory" or should_search_memory(prompt):
                    mem_res = search_memory(prompt)
                    if mem_res:
                        time_ago = format_time_ago(mem_res[0]['timestamp'])
                        mem_ctx = chr(10).join([f"{r['timestamp']} - {r['role']}: {r['message']}" for r in mem_res[:3]])
                        wiki_res = search_wikipedia(prompt)
                        if wiki_res:
                            wiki_ctx = chr(10) + chr(10).join([f"{r['title']}: {r['abstract']}" for r in wiki_res])
                            sys_inst = f"{identity_instruction}{multimodal_info}{emotion_instruction}We talked about this {time_ago}. Discussed:{chr(10)}{mem_ctx}{chr(10)}Start: 'We talked a little about this {time_ago}.' Then: 'However, here are facts:' and provide:{chr(10)}{wiki_ctx}{chr(10)}Direct answer only."
                        else:
                            sys_inst = f"{identity_instruction}{multimodal_info}{emotion_instruction}We talked about this {time_ago}. Discussed:{chr(10)}{mem_ctx}{chr(10)}Start: 'We talked a little about this {time_ago}.' Direct answer only."
                    else:
                        sys_inst = f"{identity_instruction}{multimodal_info}{emotion_instruction}No record of this. Start: 'Sorry, I can't recall anything about that.' Direct answer."
                elif route_name == "wikipedia" or should_search_wikipedia(prompt):
                    wiki_res = search_wikipedia(prompt)
                    if wiki_res:
                        # FIXED: Extracted list comprehension to prevent nested quote SyntaxError
                        wiki_ctx = chr(10).join([f"{r['title']}: {r['abstract']}" for r in wiki_res])
                        sys_inst = f"{identity_instruction}{multimodal_info}{emotion_instruction}Wikipedia context:{chr(10)}{wiki_ctx}{chr(10)}Direct answer only."
                    else:
                        sys_inst = f"{identity_instruction}{multimodal_info}{emotion_instruction}Direct answer only."
                else:
                    sys_inst = f"{identity_instruction}{multimodal_info}{emotion_instruction}Direct answer only."
            
            ans = None
            try:
                init_reasoning_db()
                task_context = hist_str
                if multimodal_info:
                    task_context += "\n" + multimodal_info
                result = run_reasoning_task(
                    original_prompt=f"{hist_str}{chr(10)}User: {prompt}",
                    system_instruction=sys_inst,
                    context=task_context,
                    research_callback=research_local_databases,
                    socketio=socketio,
                    max_depth=4,
                    max_research_rounds=3,
                )
                ans = result.get("result") or None
                socketio.emit("reasoning_task", {
                    "task_id": result.get("task_id"),
                    "status": result.get("status"),
                    "model": result.get("model"),
                })
            except Exception as e:
                print(f"⚠️ Adaptive reasoning error: {e}")
                ans = None
            
            ans = ans or "I honestly don't know based on the information available to me."
            
            if "Unknown terms detected" in slang_context:
                match = re.search(r"Unknown terms detected: ([^\.]+)", slang_context)
                if match:
                    term = match.group(1).split(", ")[0].strip()
                    with global_state_lock: pending_slang_learning[log_id] = term
                    ans += f" By the way, I'm not familiar with the term '{term}'. What does it mean?"
            
            if emotional_prefix and current_emotion != "neutral" and emotion_intensity > 0.6: ans = emotional_prefix + ans
            if preprocessed.get("warning"): ans = preprocessed["warning"] + " " + ans
            
            with db_lock:
                conn = sqlite3.connect("ai_sentry.db")
                try:
                    conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (str(uuid.uuid4()), str(datetime.datetime.now()), "AI_RESPONSE", "assistant", ans))
                    conn.commit()
                    if person_id:
                        log_person_conversation(person_id, prompt, "user")
                        log_person_conversation(person_id, ans, "assistant")
                        update_trust_score(person_id, 0.01)
                finally: conn.close()
            
            socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": ans})
            socketio.emit("emotion_update", {"emotion": current_emotion, "intensity": emotion_intensity})
            speak_text(ans)
            
            if person_id:
                try:
                    person_hist = get_person_conversation_history(person_id, 5)
                    should_fu, reason = should_ask_followup(person_id, prompt, ans, person_hist)
                    if should_fu:
                        fu_q = generate_followup_question(person_id, prompt, ans, person_hist)
                        log_followup_question(person_id, prompt, ans, fu_q)
                        def delayed_fu(text, p_id):
                            time.sleep(random.randint(5, 15))
                            fid = str(uuid.uuid4())
                            with db_lock:
                                conn = sqlite3.connect("ai_sentry.db")
                                try:
                                    conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (fid, str(datetime.datetime.now()), "FOLLOWUP", "assistant", text))
                                    conn.commit()
                                finally: conn.close()
                            socketio.emit("new_message", {"id": fid, "role": "assistant", "message": text})
                            speak_text(text)
                            with db_lock:
                                conn = sqlite3.connect("ai_sentry.db")
                                try:
                                    c = conn.cursor()
                                    c.execute("SELECT id FROM followup_questions WHERE asked = 0 ORDER BY timestamp DESC LIMIT 1")
                                    res = c.fetchone()
                                    if res: mark_followup_asked(res[0])
                                finally: conn.close()
                            update_followup_timing(p_id)
                        threading.Thread(target=delayed_fu, args=(fu_q, person_id), daemon=True).start()
                except Exception as e:
                    print(f"⚠️ Follow-up error: {e}")
            
            try: socketio.emit("dashboard_update", get_full_dashboard_data())
            except: pass
            msg_queue.task_done(); clear_ai_busy()
            resume_agent()
        except Exception as e:
            print(f"⚠️ Critical ai_worker error: {e}")
            resume_agent()
            msg_queue.task_done(); clear_ai_busy()

@socketio.on("request_history")
def handle_request_history(data=None):
    data = data or {}
    session = validate_session(data.get("session_id"))
    if not session:
        socketio.emit("session_expired")
        return
    socketio.emit("history_loaded", {"history": get_history(10)})
    socketio.emit("system_status", system_status)
    activity = get_current_activity()
    if activity: socketio.emit("autonomous_status", {"state": "reading", "activity": activity})

@socketio.on("send_message")
def handle_send_message(data):
    session_id = data.get("session_id")
    session = validate_session(session_id)
    if not session or session_id != active_session_id:
        socketio.emit("session_expired")
        return
    if is_downloading_music:
        socketio.emit("new_message", {"id": str(uuid.uuid4()), "role": "assistant", "message": "I am currently downloading music. Please wait."})
        return

    log_id = str(uuid.uuid4())
    message = data.get("message")
    person_id = session["owner_id"]
    
    if "spotify.com" in message.lower() and ("download" in message.lower() or "add" in message.lower()):
        import re
        url_match = re.search(r'(https?://open\.spotify\.com/\S+)', message)
        if url_match:
            url = url_match.group(1)
            with db_lock:
                conn = sqlite3.connect("ai_sentry.db")
                try:
                    conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (log_id, str(datetime.datetime.now()), "TEXT_PROMPT", "user", message))
                    conn.commit()
                finally: conn.close()
            socketio.emit("new_message", {"id": log_id, "role": "user", "message": message})
            threading.Thread(target=handle_music_download, args=(url, log_id, session_id), daemon=True).start()
            return

    with db_lock:
        conn = sqlite3.connect("ai_sentry.db")
        try:
            conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (log_id, str(datetime.datetime.now()), "TEXT_PROMPT", "user", message))
            conn.commit()
        finally: conn.close()
    
    socketio.emit("new_message", {"id": log_id, "role": "user", "message": message})
    mark_ai_busy(); msg_queue.put((log_id, message, person_id))

@app.route("/")
def index(): return render_template("index.html")

@app.route("/api/login", methods=["POST"])
def api_login():
    global active_session_id, active_session_owner_id
    data = request.json or {}
    account = authenticate(data.get("user", ""), data.get("pass", ""))
    if not account:
        return jsonify({"error": "Invalid username or password"}), 401
    old = active_session_id
    active_session_id, reopen_key = create_session(account)
    active_session_owner_id = account["owner_id"]
    invalidate_other_sessions(active_session_id)
    # Any previous session is invalidated in SQLite; its next heartbeat/message will expire it.
    return jsonify({"session_id": active_session_id, "reopen_key": reopen_key})

@app.route("/api/session/heartbeat", methods=["POST"])
def api_session_heartbeat():
    data=request.json or {}
    session=validate_session(data.get("session_id"))
    if not session: return jsonify({"valid":False}),401
    return jsonify({"valid":True,"owner_id":session["owner_id"]})

@app.route("/api/session/close", methods=["POST"])
def api_session_close():
    global active_session_id, active_session_owner_id
    data=request.form or (request.json or {})
    sid=data.get("session_id")
    if sid:
        close_session(sid)
    if sid == active_session_id:
        active_session_id=None; active_session_owner_id=None
    return jsonify({"status":"closed"})

@app.route("/api/logout", methods=["POST"])
def api_logout():
    return api_session_close()

@app.route("/api/media", methods=["POST"])
def api_media():
    global active_session_id
    session_id = request.form.get('session_id')
    session = validate_session(session_id)
    if not session or session_id != active_session_id:
        return jsonify({"error": "Invalid session"}), 401
    if 'media' not in request.files:
        return jsonify({"error": "No media file"}), 400
    
    media_file = request.files['media']
    temp_media = "/tmp/browser_media.webm"
    temp_audio = "/tmp/browser_audio.wav"
    temp_frame = "/tmp/browser_frame.jpg"
    
    try:
        media_file.save(temp_media)
        subprocess.run(["ffmpeg", "-y", "-i", temp_media, "-vn", "-ar", "16000", "-ac", "1", "-f", "s16le", temp_audio], capture_output=True, check=True)
        text, confidence = transcribe_audio(temp_audio)
        subprocess.run(["ffmpeg", "-y", "-i", temp_media, "-ss", "00:00:01", "-vframes", "1", temp_frame], capture_output=True, check=True)
        
        objects, object_count = [], 0
        if os.path.exists(temp_frame):
            frame = cv2.imread(temp_frame)
            if frame is not None:
                objects, object_count = detect_objects(frame)
        
        person_id = session["owner_id"]
        if text and text.strip():
            log_id = str(uuid.uuid4())
            with db_lock:
                conn = sqlite3.connect("ai_sentry.db")
                try:
                    conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", (log_id, str(datetime.datetime.now()), "MIC_INPUT", "user", text.strip()))
                    conn.commit()
                finally: conn.close()
            mark_ai_busy(); msg_queue.put((log_id, text.strip(), person_id))
        
        if object_count > 0:
            log_visual_event(objects, object_count, person_id, None)
            
        return jsonify({"status": "success", "text": text.strip() if text else ""})
    except Exception as e:
        print(f"Media processing error: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        for f in [temp_media, temp_audio, temp_frame]:
            if os.path.exists(f): os.remove(f)

@app.route("/api/feedback", methods=["POST"])
def api_feedback():
    global active_session_id
    data = request.json or {}
    if not validate_session(data.get("session_id")) or data.get("session_id") != active_session_id:
        return jsonify({"error": "Invalid session"}), 401
    song_id = data.get("song_id")
    feedback_type = data.get("type")
    comment = data.get("comment", "")
    if song_id and feedback_type:
        log_user_feedback(song_id, data.get("session_id"), feedback_type, comment)
        return jsonify({"status": "success"})
    return jsonify({"error": "Missing data"}), 400

@app.route("/api/status")
def api_status():
    from ram_watchdog import get_current_status
    return jsonify(get_current_status())

@app.route("/api/dashboard")
def api_dashboard(): return jsonify(get_full_dashboard_data())

@app.route("/api/moral-guide")
def api_moral_guide():
    try:
        from bible_manager import get_moral_guide
        return jsonify({"principles": get_moral_guide()})
    except: return jsonify({"principles": []})

@app.route("/api/generated-content")
def api_generated_content():
    try:
        with db_lock:
            conn = sqlite3.connect("ai_sentry.db")
            try:
                c = conn.cursor()
                c.execute("""SELECT content_type, title, content, timestamp FROM ai_generated_content ORDER BY timestamp DESC LIMIT 20""")
                return jsonify({"content": [{"type": r[0], "title": r[1], "content": r[2], "timestamp": r[3]} for r in c.fetchall()]})
            finally: conn.close()
    except: return jsonify({"content": []})

@app.route("/api/music/playlists")
def api_music_playlists():
    try:
        with db_lock:
            conn = sqlite3.connect("ai_sentry.db")
            try:
                c = conn.cursor()
                c.execute("SELECT playlist_id, name, creation_reason, created_date FROM ai_playlists ORDER BY created_date DESC")
                return jsonify({"playlists": [{"id": r[0], "name": r[1], "reason": r[2], "date": r[3]} for r in c.fetchall()]})
            finally: conn.close()
    except: return jsonify({"playlists": []})

if __name__ == "__main__":
    with db_lock:
        conn = sqlite3.connect("ai_sentry.db")
        try:
            conn.cursor().execute("CREATE TABLE IF NOT EXISTS logs (id TEXT PRIMARY KEY, timestamp TEXT, source_tag TEXT, role TEXT, message TEXT)")
            conn.commit()
        finally: conn.close()
    
    init_camera_db(); init_audio_db(); init_slang_db(); init_emotion_db()
    init_person_db(); init_profile_db(); init_identity_db(); init_proactive_db()
    init_system_monitor_db(); init_self_perception_db(); init_social_graph_db()
    init_watchdog_db(); init_usb_log(); init_followup_db(); init_reasoning_db(); init_auth_db()
    login_user, generated_password = ensure_account()
    if generated_password:
        print(f"🔐 Web login created for {login_user}; credentials saved to ~/ai_sentry/web_login.txt (mode 600)")
    from task_orchestrator import recover_after_boot
    recovered_reasoning = recover_after_boot()
    if recovered_reasoning:
        print(f"🧠 Reasoning recovery: {recovered_reasoning}")
    init_library_db(); init_library_store(); init_bible_db(); init_download_tracker(); init_scheduler()
    init_music_db()
    from knowledge_base import init_db, populate_data
    _kb_conn = init_db(); populate_data(_kb_conn); _kb_conn.close()
    
    from analytics import init_analytics_db; init_analytics_db()
    from safety_filters import init_safety_db; init_safety_db()
    from autonomous_agent import init_autonomous_db; init_autonomous_db()
    
    threading.Thread(target=ai_worker, daemon=True).start()
    threading.Thread(target=watchdog_loop, args=(stop_event, update_system_status), daemon=True).start()
    threading.Thread(target=usb_monitor_loop, args=(stop_event,), daemon=True).start()
    threading.Thread(target=neural_optimizer_loop, args=(stop_event,), daemon=True).start()
    if os.environ.get("AI_SENTRY_LEGACY_AUTONOMOUS","0")=="1":
        threading.Thread(target=autonomous_agent.autonomous_loop,args=(stop_event,),daemon=True).start()
    # The sequential scheduler is part of the normal unattended lifecycle.
    # It enforces acquisition-before-analysis and resumes from SQLite checkpoints.
    threading.Thread(target=library_worker_loop, args=(stop_event,), daemon=True).start()
    print("📚 Sequential library scheduler active: raw acquisition → analysis")
    
    def storage_check_loop():
        while not stop_event.is_set():
            try:
                from storage_manager import manage_storage
                manage_storage()
            except Exception as e: print(f"Storage check error: {e}")
            time.sleep(3600)
    threading.Thread(target=storage_check_loop, daemon=True).start()
    
    if is_camera_available():
        threading.Thread(target=camera_loop, args=(stop_event, proactive_camera_callback), daemon=True).start()
        print("📷 Camera thread started at 15 fps")
    else: print("⚠️ Camera not available")
    
    if is_mic_available():
        threading.Thread(target=mic_loop, args=(stop_event, queue_mic_input), daemon=True).start()
        print("🎤 Microphone thread started")
    else: print("⚠️ Microphone not available")
    
    print(f"🤖 AI Identity: {AI_NAME}")
    print(f"🧠 Light: {LIGHT_MODEL} | Medium: {MEDIUM_MODEL} | Extreme: {EXTREME_MODEL}")
    print(f"🧠 Currently loaded: {get_current_model()}")
    print("🔒 USB Security Monitor active")
    print("🧠 Neural Optimizer active")
    print("🗣️ Follow-up Engine active")
    print("📚 Autonomous Library Agent active")
    print("📊 Dashboard API active")
    print("🎵 Music Manager active")
    print("📹 Browser Media API active")
    
    socketio.run(app, host="0.0.0.0", port=5000)
