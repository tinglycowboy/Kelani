#!/usr/bin/env python3
"""Dashboard Data Aggregator: Collects all real-time system and AI state info"""
import sqlite3
import os
import datetime
import subprocess

DB_PATH = "ai_sentry.db"

def get_cpu_temp():
    try:
        result = subprocess.run(['vcgencmd', 'measure_temp'], capture_output=True, text=True)
        return float(result.stdout.replace('temp=', '').replace("'C", '').strip())
    except:
        return 0.0

def get_ram_usage():
    try:
        result = subprocess.run(['free', '-m'], capture_output=True, text=True)
        lines = result.stdout.strip().split('\n')
        mem = lines[1].split()
        total = int(mem[1])
        used = int(mem[2])
        return {"used_mb": used, "total_mb": total, "percent": round((used/total)*100, 1)}
    except:
        return {"used_mb": 0, "total_mb": 0, "percent": 0}

def get_storage_usage():
    import shutil
    try:
        usage = shutil.disk_usage('/')
        return {
            "used_gb": round(usage.used / (1024**3), 1),
            "total_gb": round(usage.total / (1024**3), 1),
            "percent": round((usage.used / usage.total) * 100, 1)
        }
    except:
        return {"used_gb": 0, "total_gb": 0, "percent": 0}

def get_ai_emotion():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT current_emotion, intensity FROM emotion_state ORDER BY id DESC LIMIT 1")
        row = c.fetchone()
        conn.close()
        if row:
            return {"emotion": row[0], "intensity": round(row[1] * 100)}
    except:
        pass
    return {"emotion": "neutral", "intensity": 50}

def get_current_model():
    try:
        from model_manager import get_current_model
        return get_current_model()
    except:
        return "unknown"

def get_current_activity():
    try:
        from autonomous_agent import get_current_activity
        return get_current_activity() or "Idle"
    except:
        return "Idle"

def get_library_stats():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        c.execute("SELECT COUNT(*) FROM library_books WHERE status = 'completed'")
        completed = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM library_books WHERE status = 'reading'")
        reading = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM library_books WHERE status = 'unread'")
        unread = c.fetchone()[0]
        
        current_book = None
        if reading > 0:
            c.execute("SELECT title, current_offset, file_size, read_count FROM library_books WHERE status = 'reading' LIMIT 1")
            row = c.fetchone()
            if row:
                progress = round((row[1] / row[2]) * 100, 1) if row[2] > 0 else 0
                current_book = {
                    "title": row[0],
                    "progress": progress,
                    "read_count": row[3]
                }
        
        conn.close()
        return {
            "completed": completed,
            "reading": reading,
            "unread": unread,
            "total": completed + reading + unread,
            "current_book": current_book
        }
    except Exception as e:
        print(f"Library stats error: {e}")
        return {"completed": 0, "reading": 0, "unread": 0, "total": 0, "current_book": None}

def get_bible_progress():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""SELECT book, chapter, verse_start, verse_end, cycle_number 
                     FROM bible_progress ORDER BY id DESC LIMIT 1""")
        row = c.fetchone()
        conn.close()
        if row:
            return {
                "book": row[0].title(),
                "chapter": row[1],
                "verse_start": row[2],
                "verse_end": row[3],
                "cycle": row[4],
                "reference": f"{row[0].title()} {row[1]}:{row[2]}-{row[3]}"
            }
    except:
        pass
    return None

def get_moral_guide_count():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM moral_guide")
        count = c.fetchone()[0]
        conn.close()
        return count
    except:
        return 0

def get_people_known():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM persons")
        count = c.fetchone()[0]
        conn.close()
        return count
    except:
        return 0

def get_recent_conversations(limit=5):
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""SELECT role, message, timestamp FROM logs 
                     WHERE role IN ('user', 'assistant')
                     ORDER BY timestamp DESC LIMIT ?""", (limit,))
        rows = c.fetchall()
        conn.close()
        return [{"role": r[0], "message": r[1][:100], "timestamp": r[2]} for r in reversed(rows)]
    except:
        return []

def get_uptime():
    try:
        result = subprocess.run(['uptime', '-p'], capture_output=True, text=True)
        return result.stdout.replace('up ', '').strip()
    except:
        return "unknown"

def get_wifi_status():
    try:
        result = subprocess.run(['iwgetid', '-r'], capture_output=True, text=True, timeout=5)
        if result.returncode == 0 and result.stdout.strip():
            return {"connected": True, "ssid": result.stdout.strip()}
        return {"connected": False, "ssid": None}
    except:
        return {"connected": False, "ssid": None}

def get_full_dashboard_data():
    """Aggregate all dashboard data into one dict"""
    return {
        "timestamp": str(datetime.datetime.now()),
        "system": {
            "cpu_temp": get_cpu_temp(),
            "ram": get_ram_usage(),
            "storage": get_storage_usage(),
            "uptime": get_uptime(),
            "wifi": get_wifi_status()
        },
        "ai": {
            "emotion": get_ai_emotion(),
            "current_model": get_current_model(),
            "current_activity": get_current_activity(),
            "moral_principles": get_moral_guide_count()
        },
        "library": get_library_stats(),
        "bible": get_bible_progress(),
        "social": {
            "people_known": get_people_known()
        },
        "recent_conversations": get_recent_conversations(5)
    }

if __name__ == "__main__":
    import json
    data = get_full_dashboard_data()
    print(json.dumps(data, indent=2))
  
