#!/bin/bash
set -euo pipefail

# Pi AI Sentry unattended installer.
# Run as the normal SSH user from a freshly installed 64-bit Raspberry Pi OS Lite.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${AI_SENTRY_HOME:-$HOME/ai_sentry}"
MIN_FREE_GB="${AI_SENTRY_MIN_FREE_GB:-20}"
RAM_HARD="${AI_SENTRY_RAM_HARD_LIMIT:-92}"
BOOK_LIMIT="${AI_SENTRY_GUTENBERG_MAX_BOOKS:-500}"
BOOK_BATCH="${AI_SENTRY_BOOK_BATCH:-5}"

if [[ "$(id -u)" -eq 0 ]]; then
  echo "Run setup.sh as the normal Pi user, not root." >&2
  exit 1
fi

ARCH="$(dpkg --print-architecture)"
if [[ "$ARCH" != "arm64" ]]; then
  echo "ERROR: This unattended build expects 64-bit ARM (arm64/aarch64). Detected: $ARCH" >&2
  exit 1
fi

TOTAL_RAM_MB="$(awk '/MemTotal:/{print int($2/1024)}' /proc/meminfo)"
if (( TOTAL_RAM_MB < 7000 )); then
  echo "WARNING: This build is tuned for an 8 GB Pi 4. Detected approximately ${TOTAL_RAM_MB} MB RAM."
fi

mkdir -p "$APP_DIR"
rsync -a --delete \
  --exclude '.git/' --exclude 'runtime.env' --exclude 'ai_sentry.db' \
  --exclude 'libraries/' --exclude 'temp/' --exclude 'logs/' --exclude 'venv/' --exclude 'vendor/' \
  "$SCRIPT_DIR/" "$APP_DIR/"
cd "$APP_DIR"

sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
  python3-venv python3-pip python3-opencv python3-pyudev python3-pyaudio \
  espeak-ng sqlite3 git curl wget unzip ffmpeg portaudio19-dev libasound2-dev \
  libatlas-base-dev rsync cmake build-essential libopencv-dev pkg-config \
  v4l-utils

sudo usermod -aG audio "$USER" || true

if ! command -v ollama >/dev/null 2>&1; then
  curl -fsSL https://ollama.com/install.sh | sh
fi

sudo mkdir -p /etc/systemd/system/ollama.service.d
sudo tee /etc/systemd/system/ollama.service.d/override.conf >/dev/null <<'EOF'
[Service]
Environment="OLLAMA_MAX_LOADED_MODELS=1"
Environment="OLLAMA_NUM_PARALLEL=1"
EOF
sudo systemctl daemon-reload
sudo systemctl enable --now ollama.service

for _ in $(seq 1 60); do
  if curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then break; fi
  sleep 2
done
curl -fsS http://127.0.0.1:11434/api/tags >/dev/null

python3 -m venv --system-site-packages "$APP_DIR/venv"
# shellcheck disable=SC1091
source "$APP_DIR/venv/bin/activate"
pip install --upgrade pip
pip install flask flask-socketio requests vosk numpy pyaudio yt-dlp mutagen soundfile

# Install every configured Qwen model once. Ollama is configured to keep only one loaded.
for model in qwen3:0.6b qwen2.5:3b qwen2.5:7b; do
  if ! ollama list | awk 'NR>1 {print $1}' | grep -Fxq "$model"; then
    ollama pull "$model"
  fi
done

# Offline STT and speaker-vector models.
if [[ ! -d "$APP_DIR/vosk-model-small-en-us-0.15" ]]; then
  wget -c --timeout=120 --tries=5 https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip -O "$APP_DIR/vosk-stt.zip"
  unzip -q "$APP_DIR/vosk-stt.zip" -d "$APP_DIR"
  rm -f "$APP_DIR/vosk-stt.zip"
fi
if [[ ! -d "$APP_DIR/vosk-model-spk-0.4" ]]; then
  wget -c --timeout=120 --tries=5 https://alphacephei.com/vosk/models/vosk-model-spk-0.4.zip -O "$APP_DIR/vosk-spk.zip"
  unzip -q "$APP_DIR/vosk-spk.zip" -d "$APP_DIR"
  rm -f "$APP_DIR/vosk-spk.zip"
fi

# Build Qengineering RetinaFace/ArcFace bridge. If compilation is unavailable,
# the system keeps an OpenCV fallback rather than preventing audio/AI operation.
if [[ "${AI_SENTRY_INSTALL_QENGINEERING:-1}" == "1" ]]; then
  if ! "$APP_DIR/tools/qengineering/install.sh"; then
    echo "WARNING: Qengineering build failed. OpenCV identity fallback will remain available."
    echo "         Re-run AI_SENTRY_INSTALL_QENGINEERING=1 ./setup.sh after fixing the build." 
  fi
fi

mkdir -p "$APP_DIR/libraries/books" "$APP_DIR/libraries/music" "$APP_DIR/libraries/wikipedia" "$APP_DIR/libraries/bible" "$APP_DIR/libraries/other" "$APP_DIR/temp" "$APP_DIR/logs"

cat > "$APP_DIR/runtime.env" <<EOF
AI_SENTRY_HOME=$APP_DIR
VOSK_MODEL_PATH=$APP_DIR/vosk-model-small-en-us-0.15
VOSK_SPK_MODEL_PATH=$APP_DIR/vosk-model-spk-0.4
QENGINEERING_FACE_BRIDGE=$APP_DIR/vendor/qengineering-face-recognition/qengineering_face_bridge
AI_SENTRY_RAM_HARD_LIMIT=$RAM_HARD
AI_SENTRY_RAM_MODEL_LIMIT=${AI_SENTRY_RAM_MODEL_LIMIT:-78}
AI_SENTRY_RAM_BACKGROUND_LIMIT=${AI_SENTRY_RAM_BACKGROUND_LIMIT:-72}
AI_SENTRY_RAM_CHECK_INTERVAL=${AI_SENTRY_RAM_CHECK_INTERVAL:-5}
AI_SENTRY_NAME_CACHE_DAYS=${AI_SENTRY_NAME_CACHE_DAYS:-14}
AI_SENTRY_REASONING_MAX_DEPTH=${AI_SENTRY_REASONING_MAX_DEPTH:-4}
AI_SENTRY_REASONING_MAX_RESEARCH_ROUNDS=${AI_SENTRY_REASONING_MAX_RESEARCH_ROUNDS:-3}
AI_SENTRY_REASONING_MAX_PARTS=${AI_SENTRY_REASONING_MAX_PARTS:-4}
AI_SENTRY_WEB_SESSION_TTL=${AI_SENTRY_WEB_SESSION_TTL:-45}
AI_SENTRY_WEB_USER='toby_smith03@proton.me'
AI_SENTRY_WEB_PASSWORD='A3467FBgZQtxA047#\!'
AI_SENTRY_OWNER_ID='toby_smith03@proton.me'
AI_SENTRY_GUTENBERG_MAX_BOOKS=$BOOK_LIMIT
AI_SENTRY_BOOK_BATCH=$BOOK_BATCH
AI_SENTRY_MIN_FREE_GB=$MIN_FREE_GB
AI_SENTRY_IDLE_SECONDS=${AI_SENTRY_IDLE_SECONDS:-30}
AI_SENTRY_LIBRARY_POLL=${AI_SENTRY_LIBRARY_POLL:-5}
EOF

# Refuse to start a huge acquisition if the card is already dangerously full.
FREE_KB="$(df -Pk "$APP_DIR" | awk 'NR==2 {print $4}')"
if (( FREE_KB < MIN_FREE_GB * 1024 * 1024 )); then
  echo "ERROR: Less than ${MIN_FREE_GB} GB free on the target filesystem." >&2
  exit 1
fi

source "$APP_DIR/venv/bin/activate"
python3 -c 'from library_store import init_library_store; init_library_store()'
python3 -c 'from identity_manager import init_identity_db; init_identity_db()'
python3 -m py_compile *.py

sudo tee /etc/systemd/system/ai-sentry-ram-guard.service >/dev/null <<EOF
[Unit]
Description=Pi AI Sentry independent RAM safety guard
After=multi-user.target
Before=ai-sentry.service
[Service]
Type=simple
EnvironmentFile=$APP_DIR/runtime.env
ExecStart=$APP_DIR/ram_guard.sh
Restart=always
RestartSec=2
[Install]
WantedBy=multi-user.target
EOF

sudo tee /etc/systemd/system/ai-sentry.service >/dev/null <<EOF
[Unit]
Description=Pi AI Sentry autonomous offline AI
After=network-online.target ollama.service ai-sentry-ram-guard.service
Wants=network-online.target ollama.service
[Service]
Type=simple
User=$USER
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/runtime.env
Environment=PATH=$APP_DIR/venv/bin:/usr/local/bin:/usr/bin:/bin
ExecStart=$APP_DIR/venv/bin/python3 $APP_DIR/main.py
Restart=always
RestartSec=5
KillSignal=SIGTERM
TimeoutStopSec=30
[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable ai-sentry-ram-guard.service ai-sentry.service
sudo systemctl restart ai-sentry-ram-guard.service
sudo systemctl restart ai-sentry.service

# Give startup a moment, then print useful status. Failure here does not undo the install.
sleep 5
sudo systemctl --no-pager --full status ai-sentry.service || true
sudo systemctl --no-pager --full status ai-sentry-ram-guard.service || true

echo
echo "============================================================"
echo "Pi AI Sentry installation complete."
echo "App: $APP_DIR"
echo "Models: qwen3:0.6b, qwen2.5:3b, qwen2.5:7b"
echo "Gutenberg target: $BOOK_LIMIT books"
echo "Hard RAM reboot: ${RAM_HARD}%"
echo "The AI now starts automatically on every boot."
if [ -f "$APP_DIR/web_login.txt" ]; then echo "Web login credentials: $APP_DIR/web_login.txt (mode 600)"; fi
echo "Raw acquisition happens before library analysis."
echo "============================================================"
