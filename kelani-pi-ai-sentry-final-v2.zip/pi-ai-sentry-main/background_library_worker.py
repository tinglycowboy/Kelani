import os,time,datetime,gc,sqlite3,json
from config import RAM_BACKGROUND_LIMIT_PERCENT, DB_PATH
from library_store import init_library_store,connect,register_document,add_memory
from ram_watchdog import get_ram_usage
from preprocessor import preprocess
from task_orchestrator import init_reasoning_db, run_reasoning_task

IDLE_SECONDS=30
CHUNK=3500

def idle():
    try:
        with connect() as c:
            r=c.execute("SELECT MAX(timestamp) FROM logs WHERE role='user'").fetchone()
        return not r or not r[0] or (datetime.datetime.now()-datetime.datetime.fromisoformat(r[0])).total_seconds()>=IDLE_SECONDS
    except Exception:
        return True

def next_doc():
    with connect() as c:
        return c.execute("SELECT d.id,d.title,d.path,s.kind,q.id FROM analysis_queue q JOIN library_documents d ON d.id=q.document_id JOIN library_sources s ON s.id=d.source_id WHERE q.status='queued' ORDER BY q.priority DESC,q.created_at LIMIT 1").fetchone()

def scan():
    init_library_store()
    roots={'books':os.path.expanduser('~/ai_sentry/libraries/books'),'music':os.path.expanduser('~/ai_sentry/libraries/music'),'bible':os.path.expanduser('~/ai_sentry/libraries/bible'),'other':os.path.expanduser('~/ai_sentry/libraries/other')}
    for kind,root in roots.items():
        for base,_,files in os.walk(root):
            for n in files:
                if n.startswith('.') or n.endswith(('.zip','.part','.tmp')): continue
                p=os.path.join(base,n); e=os.path.splitext(n)[1].lower()
                if kind=='music' and e not in ('.mp3','.wav','.flac','.ogg','.m4a'): continue
                if kind!='music' and e not in ('.txt','.md','.html','.htm','.json','.xml'): continue
                try: register_document(kind,p)
                except Exception as x: print('register',x)

def local_research(query):
    """Offline-only evidence lookup used by background reasoning pauses."""
    evidence=[]
    try:
        from wiki_search import search_wikipedia
        for r in search_wikipedia(query, limit=3):
            evidence.append(f"[Wikipedia] {r.get('title','')}\n{r.get('abstract','')}\nRAW_SOURCE={r.get('source_file','')}")
    except Exception as x: print('library wiki research',x)
    try:
        from knowledge_base import query_knowledge
        for row in query_knowledge(query, 'dictionary', limit=5):
            word,definition,synonyms,antonyms=row
            evidence.append(f"[Dictionary/Thesaurus] {word}: {definition}\nSynonyms: {synonyms}\nAntonyms: {antonyms}")
    except Exception as x: print('library dictionary research',x)
    try:
        with sqlite3.connect(DB_PATH) as c:
            rows=c.execute("""SELECT d.title,d.path,c.text,c.chunk_index
                              FROM library_documents d JOIN library_chunks c ON c.document_id=d.id
                              WHERE d.title LIKE ? OR c.text LIKE ?
                              ORDER BY d.id DESC LIMIT 5""",(f'%{query}%',f'%{query}%')).fetchall()
        for title,path,text,idx in rows:
            evidence.append(f"[Local Library] {title} chunk={idx}\n{text[:3000]}\nRAW_SOURCE={path}")
    except Exception as x: print('library local research',x)
    return "\n\n".join(evidence[:12])

def _logbook_internal(kind,title,path,summary,task_id=None):
    """Persist internal completed analysis; never emit it to chat or TTS."""
    add_memory('library_analysis',summary,title,'library_document',None,.5,{'kind':kind,'raw_source':path,'task_id':task_id,'spoken':False})

def analyze(row):
    did,title,path,kind,qid=row
    with connect() as c:
        c.execute("UPDATE analysis_queue SET status='working',attempts=attempts+1,updated_at=? WHERE id=?",(datetime.datetime.now().isoformat(),qid))
    try:
        if kind=='music':
            from audio_analyzer import analyze_audio_features
            feat=analyze_audio_features(path,duration=30)
            add_memory('music_features',str(feat),title,'library_document',did,.6,feat)
        else:
            with open(path,encoding='utf-8',errors='ignore') as f: text=f.read(CHUNK)
            if not text: raise RuntimeError('empty/unreadable')
            # Same input filter/NLP/routing pipeline as conversational input.
            filtered=preprocess(text)
            if not filtered.get('safe_to_process',True):
                raise RuntimeError('library material rejected by safety filter')
            filtered_text=filtered.get('processed_text') or text
            route=(filtered.get('route') or {}).get('route','ai_general')
            prompt=(f"Analyze this offline library material for Kelani's private knowledge base. "
                    f"This is internal background work, not a user-facing response. "
                    f"Title: {title}. Type: {kind}. Route: {route}.\nMaterial:\n{filtered_text}\n\n"
                    "Return a concise completed analysis containing factual summary, themes, useful observations, "
                    "and searchable concepts. Do not invent facts. Do not address the user. Do not produce speech commands.")
            init_reasoning_db()
            result=run_reasoning_task(
                original_prompt=prompt,
                system_instruction=("You are performing private offline library analysis for Kelani. "
                                    "Never write as if speaking to the user. Produce internal analysis only."),
                context=f"Library source: {path}\nFiltered route: {route}",
                research_callback=local_research,
                socketio=None,
                max_depth=4,
                max_research_rounds=3,
            )
            summary=result.get('result') or filtered_text[:3000]
            add_memory(kind,summary,title,'library_document',did,.5,{'route':route,'task_id':result.get('task_id'),'spoken':False})
            with connect() as c:
                c.execute('INSERT OR IGNORE INTO library_chunks(document_id,chunk_index,start_offset,end_offset,text) VALUES(?,?,?,?,?)',(did,0,0,len(filtered_text),filtered_text))
                cid=c.execute('SELECT id FROM library_chunks WHERE document_id=? AND chunk_index=0',(did,)).fetchone()[0]
                c.execute('INSERT INTO library_analysis(document_id,chunk_id,model,analysis_type,summary,created_at) VALUES(?,?,?,?,?,?)',(did,cid,result.get('model') or 'adaptive','adaptive_filtered',summary,datetime.datetime.now().isoformat()))
            _logbook_internal(kind,title,path,summary,result.get('task_id'))
        with connect() as c:
            c.execute("UPDATE library_documents SET status='analyzed',analyzed_at=? WHERE id=?",(datetime.datetime.now().isoformat(),did))
            c.execute("UPDATE analysis_queue SET status='done',updated_at=? WHERE id=?",(datetime.datetime.now().isoformat(),qid))
    except Exception as x:
        with connect() as c:
            c.execute("UPDATE analysis_queue SET status='queued',last_error=?,updated_at=? WHERE id=?",(str(x),datetime.datetime.now().isoformat(),qid))
        print('library worker',x)
    gc.collect()

def worker_loop(stop_event):
    print('📚 Idle library worker started')
    init_library_store(); init_reasoning_db()
    while not stop_event.is_set():
        try:
            scan(); _,_,ram=get_ram_usage()
            if ram>=RAM_BACKGROUND_LIMIT_PERCENT or not idle(): time.sleep(15); continue
            row=next_doc()
            if row: analyze(row)
            else: time.sleep(60)
        except Exception as x:
            print('library loop',x); time.sleep(30)
