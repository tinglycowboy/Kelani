#!/usr/bin/env python3
import os, sqlite3, datetime
DB_PATH="ai_sentry.db"

def init_bible_db():
    conn=sqlite3.connect(DB_PATH); c=conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS bible_versions (version_code TEXT PRIMARY KEY, file_path TEXT, available INTEGER DEFAULT 0)")
    c.execute("CREATE TABLE IF NOT EXISTS bible_progress (id INTEGER PRIMARY KEY AUTOINCREMENT, book TEXT, chapter INTEGER, verse_start INTEGER, verse_end INTEGER, cycle_number INTEGER DEFAULT 1)")
    c.execute("CREATE TABLE IF NOT EXISTS bible_reflections (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT, reference TEXT, versions TEXT, about_god TEXT, about_self TEXT, about_others TEXT, characters TEXT, cross_reference TEXT, moral_added TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS moral_principles (id INTEGER PRIMARY KEY AUTOINCREMENT, principle TEXT UNIQUE, source TEXT, created TEXT, revised TEXT)")
    conn.commit(); conn.close()

def download_bible_versions():
    # Deliberately does not fetch copyrighted translations automatically. Local files can be registered here.
    init_bible_db(); return []

def get_available_versions():
    init_bible_db(); conn=sqlite3.connect(DB_PATH); rows=conn.execute("SELECT version_code,file_path FROM bible_versions WHERE available=1").fetchall(); conn.close(); return {r[0]:r[1] for r in rows}

def get_next_passage(): return None
def get_cross_reference_passage(*args, **kwargs): return {}
def advance_progress(*args, **kwargs): return None
def save_reflection(*args, **kwargs): return None
def add_moral_principle(principle, source="AI"):
    init_bible_db(); conn=sqlite3.connect(DB_PATH); conn.execute("INSERT OR IGNORE INTO moral_principles(principle,source,created) VALUES(?,?,?)",(principle,source,str(datetime.datetime.now()))); conn.commit(); conn.close()
def revise_moral_principle(*args, **kwargs): return None
def get_moral_guide():
    init_bible_db(); conn=sqlite3.connect(DB_PATH); rows=conn.execute("SELECT principle,source FROM moral_principles ORDER BY id DESC LIMIT 50").fetchall(); conn.close()
    if rows: return [{"principle":r[0],"source":r[1]} for r in rows]
    return [{"principle":"Be kind and avoid unnecessary harm.","source":"default"},{"principle":"Seek truth and represent uncertainty honestly.","source":"default"},{"principle":"Respect people and their boundaries.","source":"default"}]

def get_passage_from_version(version_code, book, chapter, v_start, v_end):
    versions=get_available_versions(); path=versions.get(version_code)
    if not path or not os.path.exists(path): return None
    try:
        with open(path,encoding='utf-8',errors='ignore') as f: content=f.read()
        marker=f"{book.title()} {chapter}:{v_start}"
        idx=content.find(marker)
        return content[idx:idx+1500] if idx>=0 else None
    except Exception as e: return f"[Error reading {version_code}: {e}]"
