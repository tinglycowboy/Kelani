#!/usr/bin/env python3
"""Local single-session web authentication for Kelani."""
import hashlib, os, secrets, sqlite3, time
from config import DB_PATH, APP_DIR

SESSION_TTL = int(os.environ.get("AI_SENTRY_WEB_SESSION_TTL", "45"))
USER = os.environ.get("AI_SENTRY_WEB_USER", "owner")
OWNER_ID = os.environ.get("AI_SENTRY_OWNER_ID", "owner")
SCHEMA = """
CREATE TABLE IF NOT EXISTS web_accounts(user TEXT PRIMARY KEY, password_hash TEXT NOT NULL, owner_id TEXT NOT NULL, created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS web_sessions(session_id TEXT PRIMARY KEY, user TEXT NOT NULL, owner_id TEXT NOT NULL, created_at REAL NOT NULL, last_seen REAL NOT NULL, reopen_key_hash TEXT);
"""

def _db():
    c=sqlite3.connect(DB_PATH, timeout=30); c.execute("PRAGMA journal_mode=WAL"); return c

def _hash(password, salt=None):
    salt=salt or secrets.token_bytes(16)
    digest=hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 240000)
    return f"pbkdf2$240000${salt.hex()}${digest.hex()}"

def _verify(password, stored):
    try:
        _, rounds, salt_hex, digest=stored.split("$")
        got=hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), int(rounds)).hex()
        return secrets.compare_digest(got, digest)
    except Exception: return False

def init_auth_db():
    with _db() as c: c.executescript(SCHEMA)

def ensure_account():
    init_auth_db()
    configured_password=os.environ.get("AI_SENTRY_WEB_PASSWORD")
    generated=False
    with _db() as c:
        row=c.execute("SELECT user,password_hash FROM web_accounts WHERE user=?",(USER,)).fetchone()
        if row:
            # If an explicit password is configured, make the configured account deterministic
            # across reinstalls/restarts without ever storing the plaintext password in SQLite.
            if configured_password:
                c.execute("UPDATE web_accounts SET password_hash=?,owner_id=? WHERE user=?",
                          (_hash(configured_password),OWNER_ID,USER))
                password=configured_password
            else:
                password=None
        else:
            password=configured_password or secrets.token_urlsafe(16)
            generated=not bool(configured_password)
            c.execute("INSERT INTO web_accounts VALUES(?,?,?,?)",(USER,_hash(password),OWNER_ID,time.time()))
    try:
        path=os.path.join(APP_DIR,"web_login.txt")
        if password and (configured_password or generated or not os.path.exists(path)):
            with open(path,"w") as f: f.write(f"Username: {USER}\nPassword: {password}\n")
            os.chmod(path,0o600)
    except Exception: pass
    return USER,password

def authenticate(user,password):
    init_auth_db()
    with _db() as c:
        row=c.execute("SELECT user,password_hash,owner_id FROM web_accounts WHERE user=?",(user,)).fetchone()
    if not row or not _verify(password,row[1]): return None
    return {"user":row[0],"owner_id":row[2]}

def create_session(account):
    init_auth_db(); sid=secrets.token_urlsafe(32); now=time.time(); reopen=secrets.token_urlsafe(32)
    with _db() as c:
        c.execute("UPDATE web_sessions SET last_seen=0 WHERE last_seen>?",(now-SESSION_TTL,))
        c.execute("INSERT INTO web_sessions VALUES(?,?,?,?,?,?)",(sid,account["user"],account["owner_id"],now,now,hashlib.sha256(reopen.encode()).hexdigest()))
    return sid,reopen

def validate_session(session_id, touch=True):
    if not session_id: return None
    now=time.time()
    with _db() as c:
        row=c.execute("SELECT session_id,user,owner_id,last_seen FROM web_sessions WHERE session_id=?",(session_id,)).fetchone()
        if not row or now-row[3]>SESSION_TTL: return None
        if touch: c.execute("UPDATE web_sessions SET last_seen=? WHERE session_id=?",(now,session_id))
        return {"session_id":row[0],"user":row[1],"owner_id":row[2]}

def close_session(session_id):
    with _db() as c: c.execute("DELETE FROM web_sessions WHERE session_id=?",(session_id,))

def invalidate_other_sessions(session_id):
    with _db() as c: c.execute("DELETE FROM web_sessions WHERE session_id!=?",(session_id,))
