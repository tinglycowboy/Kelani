#!/usr/bin/env python3
"""
Sequential library acquisition + resumable analysis scheduler.

Phase 1: acquire raw files only while the system is idle.
Phase 2: after ALL configured raw acquisition jobs report complete, analyze one
item at a time. Analysis is checkpointed and yields immediately to user/stimuli.

New streams can be registered in LIBRARY_STREAMS without changing the scheduler.
"""
import os, time, json, datetime, subprocess, threading, gc, sqlite3
from config import APP_DIR, LIBRARIES_DIR, RAM_BACKGROUND_LIMIT_PERCENT
from library_store import connect, init_library_store, register_document, add_memory

IDLE_SECONDS = int(os.environ.get("AI_SENTRY_IDLE_SECONDS", "30"))
POLL_SECONDS = int(os.environ.get("AI_SENTRY_LIBRARY_POLL", "5"))
CHUNK_CHARS = int(os.environ.get("AI_SENTRY_LIBRARY_CHUNK", "3000"))

# A stream is a logical library, not necessarily a single file.
# "required=1" means acquisition must finish before analysis phase can start.
LIBRARY_STREAMS = [
    ("music", "Music", 1, 35),
    ("books", "Books", 1, 30),
    ("wikipedia", "Wikipedia", 1, 20),
    ("bible", "Religious texts", 1, 8),
    ("other", "Reference/other", 1, 7),
]

def init_scheduler():
    init_library_store()
    with connect() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS library_streams(
            id INTEGER PRIMARY KEY,
            kind TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            required INTEGER DEFAULT 1,
            base_weight REAL DEFAULT 1,
            acquisition_status TEXT DEFAULT 'pending',
            acquisition_progress REAL DEFAULT 0,
            acquisition_message TEXT DEFAULT '',
            updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS library_scheduler(
            id INTEGER PRIMARY KEY CHECK(id=1),
            phase TEXT NOT NULL DEFAULT 'acquire',
            active_stream TEXT,
            active_document INTEGER,
            last_action TEXT,
            updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS library_item_scores(
            document_id INTEGER PRIMARY KEY,
            novelty REAL DEFAULT .5,
            usefulness REAL DEFAULT .5,
            user_interest REAL DEFAULT .5,
            completeness REAL DEFAULT 0,
            age REAL DEFAULT .5,
            priority REAL DEFAULT .5,
            reason TEXT DEFAULT '',
            updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS analysis_checkpoints(
            document_id INTEGER PRIMARY KEY,
            stage TEXT DEFAULT 'start',
            cursor INTEGER DEFAULT 0,
            partial_result TEXT DEFAULT '',
            updated_at TEXT,
            FOREIGN KEY(document_id) REFERENCES library_documents(id)
        );
        """)
        now=datetime.datetime.now().isoformat()
        for kind,name,required,weight in LIBRARY_STREAMS:
            c.execute("""INSERT INTO library_streams(kind,name,required,base_weight,updated_at)
                         VALUES(?,?,?,?,?) ON CONFLICT(kind) DO UPDATE SET
                         name=excluded.name,required=excluded.required,base_weight=excluded.base_weight,
                         updated_at=excluded.updated_at""",
                      (kind,name,required,weight,now))
        c.execute("""INSERT OR IGNORE INTO library_scheduler(id,phase,updated_at)
                     VALUES(1,'acquire',?)""",(now,))

def system_idle():
    """User/stimulus idle check. Uses the latest user log and AI work flag."""
    try:
        with connect() as c:
            row=c.execute("SELECT MAX(timestamp) FROM logs WHERE role='user'").fetchone()
        if row and row[0]:
            try:
                if (datetime.datetime.now()-datetime.datetime.fromisoformat(row[0])).total_seconds() < IDLE_SECONDS:
                    return False
            except ValueError:
                pass
    except Exception:
        pass
    # main.py may set this environment-independent file flag during active work.
    return not os.path.exists(os.path.join(APP_DIR, ".ai_busy"))

def ram_ok():
    try:
        with open("/proc/meminfo") as f:
            vals={line.split(":")[0]:int(line.split()[1]) for line in f if ":" in line}
        total=vals["MemTotal"]; avail=vals["MemAvailable"]
        used=(total-avail)/total*100
        return used < RAM_BACKGROUND_LIMIT_PERCENT
    except Exception:
        return True

def set_phase(phase, stream=None, doc=None, action=""):
    now=datetime.datetime.now().isoformat()
    with connect() as c:
        c.execute("""UPDATE library_scheduler SET phase=?,active_stream=?,active_document=?,
                     last_action=?,updated_at=? WHERE id=1""",
                  (phase,stream,doc,action,now))

def acquisition_complete():
    with connect() as c:
        rows=c.execute("SELECT kind FROM library_streams WHERE required=1 AND acquisition_status!='complete'").fetchall()
        return len(rows)==0

def scan_raw_libraries():
    """Register completed raw files. Never queues analysis during acquisition."""
    roots = {
        "books": os.path.join(LIBRARIES_DIR,"books"),
        "music": os.path.join(LIBRARIES_DIR,"music"),
        "wikipedia": os.path.join(LIBRARIES_DIR,"wikipedia"),
        "bible": os.path.join(LIBRARIES_DIR,"bible"),
        "other": os.path.join(LIBRARIES_DIR,"other"),
    }
    exts={
        "music": {".mp3",".wav",".flac",".ogg",".m4a"},
        "books": {".txt",".md",".epub"},
        "wikipedia": {".txt",".xml",".json"},
        "bible": {".txt",".json",".xml"},
        "other": {".txt",".md",".json",".csv",".xml",".pdf"},
    }
    found={}
    for kind,root in roots.items():
        count=0
        for base,_,files in os.walk(root):
            for n in files:
                if n.startswith(".") or n.endswith((".part",".tmp",".crdownload")):
                    continue
                p=os.path.join(base,n)
                if os.path.splitext(n)[1].lower() not in exts[kind]:
                    continue
                try:
                    register_document(kind,p,queue=False)
                    count+=1
                except Exception as e:
                    print("library registration:",e)
        found[kind]=count
    return found

def score_documents():
    """Re-score candidates so the next stream/item is chosen from evidence."""
    with connect() as c:
        docs=c.execute("""SELECT d.id,d.status,s.kind,d.size_bytes,
                          COALESCE(q.status,'none')
                          FROM library_documents d JOIN library_sources s ON s.id=d.source_id
                          LEFT JOIN analysis_queue q ON q.document_id=d.id
                          WHERE d.status!='analyzed'""").fetchall()
        for did,status,kind,size,qstatus in docs:
            row=c.execute("SELECT COUNT(*) FROM library_chunks WHERE document_id=?",(did,)).fetchone()
            completeness=min(1.0,(row[0] or 0)/10.0)
            # Bias toward unfinished work while preserving stream weights.
            weight=next((w for k,_,_,w in LIBRARY_STREAMS if k==kind),5)
            novelty=1.0 if qstatus in ("none","queued") else .2
            usefulness=min(1.0,weight/35.0)
            priority=max(0.01, .35*novelty+.30*usefulness+.25*(1-completeness)+.10)
            reason=f"{kind}: unfinished={1-completeness:.2f}, usefulness={usefulness:.2f}"
            c.execute("""INSERT INTO library_item_scores(document_id,novelty,usefulness,
                         user_interest,completeness,age,priority,reason,updated_at)
                         VALUES(?,?,?,?,?,?,?,?,?)
                         ON CONFLICT(document_id) DO UPDATE SET
                         novelty=excluded.novelty,usefulness=excluded.usefulness,
                         completeness=excluded.completeness,priority=excluded.priority,
                         reason=excluded.reason,updated_at=excluded.updated_at""",
                      (did,novelty,usefulness,.5,completeness,.5,priority,reason,
                       datetime.datetime.now().isoformat()))

def next_scored_document():
    with connect() as c:
        return c.execute("""SELECT d.id,d.title,d.path,s.kind,q.id
                            FROM library_item_scores x
                            JOIN library_documents d ON d.id=x.document_id
                            JOIN library_sources s ON s.id=d.source_id
                            LEFT JOIN analysis_queue q ON q.document_id=d.id
                            WHERE d.status!='analyzed'
                            ORDER BY x.priority DESC, x.updated_at ASC LIMIT 1""").fetchone()

def checkpoint(did,stage,cursor,partial=""):
    with connect() as c:
        c.execute("""INSERT INTO analysis_checkpoints(document_id,stage,cursor,partial_result,updated_at)
                     VALUES(?,?,?,?,?) ON CONFLICT(document_id) DO UPDATE SET
                     stage=excluded.stage,cursor=excluded.cursor,partial_result=excluded.partial_result,
                     updated_at=excluded.updated_at""",
                  (did,stage,cursor,partial,datetime.datetime.now().isoformat()))

def analyze_one(row, stop_event):
    did,title,path,kind,qid=row
    with connect() as c:
        c.execute("""INSERT INTO analysis_queue(document_id,priority,status,created_at,updated_at)
                     VALUES(?,50,'working',?,?) ON CONFLICT(document_id) DO UPDATE SET
                     status='working',updated_at=?""",
                  (did,datetime.datetime.now().isoformat(),datetime.datetime.now().isoformat()))
    try:
        if kind=="music":
            from audio_analyzer import analyze_audio_features
            # Audio stage is atomic and short; it can be retried safely.
            checkpoint(did,"audio_features",0)
            features=analyze_audio_features(path,duration=30)
            if not system_idle() or not ram_ok():
                checkpoint(did,"audio_features",1,json.dumps(features))
                return False
            # Vosk transcription is optional if the configured mic model exists.
            transcript=""
            try:
                from mic_module import transcribe_audio
                wav=os.path.join(APP_DIR,"temp",f"library_{did}.wav")
                subprocess.run(["ffmpeg","-y","-i",path,"-t","30","-ar","16000","-ac","1","-f","s16le",wav],
                               stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True,timeout=120)
                transcript,_=transcribe_audio(wav)
                if os.path.exists(wav): os.remove(wav)
            except Exception as e:
                transcript=f"[transcription unavailable: {e}]"
            checkpoint(did,"music_reasoning",1)
            if not system_idle() or not ram_ok():
                return False
            from model_manager import generate
            prompt=("Analyze this song using BOTH independent streams.\n"
                    f"Audio features: {json.dumps(features,default=str)}\n"
                    f"Speech/transcription stream: {transcript[:6000]}\n"
                    "Separate observable evidence from interpretation. Give themes, musical observations, "
                    "and an opinion. Do not invent lyrics or facts.")
            result=generate(prompt,model=None,num_predict=450,timeout=180,keep_alive="2m")
            add_memory("music_opinion",result or "",title,"library_document",did,.7,
                       {"audio_features":features,"transcript":transcript})
            with connect() as c:
                c.execute("""INSERT INTO library_analysis(document_id,model,analysis_type,summary,opinion,tags,confidence,created_at)
                             VALUES(?,?,?,?,?,?,?,?)""",
                          (did,"selected","music_full",result or "",result or "",
                           "music,audio,transcription",.7,datetime.datetime.now().isoformat()))
        else:
            with connect() as c:
                cp=c.execute("SELECT cursor,partial_result FROM analysis_checkpoints WHERE document_id=?",(did,)).fetchone()
            cursor=cp[0] if cp else 0
            partial=cp[1] if cp else ""
            with open(path,"r",encoding="utf-8",errors="ignore") as f:
                f.seek(cursor); chunk=f.read(CHUNK_CHARS); newcursor=f.tell()
            if not chunk:
                with connect() as c:
                    c.execute("UPDATE library_documents SET status='analyzed',analyzed_at=? WHERE id=?",
                              (datetime.datetime.now().isoformat(),did))
                    c.execute("DELETE FROM analysis_queue WHERE document_id=?",(did,))
                return True
            if not system_idle() or not ram_ok(): return False
            from model_manager import generate
            result=generate(f"Analyze this {kind} library chunk from '{title}'. Extract facts, themes, "
                            f"connections and useful observations. Do not invent facts.\n{chunk}",
                            model=None,num_predict=350,timeout=180,keep_alive="2m")
            with connect() as c:
                idx=c.execute("SELECT COALESCE(MAX(chunk_index),-1)+1 FROM library_chunks WHERE document_id=?",(did,)).fetchone()[0]
                c.execute("""INSERT OR REPLACE INTO library_chunks(document_id,chunk_index,start_offset,end_offset,text)
                             VALUES(?,?,?,?,?)""",(did,idx,cursor,newcursor,chunk))
                cid=c.execute("SELECT id FROM library_chunks WHERE document_id=? AND chunk_index=?",(did,idx)).fetchone()[0]
                c.execute("""INSERT INTO library_analysis(document_id,chunk_id,model,analysis_type,summary,opinion,confidence,created_at)
                             VALUES(?,?,?,?,?,?,?,?)""",
                          (did,cid,"selected","chunk",result or "", "",.6,datetime.datetime.now().isoformat()))
            add_memory(kind,result or "",title,"library_document",did,.55)
            checkpoint(did,"chunk",newcursor,partial)
            if newcursor >= os.path.getsize(path):
                with connect() as c:
                    c.execute("UPDATE library_documents SET status='analyzed',analyzed_at=? WHERE id=?",
                              (datetime.datetime.now().isoformat(),did))
                    c.execute("DELETE FROM analysis_queue WHERE document_id=?",(did,))
                return True
        with connect() as c:
            c.execute("DELETE FROM analysis_queue WHERE document_id=?",(did,))
        return True
    except Exception as e:
        with connect() as c:
            c.execute("UPDATE analysis_queue SET status='queued',last_error=?,updated_at=? WHERE document_id=?",
                      (str(e),datetime.datetime.now().isoformat(),did))
        print("library analysis:",e)
        return False
    finally:
        gc.collect()

def run_download_step():
    """Download only during idle. Each downloader must be resumable and non-analysis."""
    # These are intentionally invoked one stream at a time.
    with connect() as c:
        rows=c.execute("SELECT kind FROM library_streams WHERE required=1 AND acquisition_status!='complete' ORDER BY id").fetchall()
    if not rows: return True
    kind=rows[0][0]
    set_phase("acquire",kind,action="download")
    try:
        if kind=="music":
            from download_fma import download_fma_small
            complete=download_fma_small()
        elif kind=="books":
            from download_gutenberg import download_batch
            # Acquisition is resumable and yields after each batch.
            download_batch(batch_size=int(os.environ.get("AI_SENTRY_BOOK_BATCH","5")))
            from download_gutenberg import acquisition_complete
            complete=acquisition_complete()
        elif kind=="wikipedia":
            from download_wiki import download_wikipedia
            complete=download_wikipedia()
        elif kind=="bible":
            from download_reference_data import download_bibles
            complete=download_bibles()
        else:
            from download_reference_data import download_other
            complete=download_other()
        if complete is True:
            with connect() as c:
                c.execute("UPDATE library_streams SET acquisition_status='complete',acquisition_progress=100,updated_at=? WHERE kind=?",
                          (datetime.datetime.now().isoformat(),kind))
        return True
    except Exception as e:
        print("acquisition",kind,e)
        with connect() as c:
            c.execute("UPDATE library_streams SET acquisition_message=?,updated_at=? WHERE kind=?",
                      (str(e),datetime.datetime.now().isoformat(),kind))
        return False

def worker_loop(stop_event):
    print("📚 Sequential library scheduler started")
    init_scheduler()
    while not stop_event.is_set():
        try:
            scan_raw_libraries()
            if not system_idle() or not ram_ok():
                time.sleep(POLL_SECONDS); continue
            if not acquisition_complete():
                # No analysis is allowed in phase 1.
                run_download_step()
                time.sleep(POLL_SECONDS)
                continue
            # Phase 2: score all unfinished information and pick exactly one item.
            set_phase("analyze",action="score")
            score_documents()
            row=next_scored_document()
            if row:
                set_phase("analyze",row[3],row[0],"analyzing")
                analyze_one(row,stop_event)
            else:
                # Nothing left: rescore later when new raw material appears.
                time.sleep(30)
        except Exception as e:
            print("library scheduler:",e)
            time.sleep(15)
        gc.collect()
