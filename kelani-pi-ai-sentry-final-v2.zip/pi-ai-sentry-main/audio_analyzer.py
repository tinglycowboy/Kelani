#!/usr/bin/env python3
"""Optional lightweight music feature extraction. Librosa is used only if installed."""
import os, subprocess, tempfile, wave
import numpy as np

def _fallback_features(file_path, duration=30):
    try:
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
            wav_path=tmp.name
        subprocess.run(["ffmpeg","-v","error","-y","-i",file_path,"-t",str(duration),"-ar","22050","-ac","1","-f","wav",wav_path], check=True, capture_output=True)
        with wave.open(wav_path,'rb') as wf:
            raw=wf.readframes(wf.getnframes()); sr=wf.getframerate()
        os.unlink(wav_path)
        y=np.frombuffer(raw,dtype=np.int16).astype(np.float32)/32768.0
        if y.size == 0: raise ValueError('empty audio')
        rms=float(np.sqrt(np.mean(y*y)))
        zcr=float(np.mean(np.abs(np.diff(np.signbit(y).astype(np.int8)))))
        return {"bpm": None,"key":"Unknown","energy":"High" if rms>0.15 else "Medium" if rms>0.08 else "Low","brightness":"Unknown","mood_hint":"Upbeat/Agitated" if zcr>0.1 else "Calm/Mellow","raw_features":f"Energy RMS: {rms:.3f}, Zero-crossing rate: {zcr:.3f}"}
    except Exception as e:
        return {"raw_features":f"Analysis failed: {e}"}

def analyze_audio_features(file_path, duration=30):
    try:
        import librosa
        y, sr=librosa.load(file_path,duration=duration,sr=22050)
        tempo,_=librosa.beat.beat_track(y=y,sr=sr); bpm=float(np.asarray(tempo).reshape(-1)[0])
        chroma=librosa.feature.chroma_stft(y=y,sr=sr); keys=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']; key=keys[int(np.mean(chroma,axis=1).argmax())]
        rms=librosa.feature.rms(y=y); energy=float(np.mean(rms)); energy_level='High' if energy>0.15 else 'Medium' if energy>0.08 else 'Low'
        centroid=librosa.feature.spectral_centroid(y=y,sr=sr); brightness=float(np.mean(centroid)); brightness_level='Bright' if brightness>3000 else 'Warm' if brightness>1500 else 'Dark'
        zcr=float(np.mean(librosa.feature.zero_crossing_rate(y))); mood_hint='Upbeat/Agitated' if zcr>0.1 else 'Calm/Mellow'
        return {"bpm":round(bpm,1),"key":key,"energy":energy_level,"brightness":brightness_level,"mood_hint":mood_hint,"raw_features":f"BPM: {bpm:.1f}, Key: {key}, Energy: {energy_level}, Brightness: {brightness_level}"}
    except ImportError:
        return _fallback_features(file_path,duration)
    except Exception as e:
        print(f"Audio analysis fallback for {file_path}: {e}")
        return _fallback_features(file_path,duration)

if __name__ == '__main__': print('Audio analyzer ready.')
