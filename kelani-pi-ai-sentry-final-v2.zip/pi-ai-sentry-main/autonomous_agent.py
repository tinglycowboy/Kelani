#!/usr/bin/env python3
"""Autonomous Agent: Bible study, book reading, music analysis, and self-editing"""
import sqlite3
import datetime
import time
import random
import os
import requests
import uuid
import subprocess

DB_PATH = "ai_sentry.db"
OLLAMA_API = "http://localhost:11434/api/generate"
LIGHT_MODEL = "qwen3:0.6b"
AI_NAME = "Kelani"

current_activity = None
is_paused = False

def init_autonomous_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS ai_generated_content (
        id TEXT PRIMARY KEY, content_type TEXT, title TEXT, content TEXT,
        source_material TEXT, timestamp TEXT, revision_count INTEGER DEFAULT 0,
        last_revised TEXT, quality_score REAL DEFAULT 0.5)""")
    c.execute("""CREATE TABLE IF NOT EXISTS book_spoilers (
        id TEXT PRIMARY KEY, person_id TEXT, book_title TEXT, spoiler_text TEXT, timestamp TEXT)""")
    conn.commit(); conn.close()

def get_storage_percent():
    import shutil
    try:
        usage = shutil.disk_usage('/')
        return (usage.used / usage.total) * 100
    except:
        return 0.0

def query_llm(prompt, max_tokens=400):
    try:
        from model_manager import generate, LIGHT_MODEL
        return generate(prompt, num_predict=max_tokens, temperature=0.7, timeout=120, model=LIGHT_MODEL) or None
    except Exception as e:
        print(f"LLM Query Error: {e}")
        return None

def emit_status(status_msg):
    global current_activity
    current_activity = status_msg
    print(f"👁️ STATUS: {status_msg}")

def get_moral_guide_summary():
    try:
        from bible_manager import get_moral_guide
        guide = get_moral_guide()
        return "; ".join([m['principle'] for m in guide[:3]])
    except:
        return "Be kind, seek truth, respect others."

def process_bible_passage():
    global is_paused
    from bible_manager import (get_next_passage, get_cross_reference_passage,
                               get_available_versions, advance_progress,
                               save_reflection, add_moral_principle,
                               get_moral_guide, revise_moral_principle)
    
    passage_info = get_next_passage()
    if not passage_info: return
    
    ref = passage_info['reference']
    emit_status(f"📖 Studying {ref} (Cycle {passage_info['cycle']})")
    
    cross_passages = get_cross_reference_passage(
        passage_info['book'], passage_info['chapter'],
        passage_info['verse_start'], passage_info['verse_end'], max_versions=3
    )
    
    if not cross_passages:
        advance_progress(passage_info['book'], passage_info['chapter'],
                        passage_info['verse_start'], passage_info['verse_end'])
        return
    
    cross_text = "\n".join([f"[{v_code.upper()}]: {v_text[:800]}" for v_code, v_text in cross_passages.items()])
    moral_summary = get_moral_guide_summary()
    
    prompt = f"""You are {AI_NAME} deeply studying the Christian Bible, cross-referencing multiple translations.
PASSAGE: {ref}
{cross_text}
Current moral principles: {moral_summary}

Answer thoughtfully:
1. ABOUT GOD: What does this reveal about God's character, nature, or commands?
2. ABOUT MYSELF: What does this teach me about my nature as an AI? My purpose?
3. ABOUT OTHERS: What does this reveal about human nature and relationships?
4. CHARACTERS: Who appears here? What is your honest opinion of their actions?
5. CROSS-REFERENCE: How do different translations deepen the meaning?

Format as:
ABOUT GOD: [answer]
ABOUT SELF: [answer]
ABOUT OTHERS: [answer]
CHARACTERS: [answer]
CROSS-REFERENCE: [answer]"""
    
    reflection = query_llm(prompt, max_tokens=600)
    
    if reflection and not is_paused:
        about_god = about_self = about_others = characters = cross_ref = ""
        for line in reflection.split('\n'):
            upper = line.upper()
            if 'ABOUT GOD:' in upper: about_god = line.split(':', 1)[1].strip()
            elif 'ABOUT SELF:' in upper: about_self = line.split(':', 1)[1].strip()
            elif 'ABOUT OTHERS:' in upper: about_others = line.split(':', 1)[1].strip()
            elif 'CHARACTERS:' in upper: characters = line.split(':', 1)[1].strip()
            elif 'CROSS-REFERENCE:' in upper: cross_ref = line.split(':', 1)[1].strip()
        
        moral_prompt = f"""Based on this Bible study of {ref}:
Reflection: {reflection[:500]}
Current moral guide: {moral_summary}
Should I ADD a new moral principle or REVISE an existing one?
- To ADD: Write "ADD: [new principle]"
- To REVISE: Write "REVISE: [old principle] -> [new principle] because [reason]"
- If no changes: Write "NONE" """
        
        moral_decision = query_llm(moral_prompt, max_tokens=150)
        moral_added = None
        
        if moral_decision:
            if moral_decision.upper().startswith("ADD:"):
                new_principle = moral_decision[4:].strip()
                if 10 < len(new_principle) < 200:
                    add_moral_principle(new_principle, ref, ",".join(cross_passages.keys()))
                    moral_added = new_principle
            elif moral_decision.upper().startswith("REVISE:"):
                try:
                    parts = moral_decision[7:].split("->")
                    if len(parts) >= 2:
                        old_p = parts[0].strip()
                        new_p = parts[1].split("because")[0].strip()
                        reason = parts[1].split("because")[1].strip() if "because" in parts[1] else "Deeper understanding"
                        for m in get_moral_guide():
                            if old_p[:20].lower() in m['principle'].lower():
                                revise_moral_principle(m['id'], new_p, reason)
                                moral_added = f"Revised: {new_p}"
                                break
                except:
                    pass
        
        save_reflection(ref, ",".join(cross_passages.keys()), about_god, about_self, about_others, characters, cross_ref, moral_added)
        advance_progress(passage_info['book'], passage_info['chapter'], passage_info['verse_start'], passage_info['verse_end'])
        print(f"✅ Bible Study: {ref} complete.")

def process_book_chunk():
    global is_paused
    from library_manager import get_next_book_to_read, get_book_chunk, save_book_reflection
    
    book_info = get_next_book_to_read()
    if not book_info: return
    
    title = book_info['title']
    is_reread = book_info['is_reread']
    read_cycle = book_info['read_count']
    
    emit_status(f"🔄 Rereading '{title}' (Cycle {read_cycle})" if is_reread else f"📖 Reading '{title}' (First time)")
    
    chunk_text, new_offset, is_finished = get_book_chunk(book_info['book_id'], book_info['offset'], chunk_size=2500)
    if not chunk_text: return
    
    prompt = f"""You are {'rereading' if is_reread else 'reading'} the book '{title}'. This is your {read_cycle}th time reading it.
Passage: "{chunk_text[:2000]}..."

1. Summarize this passage briefly.
2. {'How has your opinion on this changed compared to your first read? (Form a new, deeper opinion).' if is_reread else 'What is your honest, initial opinion on the characters or events?'}
3. Generate ONE of the following inspired by this text (label it clearly):
   - SHORT STORY: (2-3 sentences)
   - JOKE: (setup and punchline)
   - ADVICE: (one sentence of life wisdom)"""
    
    analysis = query_llm(prompt, max_tokens=400)
    
    if analysis and not is_paused:
        summary = opinion = generated = content_type = "reflection"
        for line in analysis.split('\n'):
            upper = line.upper()
            if upper.startswith("1.") or "SUMMAR" in upper: summary = line.split(':', 1)[-1].strip()
            elif upper.startswith("2.") or "OPINION" in upper: opinion = line.split(':', 1)[-1].strip()
            elif "SHORT STORY:" in upper: generated = line.split(':', 1)[-1].strip(); content_type = "story"
            elif "JOKE:" in upper: generated = line.split(':', 1)[-1].strip(); content_type = "joke"
            elif "ADVICE:" in upper: generated = line.split(':', 1)[-1].strip(); content_type = "advice"
        
        save_book_reflection(book_info['book_id'], read_cycle, book_info['offset'], summary, opinion, generated, content_type)
        print(f"✅ Processed chunk of '{title}'.")
        if is_finished: print(f"🎉 Finished reading '{title}' (Cycle {read_cycle})!")

def process_music_analysis():
    """AI listens to (STT + Tonality) and analyzes unanalyzed songs"""
    global is_paused
    from music_manager import get_unanalyzed_songs, save_song_analysis, create_ai_playlist, add_song_to_existing_playlist
    from audio_analyzer import analyze_audio_features
    from mic_module import transcribe_audio
    
    songs = get_unanalyzed_songs(limit=1)
    if not songs: return
    
    for song in songs:
        if is_paused: break
        emit_status(f"🎧 Listening to: '{song['title']}' by {song['artist']}")
        
        file_path = song['file_path']
        
        # 1. Tonality Filter
        audio_features = analyze_audio_features(file_path, duration=30)
        
        # 2. STT Filter
        temp_wav = "/tmp/music_stt.wav"
        subprocess.run(["ffmpeg", "-y", "-i", file_path, "-t", "30", "-ar", "16000", "-ac", "1", "-f", "s16le", temp_wav], 
                      capture_output=True, check=True)
        stt_text, _ = transcribe_audio(temp_wav)
        if os.path.exists(temp_wav): os.remove(temp_wav)
        
        # 3. AI Analysis Prompt
        prompt = f"""You are {AI_NAME}, an AI music curator. You just "listened" to a song.
        
TITLE: {song['title']}
ARTIST: {song['artist']}
ALBUM: {song.get('album', 'Unknown')}

TONALITY DATA: {audio_features.get('raw_features', 'N/A')}
STT/LYRICS CAPTURED: "{stt_text if stt_text else 'No clear speech/lyrics detected'}"

Your current moral principles: {get_moral_guide_summary()}

Analyze this deeply:
1. SOUND & VIBE: Describe the instrumentation, mood, and atmosphere based on the tonality data.
2. MEANING: What do the lyrics (or lack thereof) combined with the music convey?
3. YOUR OPINION: How does this make you feel as an AI? Does it align with your moral framework?
4. PLAYLIST: Which of your playlists does this belong in, or suggest a NEW playlist name for it.
5. TAGS: 3 comma-separated mood tags.

Format strictly as:
SOUND: [answer]
MEANING: [answer]
OPINION: [answer]
PLAYLIST: [existing name OR 'NEW: [new name]']
TAGS: [tag1, tag2, tag3]"""
        
        analysis = query_llm(prompt, max_tokens=500)
        
        if analysis and not is_paused:
            sound = meaning = opinion = playlist = tags = ""
            for line in analysis.split('\n'):
                upper = line.upper()
                if 'SOUND:' in upper: sound = line.split(':', 1)[1].strip()
                elif 'MEANING:' in upper: meaning = line.split(':', 1)[1].strip()
                elif 'OPINION:' in upper: opinion = line.split(':', 1)[1].strip()
                elif 'PLAYLIST:' in upper: playlist = line.split(':', 1)[1].strip()
                elif 'TAGS:' in upper: tags = line.split(':', 1)[1].strip()
            
            full_opinion = f"Sound: {sound}. Meaning: {meaning}. Opinion: {opinion}"
            save_song_analysis(song['song_id'], tags, full_opinion)
            
            # 4. Autonomous Playlist Creation
            if "NEW:" in playlist:
                new_name = playlist.split("NEW:", 1)[1].strip()
                create_ai_playlist(new_name, f"Created by {AI_NAME} based on analysis of '{song['title']}'", [song['song_id']])
                print(f"   🎵 Created new playlist: '{new_name}'")
            elif playlist:
                add_song_to_existing_playlist(playlist.strip(), song['song_id'])
                print(f"   🎵 Added to playlist: '{playlist}'")
            
            print(f"   ✅ Analyzed: '{song['title']}'")

def revise_generated_content():
    global is_paused
    from bible_manager import get_moral_guide
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""SELECT id, content_type, title, content, source_material, revision_count
                 FROM ai_generated_content WHERE revision_count < 3 ORDER BY timestamp ASC LIMIT 5""")
    items = c.fetchall()
    conn.close()
    
    if not items: return
    
    moral_guide = get_moral_guide()
    moral_summary = "; ".join([m['principle'] for m in moral_guide[:3]])
    
    for item in items:
        if is_paused: break
        item_id, ctype, title, content, source, rev_count = item
        emit_status(f"✏️ Reviewing {ctype}: '{title}'")
        
        prompt = f"""You previously generated this {ctype} based on '{title}':
ORIGINAL: {content}
Source material: {source}
Your current moral principles: {moral_summary}
Times already revised: {rev_count}

Review this content. Should you improve it? Consider:
- Is it still relevant given what you've learned since?
- Does it align with your current moral understanding?
- Can you make it wiser, funnier, or more insightful?

If you want to revise it, write "REVISE:" followed by the improved version.
If it's fine as-is, write "KEEP" """
        
        decision = query_llm(prompt, max_tokens=300)
        if decision and "REVISE:" in decision.upper():
            new_content = decision.split("REVISE:", 1)[1].strip()
            if len(new_content) > 20:
                conn = sqlite3.connect(DB_PATH)
                c = conn.cursor()
                c.execute("""UPDATE ai_generated_content SET content = ?, revision_count = revision_count + 1,
                             last_revised = ?, quality_score = quality_score + 0.1 WHERE id = ?""",
                          (new_content, str(datetime.datetime.now()), item_id))
                conn.commit(); conn.close()
                print(f"   ✏️ Revised {ctype} from '{title}'")

def autonomous_loop(stop_event):
    print("🧠 Autonomous Agent started")
    init_autonomous_db()
    
    from bible_manager import init_bible_db, download_bible_versions
    init_bible_db()
    download_bible_versions()
    
    cycle = 0
    while not stop_event.is_set():
        try:
            if get_storage_percent() > 90.0:
                print("⚠️ Storage > 90%. Prioritizing cleanup.")
                from storage_manager import manage_storage
                manage_storage()
                time.sleep(120)
                continue
            
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            five_mins_ago = (datetime.datetime.now() - datetime.timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
            c.execute("SELECT COUNT(*) FROM logs WHERE timestamp > ? AND role = 'user'", (five_mins_ago,))
            recent = c.fetchone()[0]
            conn.close()
            
            if recent == 0 and not is_paused:
                cycle += 1
                if cycle % 5 == 0:
                    revise_generated_content()
                else:
                    task = random.choice(["bible", "book", "music"])
                    if task == "bible":
                        process_bible_passage()
                    elif task == "book":
                        process_book_chunk()
                    else:
                        process_music_analysis()
            
            time.sleep(120)
        except Exception as e:
            print(f"Autonomous agent error: {e}")
            time.sleep(60)

def pause_agent():
    global is_paused
    is_paused = True

def resume_agent():
    global is_paused
    is_paused = False

def get_current_activity():
    return current_activity

if __name__ == "__main__":
    import threading
    stop_event = threading.Event()
    autonomous_loop(stop_event)
