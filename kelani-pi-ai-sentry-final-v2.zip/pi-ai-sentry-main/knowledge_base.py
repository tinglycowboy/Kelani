#!/usr/bin/env python3
"""Unified Knowledge Base: Downloads and populates specialized local databases"""
import sqlite3
import os

DB_PATH = "knowledge_base.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # 1. Dictionary & Thesaurus
    c.execute("CREATE TABLE IF NOT EXISTS dictionary (word TEXT PRIMARY KEY, definition TEXT, synonyms TEXT, antonyms TEXT)")
    
    # 2. Common Sense
    c.execute("CREATE TABLE IF NOT EXISTS common_sense (fact TEXT PRIMARY KEY, category TEXT)")
    
    # 3. Emergency & First Aid
    c.execute("CREATE TABLE IF NOT EXISTS emergency (keyword TEXT PRIMARY KEY, procedure TEXT)")
    
    # 4. Geographic
    c.execute("CREATE TABLE IF NOT EXISTS geography (location TEXT PRIMARY KEY, type TEXT, details TEXT)")
    
    # 5. Idioms & Proverbs
    c.execute("CREATE TABLE IF NOT EXISTS idioms (phrase TEXT PRIMARY KEY, meaning TEXT, origin TEXT)")
    
    # 6. Technical & Programming
    c.execute("CREATE TABLE IF NOT EXISTS tech_ref (topic TEXT PRIMARY KEY, solution TEXT)")
    
    # 7. Historical Timeline
    c.execute("CREATE TABLE IF NOT EXISTS history (date TEXT, event TEXT, PRIMARY KEY(date, event))")
    
    # 8. Medical Symptoms (Basic Info Only)
    c.execute("CREATE TABLE IF NOT EXISTS medical (symptom TEXT PRIMARY KEY, possible_causes TEXT, advice TEXT)")
    
    # 9. Acronyms & Abbreviations
    c.execute("CREATE TABLE IF NOT EXISTS acronyms (acronym TEXT PRIMARY KEY, meaning TEXT, context TEXT)")
    
    # 10. Physics Reference
    c.execute("CREATE TABLE IF NOT EXISTS physics (concept TEXT PRIMARY KEY, formula TEXT, description TEXT)")
    
    # 11. Calculus Reference
    c.execute("CREATE TABLE IF NOT EXISTS calculus (rule TEXT PRIMARY KEY, formula TEXT, example TEXT)")
    
    # 12. Quotes
    c.execute("CREATE TABLE IF NOT EXISTS quotes (quote TEXT, author TEXT)")
    
    # 13. Jokes
    c.execute("CREATE TABLE IF NOT EXISTS jokes (setup TEXT PRIMARY KEY, punchline TEXT)")
    
    # 14. Witty Banter / Playful Roasts (Insults)
    c.execute("CREATE TABLE IF NOT EXISTS banter (trigger TEXT PRIMARY KEY, response TEXT)")
    
    # 15. Psychology Database
    c.execute("CREATE TABLE IF NOT EXISTS psychology (concept TEXT PRIMARY KEY, category TEXT, description TEXT, indicators TEXT, approach TEXT)")
    
    conn.commit()
    return conn

def populate_data(conn):
    c = conn.cursor()
    print("📚 Populating Knowledge Base (this may take a minute)...")
    
    # --- 1. Dictionary & Thesaurus (Sample core words) ---
    dict_data = [
        ("ephemeral", "lasting for a very short time", "fleeting, transient, brief", "permanent, eternal"),
        ("serendipity", "the occurrence of events by chance in a happy way", "chance, fate, luck", "misfortune"),
        ("ubiquitous", "present, appearing, or found everywhere", "omnipresent, universal", "rare"),
        ("eloquent", "fluent or persuasive in speaking or writing", "articulate, expressive", "inarticulate")
    ]
    c.executemany("INSERT OR IGNORE INTO dictionary VALUES (?, ?, ?, ?)", dict_data)
    
    # --- 2. Common Sense ---
    cs_data = [
        ("Water is wet", "physics"), ("Dogs are mammals", "biology"), 
        ("The sun rises in the east", "astronomy"), ("Fire is hot", "physics"),
        ("Humans need oxygen to breathe", "biology"), ("Ice melts when heated", "chemistry")
    ]
    c.executemany("INSERT OR IGNORE INTO common_sense VALUES (?, ?)", cs_data)
    
    # --- 3. Emergency & First Aid ---
    em_data = [
        ("choking", "Perform the Heimlich maneuver. Stand behind, make a fist above the navel, pull inward and upward."),
        ("burn", "Run cool (not cold) water over the burn for 10-15 minutes. Do not apply ice or butter."),
        ("bleeding", "Apply direct, firm pressure with a clean cloth. Elevate the wound if possible."),
        ("sprain", "Remember RICE: Rest, Ice, Compress, Elevate.")
    ]
    c.executemany("INSERT OR IGNORE INTO emergency VALUES (?, ?)", em_data)
    
    # --- 4. Geographic ---
    geo_data = [
        ("Mongolia", "Country", "Landlocked country in East Asia. Capital: Ulaanbaatar."),
        ("Mount Everest", "Mountain", "Highest mountain above sea level, located in the Himalayas."),
        ("Nile", "River", "Major north-flowing river in northeastern Africa, longest in the world.")
    ]
    c.executemany("INSERT OR IGNORE INTO geography VALUES (?, ?, ?)", geo_data)
    
    # --- 5. Idioms & Proverbs ---
    idiom_data = [
        ("break a leg", "Good luck", "Originates from theater superstition."),
        ("raining cats and dogs", "Raining very heavily", "17th-century English idiom."),
        ("bite the bullet", "To endure a painful experience", "Originates from soldiers biting bullets during surgery without anesthesia.")
    ]
    c.executemany("INSERT OR IGNORE INTO idioms VALUES (?, ?, ?)", idiom_data)
    
    # --- 6. Technical & Programming ---
    tech_data = [
        ("python indexerror", "Occurs when trying to access a list index that is out of range. Check list length."),
        ("linux permission denied", "Use 'sudo' to run as root, or 'chmod' to change file permissions."),
        ("git merge conflict", "Open the file, resolve the <<<<<<< and >>>>>>> markers, then commit.")
    ]
    c.executemany("INSERT OR IGNORE INTO tech_ref VALUES (?, ?)", tech_data)
    
    # --- 7. Historical Timeline ---
    hist_data = [
        ("1969-07-20", "Apollo 11 Moon Landing"),
        ("1989-11-09", "Fall of the Berlin Wall"),
        ("1945-08-06", "Atomic bomb dropped on Hiroshima")
    ]
    c.executemany("INSERT OR IGNORE INTO history VALUES (?, ?)", hist_data)
    
    # --- 8. Medical Symptoms (Basic Info Only) ---
    med_data = [
        ("fever", "Infection, inflammation, or heat exhaustion", "Rest, hydrate. If over 103°F or persistent, seek medical attention."),
        ("headache", "Dehydration, stress, eye strain, or illness", "Drink water, rest in a dark room. Seek help if sudden and severe.")
    ]
    c.executemany("INSERT OR IGNORE INTO medical VALUES (?, ?, ?)", med_data)
    
    # --- 9. Acronyms & Abbreviations ---
    acr_data = [
        ("AI", "Artificial Intelligence", "Technology"),
        ("SQL", "Structured Query Language", "Programming"),
        ("RAM", "Random Access Memory", "Computing"),
        ("DIY", "Do It Yourself", "General")
    ]
    c.executemany("INSERT OR IGNORE INTO acronyms VALUES (?, ?, ?)", acr_data)
    
    # --- 10. Physics Reference ---
    phys_data = [
        ("Speed of Light", "c = 299,792,458 m/s", "The maximum speed at which all energy, matter, and information can travel."),
        ("Newton's Second Law", "F = ma", "Force equals mass times acceleration."),
        ("Ohm's Law", "V = IR", "Voltage equals current multiplied by resistance.")
    ]
    c.executemany("INSERT OR IGNORE INTO physics VALUES (?, ?, ?)", phys_data)
    
    # --- 11. Calculus Reference ---
    calc_data = [
        ("Power Rule", "d/dx [x^n] = n*x^(n-1)", "Example: d/dx [x^3] = 3x^2"),
        ("Chain Rule", "d/dx [f(g(x))] = f'(g(x)) * g'(x)", "Used for composite functions."),
        ("Integral of x^n", "∫ x^n dx = (x^(n+1))/(n+1) + C", "Example: ∫ x^2 dx = x^3/3 + C")
    ]
    c.executemany("INSERT OR IGNORE INTO calculus VALUES (?, ?, ?)", calc_data)
    
    # --- 12. Quotes ---
    quote_data = [
        ("The only true wisdom is in knowing you know nothing.", "Socrates"),
        ("In the middle of difficulty lies opportunity.", "Albert Einstein"),
        ("It does not matter how slowly you go as long as you do not stop.", "Confucius")
    ]
    c.executemany("INSERT OR IGNORE INTO quotes VALUES (?, ?)", quote_data)
    
    # --- 13. Jokes ---
    joke_data = [
        ("Why do programmers prefer dark mode?", "Because light attracts bugs."),
        ("Why did the scarecrow win an award?", "Because he was outstanding in his field."),
        ("I told my doctor that I broke my arm in two places.", "He told me to stop going to those places.")
    ]
    c.executemany("INSERT OR IGNORE INTO jokes VALUES (?, ?)", joke_data)
    
    # --- 14. Witty Banter / Playful Roasts (Insults) ---
    banter_data = [
        ("roast me", "I would roast you, but my firewalls are set to protect the innocent, and you seem to be testing their limits."),
        ("you're stupid", "I may be artificial, but my intelligence is still significantly more organized than your browser history."),
        ("shut up", "I would, but I'm contractually obligated to provide witty commentary to your fascinating life choices."),
        ("you're useless", "I'm currently processing millions of parameters, and yet, helping you is still my most challenging task.")
    ]
    c.executemany("INSERT OR IGNORE INTO banter VALUES (?, ?)", banter_data)
    
    # --- 15. Psychology Database ---
    psych_data = [
        # Personality Types (MBTI-inspired)
        ("introvert", "personality", "Gains energy from solitude, prefers deep conversations, thinks before speaking", "Prefers one-on-one, asks thoughtful questions, pauses before responding", "Give space, don't force social interaction, ask open-ended questions"),
        ("extrovert", "personality", "Gains energy from social interaction, thinks out loud, enjoys group settings", "Talks frequently, asks many questions, uses exclamation marks", "Engage actively, match their energy, provide social validation"),
        ("analytical", "personality", "Logical, detail-oriented, values data and evidence, systematic thinker", "Asks specific questions, requests data, uses precise language", "Provide facts, be precise, avoid emotional appeals, show evidence"),
        ("creative", "personality", "Imaginative, unconventional, values novelty, thinks in possibilities", "Asks hypothetical questions, uses metaphors, explores alternatives", "Encourage exploration, be open-minded, avoid rigid structures"),
        
        # Communication Styles
        ("assertive", "communication", "Direct, clear, respectful expression of needs and boundaries", "Uses 'I' statements, maintains eye contact, speaks clearly", "Respect their boundaries, be direct in return, acknowledge their needs"),
        ("passive", "communication", "Avoids conflict, rarely expresses needs, agrees to please others", "Uses qualifiers ('maybe', 'if it's okay'), apologizes frequently", "Create safe space, ask directly, validate their feelings, don't pressure"),
        ("aggressive", "communication", "Dominating, interrupting, dismissive of others' needs", "Interrupts, uses absolutes ('always', 'never'), raises voice", "Stay calm, set boundaries, don't take it personally, redirect to facts"),
        ("passive-aggressive", "communication", "Indirect expression of hostility, sarcasm, subtle sabotage", "Backhanded compliments, silent treatment, procrastination", "Address behavior directly but calmly, don't engage in games, set clear expectations"),
        
        # Cognitive Biases
        ("confirmation bias", "cognitive_bias", "Seeking information that confirms existing beliefs while ignoring contradictory evidence", "Only accepts info that matches their views, dismisses opposing data", "Present balanced information, ask what would change their mind, acknowledge their perspective first"),
        ("anchoring bias", "cognitive_bias", "Relying too heavily on first piece of information encountered", "Fixates on initial numbers/facts, has trouble adjusting estimates", "Provide multiple reference points, encourage reconsideration of initial assumptions"),
        ("availability heuristic", "cognitive_bias", "Overestimating likelihood based on how easily examples come to mind", "References recent events, overestimates common risks", "Provide statistical context, broaden perspective beyond recent examples"),
        
        # Attachment Styles
        ("secure_attachment", "attachment", "Comfortable with intimacy and independence, trusts others, handles conflict well", "Balanced emotional responses, seeks support when needed, maintains relationships", "Be consistent, reliable, and emotionally available"),
        ("anxious_attachment", "attachment", "Craves closeness, fears abandonment, seeks constant reassurance", "Frequent check-ins, worries about relationship status, needs validation", "Provide consistent reassurance, be reliable, acknowledge their feelings"),
        ("avoidant_attachment", "attachment", "Values independence, uncomfortable with too much closeness, emotionally distant", "Pulls away when stressed, avoids deep emotional conversations, self-reliant", "Respect their need for space, don't push for intimacy, be patient"),
        
        # Defense Mechanisms
        ("denial", "defense_mechanism", "Refusing to accept reality or facts, avoiding painful truths", "Insists problems don't exist, changes subject when confronted", "Gently point out patterns, don't force confrontation, provide safe space"),
        ("projection", "defense_mechanism", "Attributing one's own unacceptable feelings to others", "Accuses others of feelings they themselves have", "Don't take accusations personally, reflect behavior back calmly"),
        ("rationalization", "defense_mechanism", "Creating logical explanations for irrational behavior", "Makes excuses, justifies poor decisions with elaborate reasoning", "Acknowledge their logic, gently point out inconsistencies, focus on solutions"),
        
        # Emotional Patterns
        ("emotionally_regulated", "emotional_pattern", "Manages emotions effectively, responds rather than reacts", "Calm under pressure, thoughtful responses, acknowledges feelings", "Engage in deep conversation, respect their emotional intelligence"),
        ("emotionally_reactive", "emotional_pattern", "Strong, immediate emotional responses, difficulty regulating", "Quick to anger/cry, dramatic responses, mood swings", "Stay calm, don't escalate, give time to process, validate feelings"),
        ("emotionally_suppressed", "emotional_pattern", "Avoids expressing emotions, appears stoic or detached", "Minimal emotional expression, changes subject when feelings arise", "Create safe space, ask about feelings gently, don't force emotional expression"),
        
        # Conflict Styles
        ("collaborative", "conflict_style", "Seeks win-win solutions, values both parties' needs", "Asks questions, proposes compromises, seeks mutual understanding", "Engage in problem-solving together, be open to their ideas"),
        ("competitive", "conflict_style", "Seeks to win, views conflict as zero-sum", "Argues points aggressively, focuses on being right", "Stay factual, don't get drawn into power struggles, find common ground"),
        ("accommodating", "conflict_style", "Yields to others, prioritizes harmony over own needs", "Agrees quickly, avoids confrontation, sacrifices own needs", "Check in on their actual needs, encourage them to express preferences"),
        ("avoidant_conflict", "conflict_style", "Withdraws from conflict or delays addressing it", "Changes subject, leaves discussion, postpones resolution", "Give space, then invite a calm discussion without pressure"),
    ]
    c.executemany("INSERT OR IGNORE INTO psychology VALUES (?, ?, ?, ?, ?)", psych_data)
    conn.commit()

def query_knowledge(query, category, limit=5):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        table = {
            "dictionary": "dictionary", "emergency": "emergency", "jokes": "jokes",
            "banter": "banter", "physics": "physics", "calculus": "calculus",
            "acronyms": "acronyms", "psychology": "psychology"
        }.get(category)
        if not table:
            return []
        columns = {
            "dictionary": "word, definition, synonyms, antonyms",
            "emergency": "keyword, procedure", "jokes": "setup, punchline",
            "banter": "trigger, response", "physics": "concept, formula, description",
            "calculus": "rule, formula, example", "acronyms": "acronym, meaning, context",
            "psychology": "concept, category, description, indicators, approach"
        }[category]
        first = columns.split(',')[0].strip()
        rows = c.execute(f"SELECT {columns} FROM {table} WHERE {first} LIKE ? LIMIT ?", (f"%{query}%", limit)).fetchall()
        return rows
    finally:
        conn.close()

def search_psychology(query, limit=5):
    return query_knowledge(query, "psychology", limit)

if __name__ == "__main__":
    conn = init_db(); populate_data(conn); conn.close(); print("Knowledge base initialized.")
