#!/usr/bin/env python3
import subprocess
import os
import sys
import time

def check_camera():
    """Check if a camera is available"""
    try:
        import cv2
        cap = cv2.VideoCapture(0)
        if cap.isOpened():
            ret, frame = cap.read()
            cap.release()
            if ret:
                print("📷 Camera detected and working")
                return True
        return False
    except Exception as e:
        print(f"⚠️ Camera check error: {e}")
        return False

def check_microphone():
    """Check if a microphone is available"""
    try:
        import pyaudio
        p = pyaudio.PyAudio()
        
        # Check if there are any input devices
        device_count = p.get_device_count()
        for i in range(device_count):
            device_info = p.get_device_info_by_index(i)
            if device_info['maxInputChannels'] > 0:
                print(f"🎤 Microphone detected: {device_info['name']}")
                p.terminate()
                return True
        
        p.terminate()
        return False
    except Exception as e:
        print(f"⚠️ Microphone check error: {e}")
        return False

def get_usb_devices():
    """Get list of connected USB devices"""
    try:
        result = subprocess.run(['lsusb'], capture_output=True, text=True)
        return result.stdout
    except:
        return ""

def save_hardware_state():
    """Save current hardware state to file"""
    state = {
        'camera': check_camera(),
        'microphone': check_microphone(),
        'usb_devices': get_usb_devices()
    }
    
    with open('/tmp/hardware_state.txt', 'w') as f:
        f.write(f"camera={state['camera']}\n")
        f.write(f"microphone={state['microphone']}\n")
        f.write(f"usb_devices={state['usb_devices']}\n")
    
    return state

def load_hardware_state():
    """Load previous hardware state from file"""
    try:
        if not os.path.exists('/tmp/hardware_state.txt'):
            return None
        
        state = {}
        with open('/tmp/hardware_state.txt', 'r') as f:
            for line in f:
                if '=' in line:
                    key, value = line.strip().split('=', 1)
                    if key in ['camera', 'microphone']:
                        state[key] = value == 'True'
                    elif key == 'usb_devices':
                        state[key] = value
        
        return state
    except:
        return None

def detect_new_hardware():
    """Compare current hardware to previous state"""
    current_state = save_hardware_state()
    previous_state = load_hardware_state()
    
    if previous_state is None:
        print("📋 First boot, no previous state to compare")
        return False
    
    new_camera = current_state['camera'] and not previous_state.get('camera', False)
    new_microphone = current_state['microphone'] and not previous_state.get('microphone', False)
    
    if new_camera:
        print("🆕 New camera detected!")
        return True
    
    if new_microphone:
        print("🆕 New microphone detected!")
        return True
    
    print("✓ No new hardware detected")
    return False

def initial_setup():
    """Run on first boot to detect and enable hardware"""
    print("🔍 Running initial hardware detection...")
    
    camera_available = check_camera()
    mic_available = check_microphone()
    
    print(f"Camera: {'✓ Available' if camera_available else '✗ Not available'}")
    print(f"Microphone: {'✓ Available' if mic_available else '✗ Not available'}")
    
    save_hardware_state()

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == '--monitor':
        # Monitor mode: check for new hardware
        if detect_new_hardware():
            print("🔄 New hardware detected, rebooting in 3 seconds...")
            time.sleep(3)
            subprocess.run(['sudo', 'reboot'])
    else:
        # Initial setup mode
        initial_setup()
