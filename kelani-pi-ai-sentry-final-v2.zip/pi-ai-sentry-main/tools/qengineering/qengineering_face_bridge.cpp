#include <opencv2/opencv.hpp>
#include <iostream>
#include <iomanip>
#include <vector>
#include "TRetina.h"
#include "TArcface.h"
#include "TWarp.h"

using namespace cv;
using namespace std;

int main(int argc, char **argv) {
    if (argc != 2) {
        cerr << "usage: qengineering_face_bridge IMAGE" << endl;
        return 2;
    }

    Mat frame = imread(argv[1], 1);
    if (frame.empty()) {
        cerr << "cannot read image" << endl;
        return 3;
    }

    const int retina_width = 320;
    const int retina_height = 240;
    const float min_face_threshold = 0.50f;

    Mat result;
    resize(frame, result, Size(retina_width, retina_height), INTER_LINEAR);

    TRetina retina(retina_width, retina_height, false);
    TWarp warp;
    TArcFace arcface;
    vector<FaceObject> faces;
    retina.detect_retinaface(result, faces);

    if (faces.empty()) {
        cout << "{\"face_found\":false}" << endl;
        return 0;
    }

    // Qengineering's reference application deliberately recognizes one face
    // at a time because tiny faces greatly reduce recognition quality.
    size_t best = 0;
    for (size_t i = 1; i < faces.size(); ++i) {
        if (faces[i].FaceProb > faces[best].FaceProb) best = i;
    }

    if (faces[best].FaceProb < min_face_threshold) {
        cout << "{\"face_found\":false,\"face_confidence\":" << faces[best].FaceProb << "}" << endl;
        return 0;
    }

    Mat aligned = warp.Process(result, faces[best]);
    Mat feature = arcface.GetFeature(aligned);
    if (feature.empty()) {
        cerr << "ArcFace returned no feature" << endl;
        return 4;
    }

    cout << std::fixed << std::setprecision(8);
    cout << "{\"face_found\":true,\"face_confidence\":" << faces[best].FaceProb
         << ",\"angle\":" << warp.Angle << ",\"embedding\":[";
    for (int i = 0; i < feature.cols; ++i) {
        if (i) cout << ',';
        cout << feature.at<float>(0, i);
    }
    cout << "]}" << endl;
    return 0;
}
