#!/bin/bash
set -euo pipefail
APP_DIR="${AI_SENTRY_HOME:-$HOME/ai_sentry}"
VENDOR="$APP_DIR/vendor/qengineering-face-recognition"
TMP="${APP_DIR}/temp/qengineering-build"

sudo apt-get update
sudo apt-get install -y git cmake build-essential libopencv-dev

if [[ ! -f /usr/local/include/ncnn/net.h || ! -f /usr/local/lib/ncnn/libncnn.a ]]; then
  rm -rf "$TMP/ncnn"
  mkdir -p "$TMP"
  git clone --depth 1 https://github.com/Tencent/ncnn.git "$TMP/ncnn"
  cmake -S "$TMP/ncnn" -B "$TMP/ncnn-build" \
    -DNCNN_BUILD_EXAMPLES=OFF \
    -DNCNN_BUILD_TOOLS=OFF \
    -DNCNN_VULKAN=OFF \
    -DNCNN_OPENMP=ON \
    -DNCNN_BUILD_TESTS=OFF
  cmake --build "$TMP/ncnn-build" -j2
  sudo cmake --install "$TMP/ncnn-build"
fi

if [[ ! -d "$VENDOR/.git" ]]; then
  mkdir -p "$(dirname "$VENDOR")"
  git clone --depth 1 https://github.com/Qengineering/Face-Recognition-Raspberry-Pi-64-bits.git "$VENDOR"
fi

mkdir -p "$VENDOR/pi_ai_bridge"
cp "$APP_DIR/tools/qengineering/qengineering_face_bridge.cpp" "$VENDOR/pi_ai_bridge/"
cp "$APP_DIR/tools/qengineering/CMakeLists.txt" "$VENDOR/pi_ai_bridge/"

cmake -S "$VENDOR/pi_ai_bridge" -B "$VENDOR/pi_ai_bridge/build"
cmake --build "$VENDOR/pi_ai_bridge/build" -j2
chmod +x "$VENDOR/qengineering_face_bridge"
echo "Qengineering face bridge installed: $VENDOR/qengineering_face_bridge"
