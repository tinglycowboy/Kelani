#!/usr/bin/env python3
import sqlite3

from config import DB_PATH, WIKI_DIR

def search_wikipedia(query, limit=3):
    """Search Wikipedia database and return top results"""
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        # Use FTS5 full-text search with rank ordering
        c.execute("""
            SELECT title, abstract, rank
            FROM wiki 
            WHERE wiki MATCH ?
            ORDER BY rank
            LIMIT ?
        """, (query, limit))
        
        results = c.fetchall()
        conn.close()
        
        return [{"title": r[0], "abstract": r[1], "source_file": f"{WIKI_DIR}/enwiki-latest-abstract.xml"} for r in results]
    except Exception as e:
        print(f"Wiki search error: {e}")
        return []

def should_search_wikipedia(prompt):
    """Determine if the query needs Wikipedia knowledge"""
    prompt_lower = prompt.lower()
    
    # Keywords that suggest factual knowledge is needed
    knowledge_keywords = [
        "what is", "who is", "who was", "tell me about", "explain",
        "history of", "how does", "why does", "when did", "where is",
        "define", "description of", "information about"
    ]
    
    # Check if prompt contains knowledge-seeking phrases
    for keyword in knowledge_keywords:
        if keyword in prompt_lower:
            return True
    
    # If prompt is longer than 5 words, likely needs context
    if len(prompt_lower.split()) > 5:
        return True
    
    return False

if __name__ == "__main__":
    # Test the search
    results = search_wikipedia("skiing")
    for r in results:
        print(f"Title: {r['title']}")
        print(f"Abstract: {r['abstract'][:200]}...\n")
      
