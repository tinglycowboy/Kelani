#!/usr/bin/env python3
import cv2
import sqlite3
import datetime
import threading
import time
import json
import os
import tempfile
import numpy as np

from config import DB_PATH
from person_recognition import ensure_person_profile_from_face, update_person_last_seen, init_person_db
from identity_manager import record_observation, request_identity_question
from qengineering_face_backend import recognize as qengine_recognize

TARGET_FPS = 15
FRAME_INTERVAL = 1.0 / TARGET_FPS
_FACE_CASCADE = None


def init_camera_db():
    init_person_db()
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS visual_events (
            id TEXT PRIMARY KEY, timestamp TEXT, objects_detected TEXT,
            object_count INTEGER, frame_description TEXT, person_id TEXT,
            face_encoding TEXT, interaction_triggered BOOLEAN DEFAULT 0,
            recognition_backend TEXT, recognition_confidence REAL DEFAULT 0
        )""")


def _face_cascade():
    global _FACE_CASCADE
    if _FACE_CASCADE is None:
        _FACE_CASCADE = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    return _FACE_CASCADE


def detect_faces_opencv(frame):
    """Cheap first gate. Qengineering is never invoked unless this finds a face."""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = _face_cascade().detectMultiScale(gray, 1.1, 5, minSize=(48, 48))
    return list(faces)


def detect_objects(frame):
    # Keep the first-stage detector cheap; do not run the deep recognizer here.
    faces = detect_faces_opencv(frame)
    objects = [f"face_{i+1}" for i in range(len(faces))]
    return objects, len(objects)


def _run_qengineering(face_crop):
    fd, path = tempfile.mkstemp(prefix='face_', suffix='.jpg', dir='/tmp')
    os.close(fd)
    try:
        cv2.imwrite(path, face_crop, [int(cv2.IMWRITE_JPEG_QUALITY), 95])
        result = qengine_recognize(path)
        return result
    finally:
        try: os.remove(path)
        except OSError: pass


def _store_event(objects, count, person_id, face_encoding, interaction_triggered, backend, confidence):
    import uuid
    objects_str = ", ".join(objects) if objects else "none"
    frame_desc = f"Detected {count} objects: {objects_str}"
    if person_id:
        frame_desc += f" | person profile: {person_id}"
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""INSERT INTO visual_events
            (id,timestamp,objects_detected,object_count,frame_description,person_id,face_encoding,interaction_triggered,recognition_backend,recognition_confidence)
            VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (str(uuid.uuid4()), datetime.datetime.now().isoformat(), objects_str, count,
             frame_desc, person_id, json.dumps(face_encoding) if face_encoding else None,
             interaction_triggered, backend, float(confidence or 0.0)))
    return frame_desc


def log_visual_event(objects, object_count, person_id=None, face_encoding=None, interaction_triggered=False):
    return _store_event(objects, object_count, person_id, face_encoding, interaction_triggered, 'legacy', 0.0)


def camera_loop(stop_event, proactive_callback=None):
    cap = None
    try:
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("Camera not available, running audio-only mode")
            return
        cap.set(cv2.CAP_PROP_FPS, TARGET_FPS)
        print(f"Camera initialized at {TARGET_FPS} fps: OpenCV gate -> Qengineering recognition")
        frame_count = 0
        last_greeting_time = {}

        while not stop_event.is_set():
            start = time.time()
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.02)
                continue
            frame_count += 1

            faces = detect_faces_opencv(frame)
            objects = [f"face_{i+1}" for i in range(len(faces))]
            if faces and frame_count % 10 == 0:
                # Start with the largest face. This matches Qengineering's documented
                # recommendation that tiny faces are harder to recognize reliably.
                box = max(faces, key=lambda f: f[2] * f[3])
                x, y, w, h = box
                pad = int(0.18 * max(w, h))
                x0, y0 = max(0, x-pad), max(0, y-pad)
                x1, y1 = min(frame.shape[1], x+w+pad), min(frame.shape[0], y+h+pad)
                crop = frame[y0:y1, x0:x1]

                qresult = _run_qengineering(crop)
                face_encoding = qresult.get('embedding') if qresult and qresult.get('face_found') else None
                qconf = float(qresult.get('face_confidence', 0.0)) if qresult else 0.0

                # Qengineering produces the durable ArcFace descriptor. OpenCV descriptor
                # is retained only as a fallback if the bridge is unavailable.
                backend = 'qengineering_arcface'
                if face_encoding:
                    from person_recognition import identify_person
                    person_id, confidence = identify_person(face_encoding)
                    if person_id is None:
                        from identity_manager import create_unknown_profile
                        person_id = create_unknown_profile('face', face_encoding, qconf, 'qengineering_arcface')
                        confidence = qconf
                    else:
                        record_observation(person_id, 'face', max(confidence, qconf),
                                           {'backend':'qengineering_arcface'}, 'qengineering_arcface', face_encoding, qconf)
                else:
                    from person_recognition import extract_face_encoding
                    fallback = extract_face_encoding(frame, box)
                    person_id, confidence, _ = ensure_person_profile_from_face(fallback, 0.45) if fallback else (None, 0.0, False)
                    face_encoding = fallback
                    backend = 'opencv_fallback'

                if person_id:
                    update_person_last_seen(person_id)
                    now = datetime.datetime.now()
                    should_ask = person_id not in last_greeting_time or (now - last_greeting_time[person_id]).total_seconds() > 300
                    if should_ask and proactive_callback:
                        last_greeting_time[person_id] = now
                        interaction = proactive_callback(person_id, frame)
                        _store_event(objects, len(objects), person_id, face_encoding, bool(interaction), backend, confidence)
                    else:
                        _store_event(objects, len(objects), person_id, face_encoding, False, backend, confidence)
                else:
                    _store_event(objects, len(objects), None, face_encoding, False, backend, confidence)

            elapsed = time.time() - start
            if elapsed < FRAME_INTERVAL:
                time.sleep(FRAME_INTERVAL - elapsed)
    except Exception as e:
        print(f"Camera loop error: {e}")
    finally:
        if cap is not None:
            cap.release()


def get_recent_visuals(limit=5):
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT * FROM visual_events ORDER BY timestamp DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in reversed(rows)]
    except Exception as e:
        print(f"Visual history error: {e}")
        return []


def is_camera_available(index=0):
    try:
        cap = cv2.VideoCapture(index)
        ok = cap.isOpened()
        if ok:
            ok, _ = cap.read()
        cap.release()
        return bool(ok)
    except Exception:
        return False
