#!/usr/bin/env python3
import sqlite3
import xml.etree.ElementTree as ET
import urllib.request
import gzip
import shutil
import os
import re

from config import DB_PATH, WIKI_DIR
DB_PATH = DB_PATH
WIKI_FILE=os.path.join(WIKI_DIR,"enwiki-latest-abstract.xml.gz")
WIKI_XML=os.path.join(WIKI_DIR,"enwiki-latest-abstract.xml")
WIKI_URL = "https://dumps.wikimedia.org/enwiki/latest/enwiki-latest-abstract.xml.gz"

def setup_database():
    print("Creating Wikipedia database...")
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("CREATE VIRTUAL TABLE IF NOT EXISTS wiki USING fts5(title, abstract, content='')")
    conn.commit()
    return conn

def download_wikipedia():
    if os.path.exists(WIKI_XML):
        print("Wikipedia XML already exists, skipping download.")
        marker=os.path.join(WIKI_DIR,"DOWNLOAD_COMPLETE")
        if not os.path.exists(marker):
            open(marker,"w").write("Wikipedia raw acquisition complete\n")
        return True
    if not os.path.exists(WIKI_FILE):
        print(f"Downloading Wikipedia abstracts from {WIKI_URL}...")
        print("This is a large file (~700MB). Please wait...")
        urllib.request.urlretrieve(WIKI_URL, WIKI_FILE)
    print("Extracting XML...")
    with gzip.open(WIKI_FILE, "rb") as f_in:
        with open(WIKI_XML, "wb") as f_out:
            shutil.copyfileobj(f_in, f_out)
    marker=os.path.join(WIKI_DIR,"DOWNLOAD_COMPLETE")
    with open(marker,"w") as f: f.write("Wikipedia raw acquisition complete\n")
    return True

def clean_text(text):
    if not text:
        return ""
    text = re.sub(r"\{\{.*?\}\}", "", text)
    text = re.sub(r"\[\[.*?\]\]", "", text)
    text = re.sub(r"<.*?>", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def parse_wikipedia():
    print("Parsing Wikipedia into database (this may take 5-10 minutes)...")
    conn = setup_database()
    c = conn.cursor()
    
    context = ET.iterparse(WIKI_XML, events=("end",))
    count = 0
    batch = []
    
    for event, elem in context:
        if elem.tag == "doc":
            title_elem = elem.find("title")
            abstract_elem = elem.find("abstract")
            
            if title_elem is not None and abstract_elem is not None:
                title = title_elem.text or ""
                abstract = abstract_elem.text or ""
                
                title = clean_text(title)
                abstract = clean_text(abstract)
                
                if title and abstract and len(abstract) > 50:
                    batch.append((title, abstract))
                    count += 1
                    
                    if count % 10000 == 0:
                        print(f"Processed {count} articles...")
                    
                    if len(batch) >= 1000:
                        c.executemany("INSERT INTO wiki (title, abstract) VALUES (?, ?)", batch)
                        conn.commit()
                        batch = []
            
            elem.clear()
    
    if batch:
        c.executemany("INSERT INTO wiki (title, abstract) VALUES (?, ?)", batch)
        conn.commit()
    
    conn.close()
    print(f"✓ Successfully indexed {count} Wikipedia articles into {DB_PATH}")

if __name__ == "__main__":
    download_wikipedia()
    parse_wikipedia()
    print("Wikipedia database is ready!")
  
