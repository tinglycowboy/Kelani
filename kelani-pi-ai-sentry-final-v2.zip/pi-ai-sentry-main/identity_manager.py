#!/usr/bin/env python3
"""Durable, evidence-based identity profiles for Pi AI Sentry.

This module deliberately separates:
  * observations (what the sensors measured),
  * identity hypotheses (who the system thinks a profile may be), and
  * explicit/user-provided facts.

An unknown person may have a profile before ever speaking. Names heard in
conversation are temporary candidates until repeated or explicitly confirmed.
"""
import datetime as dt
import json
import math
import os
import re
import sqlite3
import uuid
from typing import Any, Dict, Iterable, Optional, Tuple

from config import DB_PATH

NAME_RE = re.compile(r"\b([A-Z][a-z]{1,30}(?:[-'][A-Z][a-z]{1,30})?)\b")
DEFAULT_NAME_TTL_DAYS = int(os.environ.get("AI_SENTRY_NAME_CACHE_DAYS", "14"))

SCHEMA = r"""
CREATE TABLE IF NOT EXISTS identity_profiles (
    person_id TEXT PRIMARY KEY,
    status TEXT NOT NULL DEFAULT 'unknown',
    display_name TEXT,
    name_confidence REAL NOT NULL DEFAULT 0.0,
    face_confidence REAL NOT NULL DEFAULT 0.0,
    voice_confidence REAL NOT NULL DEFAULT 0.0,
    identity_confidence REAL NOT NULL DEFAULT 0.0,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    observation_count INTEGER NOT NULL DEFAULT 0,
    face_observation_count INTEGER NOT NULL DEFAULT 0,
    voice_observation_count INTEGER NOT NULL DEFAULT 0,
    metadata_json TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS identity_embeddings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id TEXT NOT NULL,
    modality TEXT NOT NULL,
    embedding_json TEXT NOT NULL,
    quality REAL NOT NULL DEFAULT 0.5,
    created_at TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY(person_id) REFERENCES identity_profiles(person_id)
);
CREATE INDEX IF NOT EXISTS idx_identity_embeddings_person_modality
ON identity_embeddings(person_id, modality, active);
CREATE TABLE IF NOT EXISTS identity_observations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id TEXT,
    modality TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    confidence REAL NOT NULL,
    source TEXT NOT NULL,
    data_json TEXT NOT NULL DEFAULT '{}',
    FOREIGN KEY(person_id) REFERENCES identity_profiles(person_id)
);
CREATE INDEX IF NOT EXISTS idx_identity_observations_person_time
ON identity_observations(person_id, observed_at);
CREATE TABLE IF NOT EXISTS identity_evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id TEXT NOT NULL,
    evidence_type TEXT NOT NULL,
    value TEXT NOT NULL,
    confidence REAL NOT NULL,
    direction REAL NOT NULL DEFAULT 1.0,
    source TEXT NOT NULL,
    context TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY(person_id) REFERENCES identity_profiles(person_id)
);
CREATE INDEX IF NOT EXISTS idx_identity_evidence_person
ON identity_evidence(person_id, evidence_type, created_at);
CREATE TABLE IF NOT EXISTS identity_name_cache (
    normalized_name TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    mention_count INTEGER NOT NULL DEFAULT 1,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    context_json TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS identity_name_hypotheses (
    person_id TEXT NOT NULL,
    normalized_name TEXT NOT NULL,
    confidence REAL NOT NULL DEFAULT 0.0,
    confirmations INTEGER NOT NULL DEFAULT 0,
    last_updated TEXT NOT NULL,
    PRIMARY KEY(person_id, normalized_name),
    FOREIGN KEY(person_id) REFERENCES identity_profiles(person_id)
);
CREATE TABLE IF NOT EXISTS identity_questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id TEXT,
    question_type TEXT NOT NULL,
    question TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL,
    answered_at TEXT,
    answer_text TEXT,
    FOREIGN KEY(person_id) REFERENCES identity_profiles(person_id)
);
CREATE TABLE IF NOT EXISTS identity_facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id TEXT NOT NULL,
    fact_type TEXT NOT NULL,
    value_json TEXT NOT NULL,
    confidence REAL NOT NULL DEFAULT 0.5,
    source TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'current',
    first_seen TEXT NOT NULL,
    last_updated TEXT NOT NULL,
    FOREIGN KEY(person_id) REFERENCES identity_profiles(person_id)
);
CREATE INDEX IF NOT EXISTS idx_identity_facts_person ON identity_facts(person_id, fact_type, status);
"""


def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def connect():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_identity_db() -> None:
    with connect() as conn:
        conn.executescript(SCHEMA)


def _clip(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _new_person_id() -> str:
    return str(uuid.uuid4())


def create_unknown_profile(modality: str, sample: Any = None, quality: float = 0.7,
                           source: str = "sensor") -> str:
    """Create a profile even when there is no name or speech."""
    init_identity_db()
    person_id = _new_person_id()
    now = _now()
    with connect() as conn:
        conn.execute(
            "INSERT INTO identity_profiles(person_id,status,first_seen,last_seen,observation_count,metadata_json) "
            "VALUES(?,?,?,?,?,?)",
            (person_id, "unknown", now, now, 1, _json({"created_reason": modality})),
        )
        if sample is not None:
            conn.execute(
                "INSERT INTO identity_embeddings(person_id,modality,embedding_json,quality,created_at) VALUES(?,?,?,?,?)",
                (person_id, modality, _json(sample), _clip(quality), now),
            )
        conn.execute(
            "INSERT INTO identity_observations(person_id,modality,observed_at,confidence,source,data_json) VALUES(?,?,?,?,?,?)",
            (person_id, modality, now, _clip(quality), source, _json({"new_profile": True})),
        )
    return person_id


def record_observation(person_id: str, modality: str, confidence: float,
                       data: Optional[Dict[str, Any]] = None,
                       source: str = "sensor", sample: Any = None,
                       quality: Optional[float] = None) -> None:
    """Record a new observation and update only evidence-derived confidence."""
    init_identity_db()
    now = _now()
    confidence = _clip(confidence)
    with connect() as conn:
        conn.execute(
            "INSERT INTO identity_observations(person_id,modality,observed_at,confidence,source,data_json) VALUES(?,?,?,?,?,?)",
            (person_id, modality, now, confidence, source, _json(data or {})),
        )
        if sample is not None:
            conn.execute(
                "INSERT INTO identity_embeddings(person_id,modality,embedding_json,quality,created_at) VALUES(?,?,?,?,?)",
                (person_id, modality, _json(sample), _clip(quality if quality is not None else confidence), now),
            )
        conn.execute(
            "UPDATE identity_profiles SET last_seen=?, observation_count=observation_count+1, "
            "face_observation_count=face_observation_count+CASE WHEN ?='face' THEN 1 ELSE 0 END, "
            "voice_observation_count=voice_observation_count+CASE WHEN ?='voice' THEN 1 ELSE 0 END "
            "WHERE person_id=?",
            (now, modality, modality, person_id),
        )
        _recompute_confidence(conn, person_id)


def _recompute_confidence(conn, person_id: str) -> None:
    row = conn.execute(
        "SELECT AVG(CASE WHEN modality='face' THEN confidence END), "
        "AVG(CASE WHEN modality='voice' THEN confidence END) FROM identity_observations WHERE person_id=?",
        (person_id,),
    ).fetchone()
    face = _clip(row[0] or 0.0)
    voice = _clip(row[1] or 0.0)
    name_row = conn.execute(
        "SELECT MAX(confidence) FROM identity_name_hypotheses WHERE person_id=?", (person_id,)
    ).fetchone()
    name_conf = _clip(name_row[0] or 0.0)
    # Identity confidence is evidence aggregation, not a claim of certainty.
    evidence = [x for x in (face, voice, name_conf) if x > 0]
    identity = sum(evidence) / len(evidence) if evidence else 0.0
    conn.execute(
        "UPDATE identity_profiles SET face_confidence=?,voice_confidence=?,name_confidence=?,identity_confidence=? WHERE person_id=?",
        (face, voice, name_conf, identity, person_id),
    )


def add_evidence(person_id: str, evidence_type: str, value: str, confidence: float,
                 source: str, direction: float = 1.0, context: Optional[str] = None) -> float:
    """Add evidence that can increase or decrease a hypothesis confidence."""
    init_identity_db()
    confidence = _clip(confidence)
    direction = -1.0 if direction < 0 else 1.0
    now = _now()
    with connect() as conn:
        conn.execute(
            "INSERT INTO identity_evidence(person_id,evidence_type,value,confidence,direction,source,context,created_at) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (person_id, evidence_type, value, confidence, direction, source, context, now),
        )
        if evidence_type == "name":
            norm = normalize_name(value)
            row = conn.execute(
                "SELECT confidence, confirmations FROM identity_name_hypotheses WHERE person_id=? AND normalized_name=?",
                (person_id, norm),
            ).fetchone()
            old = float(row[0]) if row else 0.0
            confirmations = int(row[1]) if row else 0
            # Repeated independent evidence moves the score gradually, not instantly.
            target = confidence if direction > 0 else 0.0
            new = _clip(old + (target - old) * (0.35 if direction > 0 else 0.50))
            if direction > 0:
                confirmations += 1
            conn.execute(
                "INSERT INTO identity_name_hypotheses(person_id,normalized_name,confidence,confirmations,last_updated) "
                "VALUES(?,?,?,?,?) ON CONFLICT(person_id,normalized_name) DO UPDATE SET confidence=?,confirmations=?,last_updated=?",
                (person_id, norm, new, confirmations, now, new, confirmations, now),
            )
        _recompute_confidence(conn, person_id)
        row = conn.execute(
            "SELECT confidence FROM identity_name_hypotheses WHERE person_id=? AND normalized_name=?",
            (person_id, normalize_name(value)),
        ).fetchone()
        return float(row[0]) if row else confidence


def normalize_name(name: str) -> str:
    return " ".join(str(name).strip().lower().split())


def cache_name_mention(name: str, context: str = "", ttl_days: int = DEFAULT_NAME_TTL_DAYS) -> Dict[str, Any]:
    """Store an unconfirmed name temporarily. It is not attached to a person yet."""
    init_identity_db()
    display = " ".join(str(name).strip().split())
    normalized = normalize_name(display)
    if not normalized or len(normalized) < 2:
        return {}
    now_dt = dt.datetime.now(dt.timezone.utc)
    expires = now_dt + dt.timedelta(days=max(1, ttl_days))
    with connect() as conn:
        row = conn.execute(
            "SELECT mention_count, context_json FROM identity_name_cache WHERE normalized_name=?", (normalized,)
        ).fetchone()
        count = int(row[0]) + 1 if row else 1
        contexts = json.loads(row[1]) if row and row[1] else []
        if context:
            contexts = (contexts + [context])[-10:]
        conn.execute(
            "INSERT INTO identity_name_cache(normalized_name,display_name,mention_count,first_seen,last_seen,expires_at,context_json) "
            "VALUES(?,?,?,?,?,?,?) ON CONFLICT(normalized_name) DO UPDATE SET display_name=?,mention_count=?,last_seen=?,expires_at=?,context_json=?",
            (normalized, display, count, now_dt.isoformat(), now_dt.isoformat(), expires.isoformat(), _json(contexts),
             display, count, now_dt.isoformat(), expires.isoformat(), _json(contexts)),
        )
    return {"name": display, "mention_count": count, "expires_at": expires.isoformat(), "context": contexts}


def cleanup_name_cache() -> int:
    init_identity_db()
    now = _now()
    with connect() as conn:
        cur = conn.execute("DELETE FROM identity_name_cache WHERE expires_at < ?", (now,))
        return cur.rowcount


def extract_name_candidates(text: str) -> Iterable[str]:
    """Extract only names from common conversational constructions; caller decides whether to trust them."""
    text = str(text or "")
    patterns = [
        r"\b(?:my name is|i am|i'm|this is)\s+([A-Z][a-z]+(?:[-'][A-Z][a-z]+)?)",
        r"\b(?:that's|that is|his name is|her name is|their name is)\s+([A-Z][a-z]+(?:[-'][A-Z][a-z]+)?)",
        r"\b(?:named|called)\s+([A-Z][a-z]+(?:[-'][A-Z][a-z]+)?)",
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, text, flags=re.IGNORECASE):
            yield match.group(1).strip(".,!? ")


def associate_name_with_person(person_id: str, name: str, source: str,
                                confidence: float = 0.7, confirmed: bool = False,
                                context: str = "") -> float:
    confidence = _clip(1.0 if confirmed else confidence)
    score = add_evidence(person_id, "name", name, confidence, source, 1.0, context)
    with connect() as conn:
        if confirmed:
            norm = normalize_name(name)
            conn.execute("UPDATE identity_name_hypotheses SET confidence=1.0, confirmations=confirmations+1, last_updated=? WHERE person_id=? AND normalized_name=?", (_now(), person_id, norm))
            score = 1.0
            _recompute_confidence(conn, person_id)
        if confirmed or score >= 0.80:
            conn.execute(
                "UPDATE identity_profiles SET display_name=?,status='named' WHERE person_id=?",
                (str(name).strip(), person_id),
            )
    return score


def request_identity_question(person_id: str, question_type: str = "name") -> int:
    init_identity_db()
    question = "What is your name?" if question_type == "name" else "Can you tell me who you are?"
    with connect() as conn:
        existing = conn.execute(
            "SELECT id FROM identity_questions WHERE person_id=? AND question_type=? AND status='pending'",
            (person_id, question_type),
        ).fetchone()
        if existing:
            return int(existing[0])
        cur = conn.execute(
            "INSERT INTO identity_questions(person_id,question_type,question,created_at) VALUES(?,?,?,?)",
            (person_id, question_type, question, _now()),
        )
        return int(cur.lastrowid)


def answer_identity_question(question_id: int, answer_text: str) -> Optional[str]:
    """Record an answer and use it as explicit evidence for the pending identity question."""
    init_identity_db()
    with connect() as conn:
        row = conn.execute(
            "SELECT person_id,question_type FROM identity_questions WHERE id=? AND status='pending'",
            (question_id,),
        ).fetchone()
        if not row:
            return None
        person_id, question_type = row
        conn.execute(
            "UPDATE identity_questions SET status='answered',answered_at=?,answer_text=? WHERE id=?",
            (_now(), answer_text, question_id),
        )
    if question_type == "name":
        candidates = list(extract_name_candidates(answer_text))
        if not candidates:
            # A plain one/two-word answer is allowed as a name candidate.
            candidate = " ".join(str(answer_text).strip().split())
            candidates = [candidate] if 1 <= len(candidate.split()) <= 3 else []
        if candidates:
            associate_name_with_person(person_id, candidates[0], "direct_answer", 1.0, True, answer_text)
            return candidates[0]
    return None


def set_person_fact(person_id: str, fact_type: str, value: Any, confidence: float, source: str) -> int:
    """Store an observable or explicitly supplied fact; newer evidence can supersede it."""
    init_identity_db()
    now = _now()
    confidence = _clip(confidence)
    with connect() as conn:
        conn.execute("UPDATE identity_facts SET status='superseded' WHERE person_id=? AND fact_type=? AND status='current'", (person_id, fact_type))
        cur = conn.execute("INSERT INTO identity_facts(person_id,fact_type,value_json,confidence,source,status,first_seen,last_updated) VALUES(?,?,?,?,?,?,?,?)",
                           (person_id, fact_type, _json(value), confidence, source, 'current', now, now))
        return int(cur.lastrowid)


def get_person_facts(person_id: str):
    init_identity_db()
    with connect() as conn:
        rows = conn.execute("SELECT id,fact_type,value_json,confidence,source,status,first_seen,last_updated FROM identity_facts WHERE person_id=? ORDER BY last_updated DESC", (person_id,)).fetchall()
    return [{"id":r[0],"type":r[1],"value":json.loads(r[2]),"confidence":r[3],"source":r[4],"status":r[5],"first_seen":r[6],"last_updated":r[7]} for r in rows]

def get_profile(person_id: str) -> Optional[Dict[str, Any]]:
    init_identity_db()
    with connect() as conn:
        row = conn.execute("SELECT * FROM identity_profiles WHERE person_id=?", (person_id,)).fetchone()
        if not row:
            return None
        cols = [d[0] for d in conn.execute("SELECT * FROM identity_profiles LIMIT 0").description]
        result = dict(zip(cols, row))
        result["metadata"] = json.loads(result.pop("metadata_json") or "{}")
        result["name_hypotheses"] = [
            {"name": n, "confidence": c, "confirmations": k}
            for n, c, k in conn.execute(
                "SELECT normalized_name,confidence,confirmations FROM identity_name_hypotheses WHERE person_id=? ORDER BY confidence DESC",
                (person_id,),
            )
        ]
        result["facts"] = get_person_facts(person_id)
        return result


def get_repeated_name_candidates(min_mentions: int = 3, limit: int = 20):
    init_identity_db()
    cleanup_name_cache()
    with connect() as conn:
        rows = conn.execute(
            "SELECT display_name,mention_count,last_seen,expires_at FROM identity_name_cache "
            "WHERE mention_count>=? ORDER BY mention_count DESC,last_seen DESC LIMIT ?",
            (min_mentions, limit),
        ).fetchall()
    return [{"name":r[0],"mention_count":r[1],"last_seen":r[2],"expires_at":r[3]} for r in rows]


def link_third_party_name(person_id: str, name: str, confidence: float = 0.55, context: str = "") -> float:
    """Treat a statement such as 'that's Bob' as evidence, not proof."""
    return associate_name_with_person(person_id, name, 'third_party_statement', confidence, False, context)


def contradict_name(person_id: str, name: str, confidence: float = 0.60, context: str = "") -> float:
    """Decrease a name hypothesis without deleting the underlying evidence."""
    return add_evidence(person_id, 'name', name, confidence, 'contradiction', -1.0, context)

def get_repeated_name_candidates(min_mentions: int = 3, limit: int = 20):
    init_identity_db()
    cleanup_name_cache()
    with connect() as conn:
        rows = conn.execute(
            "SELECT display_name,mention_count,last_seen,expires_at FROM identity_name_cache "
            "WHERE mention_count>=? ORDER BY mention_count DESC,last_seen DESC LIMIT ?",
            (min_mentions, limit),
        ).fetchall()
    return [{"name":r[0],"mention_count":r[1],"last_seen":r[2],"expires_at":r[3]} for r in rows]


def link_third_party_name(person_id: str, name: str, confidence: float = 0.55, context: str = "") -> float:
    return associate_name_with_person(person_id, name, 'third_party_statement', confidence, False, context)


def contradict_name(person_id: str, name: str, confidence: float = 0.60, context: str = "") -> float:
    return add_evidence(person_id, 'name', name, confidence, 'contradiction', -1.0, context)

def choose_best_name_candidate(person_id: str) -> Optional[Tuple[str, float]]:
    profile = get_profile(person_id)
    if not profile or not profile["name_hypotheses"]:
        return None
    item = profile["name_hypotheses"][0]
    return item["name"], float(item["confidence"])


def match_sample(modality: str, sample: Any, distance_fn, threshold: float) -> Tuple[Optional[str], float]:
    """Match against stored samples. distance_fn returns a distance; lower is better."""
    init_identity_db()
    best_id = None
    best_distance = math.inf
    with connect() as conn:
        rows = conn.execute(
            "SELECT person_id,embedding_json FROM identity_embeddings WHERE modality=? AND active=1",
            (modality,),
        ).fetchall()
    for person_id, raw in rows:
        try:
            d = float(distance_fn(sample, json.loads(raw)))
            if d < best_distance:
                best_distance, best_id = d, person_id
        except Exception:
            continue
    if best_id is None or best_distance > threshold:
        return None, best_distance if math.isfinite(best_distance) else 1.0
    confidence = _clip(1.0 - (best_distance / max(threshold, 1e-9)))
    return best_id, confidence


def get_recent_person_candidates(window_seconds: int = 8, limit: int = 3):
    """Return recently observed people so speech can be associated with a nearby face."""
    init_identity_db()
    cutoff = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(seconds=max(1, window_seconds))).isoformat()
    with connect() as conn:
        rows = conn.execute(
            "SELECT person_id, MAX(observed_at) AS t, MAX(confidence) AS c "
            "FROM identity_observations WHERE modality='face' AND observed_at>=? "
            "GROUP BY person_id ORDER BY t DESC LIMIT ?",
            (cutoff, limit),
        ).fetchall()
    return [{"person_id": r[0], "observed_at": r[1], "confidence": float(r[2] or 0.0)} for r in rows]


def pending_identity_question(person_id: str) -> Optional[int]:
    init_identity_db()
    with connect() as conn:
        row = conn.execute(
            "SELECT id FROM identity_questions WHERE person_id=? AND status='pending' ORDER BY id DESC LIMIT 1",
            (person_id,),
        ).fetchone()
    return int(row[0]) if row else None


def get_identity_context(person_id: str, max_facts: int = 12) -> str:
    """Return compact, evidence-aware identity context for Qwen.

    This deliberately distinguishes observations/hypotheses from confirmed facts.
    Qwen can use the context for conversation without being allowed to rewrite
    identity state directly.
    """
    profile = get_profile(person_id)
    if not profile:
        return "Identity: no profile available.\n"
    lines = ["Identity profile (local evidence; do not treat uncertain fields as facts):"]
    lines.append(f"Profile ID: {profile['person_id']}")
    lines.append(f"Status: {profile['status']}")
    if profile.get('display_name'):
        lines.append(f"Current name: {profile['display_name']} (name confidence {profile['name_confidence']:.2f})")
    else:
        lines.append("Current name: unknown")
    lines.append(f"Face confidence: {profile['face_confidence']:.2f}; voice confidence: {profile['voice_confidence']:.2f}; combined identity confidence: {profile['identity_confidence']:.2f}")
    hypotheses = profile.get('name_hypotheses') or []
    if hypotheses:
        lines.append("Name hypotheses: " + ", ".join(f"{h['name']} ({float(h['confidence']):.2f}, {h['confirmations']} confirmations)" for h in hypotheses[:5]))
    facts = [f for f in (profile.get('facts') or []) if f.get('status') == 'current'][:max_facts]
    if facts:
        lines.append("Current profile facts:")
        for fact in facts:
            lines.append(f"- {fact['type']}: {json.dumps(fact['value'], ensure_ascii=False)} (confidence {float(fact['confidence']):.2f}, source {fact['source']})")
    lines.append("Identity rule: observations are evidence, not certainty; contradictory evidence may lower confidence.")
    return "\n".join(lines) + "\n"
