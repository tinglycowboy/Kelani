#!/usr/bin/env python3
import re

ROUTES = {
    "dictionary": {"patterns": [r"\b(what does \w+ mean|define|definition of|synonym for)\b"], "priority": 1, "bypass_ai": False},
    "emergency": {"patterns": [r"\b(help|emergency|choking|burn|bleeding|first aid)\b"], "priority": 0, "bypass_ai": False},
    "jokes": {"patterns": [r"\b(tell me a joke|make me laugh|funny)\b"], "priority": 1, "bypass_ai": False},
    "banter": {"patterns": [r"\b(roast me|you're \w+|shut up|insult me)\b"], "priority": 1, "bypass_ai": False},
    "physics": {"patterns": [r"\b(speed of light|newton's law|ohm's law|physics formula)\b"], "priority": 1, "bypass_ai": False},
    "calculus": {"patterns": [r"\b(derivative of|integral of|power rule|chain rule)\b"], "priority": 1, "bypass_ai": False},
    "acronyms": {"patterns": [r"\b(what does \w+ stand for|acronym for)\b"], "priority": 1, "bypass_ai": False},
    "memory": {"patterns": [r"\b(did we talk|remember when|did i mention|do you recall|previous conversation|last time)\b"], "priority": 2, "bypass_ai": False},
    "wikipedia": {"patterns": [r"\b(who is|who was|what is|tell me about|history of|how does|why does|when did|where is)\b"], "priority": 3, "bypass_ai": False},
}

def determine_route(text, nlp_result=None):
    matches=[]
    for name, cfg in ROUTES.items():
        for pattern in cfg["patterns"]:
            if re.search(pattern, text, re.I):
                matches.append((cfg["priority"], name)); break
    if matches:
        _, route = sorted(matches, key=lambda x: (x[0], x[1]))[0]
    else:
        route = "ai_general"
    return {"route": route, "confidence": 1.0 if matches else 0.5, "bypass_ai": ROUTES.get(route, {}).get("bypass_ai", False)}

def get_route_handler(route):
    return f"handle_{route}"
