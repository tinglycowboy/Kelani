import os,sqlite3,hashlib,datetime,json
from config import DB_PATH,LIBRARIES_DIR
SCHEMA=r"""
CREATE TABLE IF NOT EXISTS library_sources(id INTEGER PRIMARY KEY,name TEXT UNIQUE,kind TEXT,root_path TEXT,description TEXT,created_at TEXT);
CREATE TABLE IF NOT EXISTS library_documents(id INTEGER PRIMARY KEY,source_id INTEGER,external_id TEXT,title TEXT,author TEXT,path TEXT UNIQUE,mime_type TEXT,size_bytes INTEGER,sha256 TEXT,status TEXT DEFAULT 'raw',metadata_json TEXT,added_at TEXT,analyzed_at TEXT,FOREIGN KEY(source_id) REFERENCES library_sources(id));
CREATE TABLE IF NOT EXISTS library_chunks(id INTEGER PRIMARY KEY,document_id INTEGER,chunk_index INTEGER,start_offset INTEGER,end_offset INTEGER,text TEXT,UNIQUE(document_id,chunk_index));
CREATE TABLE IF NOT EXISTS library_analysis(id INTEGER PRIMARY KEY,document_id INTEGER,chunk_id INTEGER,model TEXT,analysis_type TEXT,summary TEXT,opinion TEXT,tags TEXT,confidence REAL,created_at TEXT);
CREATE TABLE IF NOT EXISTS memory_items(id INTEGER PRIMARY KEY,category TEXT,source_type TEXT,source_id INTEGER,title TEXT,content TEXT,importance REAL DEFAULT .5,created_at TEXT,updated_at TEXT,metadata_json TEXT);
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(title,content,category,content='memory_items',content_rowid='id');
CREATE TABLE IF NOT EXISTS analysis_queue(id INTEGER PRIMARY KEY,document_id INTEGER UNIQUE,priority INTEGER DEFAULT 50,status TEXT DEFAULT 'queued',attempts INTEGER DEFAULT 0,next_run_at TEXT,last_error TEXT,created_at TEXT,updated_at TEXT);
CREATE INDEX IF NOT EXISTS idx_docs_source_status ON library_documents(source_id,status); CREATE INDEX IF NOT EXISTS idx_queue_status_priority ON analysis_queue(status,priority,next_run_at); CREATE INDEX IF NOT EXISTS idx_memory_category ON memory_items(category);
"""
def connect():
 c=sqlite3.connect(DB_PATH,timeout=30); c.execute('PRAGMA journal_mode=WAL'); c.execute('PRAGMA synchronous=NORMAL'); return c
def init_library_store():
 with connect() as c:
  c.executescript(SCHEMA)
  for n,k,p,d in [('Books','books','books','Raw books'),('Music','music','music','Raw music'),('Wikipedia','wikipedia','wikipedia','Raw Wikipedia'),('Bible','bible','bible','Bible sources'),('Other','other','other','Other offline libraries')]:
   c.execute('INSERT OR IGNORE INTO library_sources(name,kind,root_path,description,created_at) VALUES(?,?,?,?,?)',(n,k,os.path.join(LIBRARIES_DIR,p),d,datetime.datetime.now().isoformat()))
def _sha256(path):
 h=hashlib.sha256(); f=open(path,'rb')
 for b in iter(lambda:f.read(1048576),b''): h.update(b)
 f.close(); return h.hexdigest()
def register_document(kind,path,title=None,author=None,external_id=None,metadata=None,queue=True):
 init_library_store(); path=os.path.abspath(path)
 if not os.path.isfile(path): return None
 with connect() as c:
  src=c.execute('SELECT id FROM library_sources WHERE kind=?',(kind,)).fetchone()
  if not src: raise ValueError(kind)
  row=c.execute('SELECT id FROM library_documents WHERE path=?',(path,)).fetchone()
  if row: did=row[0]
  else:
   did=c.execute('INSERT INTO library_documents(source_id,external_id,title,author,path,size_bytes,sha256,status,metadata_json,added_at) VALUES(?,?,?,?,?,?,?,?,?,?)',(src[0],external_id,title or os.path.basename(path),author,path,os.path.getsize(path),_sha256(path),'raw',json.dumps(metadata or {}),datetime.datetime.now().isoformat())).lastrowid
  if queue:
   now=datetime.datetime.now().isoformat(); c.execute('INSERT INTO analysis_queue(document_id,priority,status,created_at,updated_at) VALUES(?,50,"queued",?,?) ON CONFLICT(document_id) DO UPDATE SET status=CASE WHEN analysis_queue.status="done" THEN "done" ELSE "queued" END,updated_at=?',(did,now,now,now))
  return did
def add_memory(category,content,title='',source_type=None,source_id=None,importance=.5,metadata=None):
 now=datetime.datetime.now().isoformat()
 with connect() as c:
  did=c.execute('INSERT INTO memory_items(category,source_type,source_id,title,content,importance,created_at,updated_at,metadata_json) VALUES(?,?,?,?,?,?,?,?,?)',(category,source_type,source_id,title,content,importance,now,now,json.dumps(metadata or {}))).lastrowid
  c.execute('INSERT INTO memory_fts(rowid,title,content,category) VALUES(?,?,?,?)',(did,title,content,category)); return did
def queue_stats():
 with connect() as c: return dict(c.execute('SELECT status,COUNT(*) FROM analysis_queue GROUP BY status').fetchall())
