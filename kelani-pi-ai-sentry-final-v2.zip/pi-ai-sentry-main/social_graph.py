#!/usr/bin/env python3
import sqlite3
import datetime
import json

DB_PATH = "ai_sentry.db"

def init_social_graph_db():
    """Create social relationship tables"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS social_relationships (
            id TEXT PRIMARY KEY,
            person_a_id TEXT,
            person_b_id TEXT,
            relationship_type TEXT,
            strength REAL DEFAULT 0.5,
            notes TEXT,
            last_updated TEXT,
            FOREIGN KEY (person_a_id) REFERENCES persons(id),
            FOREIGN KEY (person_b_id) REFERENCES persons(id)
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS private_information (
            id TEXT PRIMARY KEY,
            person_id TEXT,
            information_type TEXT,
            information TEXT,
            is_private BOOLEAN DEFAULT 1,
            shared_with TEXT,
            timestamp TEXT,
            FOREIGN KEY (person_id) REFERENCES persons(id)
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS trust_violations (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            person_who_knew TEXT,
            person_who_learned TEXT,
            information_type TEXT,
            severity TEXT,
            notes TEXT
        )
    """)
    
    conn.commit()
    conn.close()

def add_relationship(person_a_id, person_b_id, relationship_type, strength=0.5, notes=None):
    """Add or update relationship between two people"""
    import uuid
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Check if relationship already exists
    c.execute("""
        SELECT id FROM social_relationships 
        WHERE (person_a_id = ? AND person_b_id = ?) OR (person_a_id = ? AND person_b_id = ?)
    """, (person_a_id, person_b_id, person_b_id, person_a_id))
    
    existing = c.fetchone()
    
    if existing:
        c.execute("""
            UPDATE social_relationships 
            SET relationship_type = ?, strength = ?, notes = ?, last_updated = ?
            WHERE id = ?
        """, (relationship_type, strength, notes, str(datetime.datetime.now()), existing[0]))
    else:
        c.execute("""
            INSERT INTO social_relationships (id, person_a_id, person_b_id, relationship_type, strength, notes, last_updated)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (str(uuid.uuid4()), person_a_id, person_b_id, relationship_type, strength, notes, str(datetime.datetime.now())))
    
    conn.commit()
    conn.close()

def get_relationship(person_a_id, person_b_id):
    """Get relationship between two people"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        SELECT relationship_type, strength, notes
        FROM social_relationships
        WHERE (person_a_id = ? AND person_b_id = ?) OR (person_a_id = ? AND person_b_id = ?)
    """, (person_a_id, person_b_id, person_b_id, person_a_id))
    
    result = c.fetchone()
    conn.close()
    
    if result:
        return {"type": result[0], "strength": result[1], "notes": result[2]}
    return None

def store_private_info(person_id, info_type, information, is_private=True):
    """Store private information about a person"""
    import uuid
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        INSERT INTO private_information (id, person_id, information_type, information, is_private, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), person_id, info_type, information, is_private, str(datetime.datetime.now())))
    
    conn.commit()
    conn.close()

def can_share_info(about_person_id, with_person_id):
    """Check if AI can share information about one person with another"""
    from person_profile import get_trust_score
    
    # Get trust scores
    about_trust = get_trust_score(about_person_id)
    with_trust = get_trust_score(with_person_id)
    
    # Check if there's a relationship
    relationship = get_relationship(about_person_id, with_person_id)
    
    # Rules:
    # 1. Can share if both have high trust (>0.7)
    # 2. Can share if they have a strong relationship (strength > 0.7)
    # 3. Cannot share if about_person has low trust in with_person
    # 4. Cannot share private information unless explicitly allowed
    
    if about_trust < 0.3 or with_trust < 0.3:
        return False, "Trust levels too low"
    
    if relationship and relationship['strength'] > 0.7:
        return True, "Strong relationship exists"
    
    if about_trust > 0.7 and with_trust > 0.7:
        return True, "Both have high trust"
    
    return False, "Insufficient trust or relationship"

def log_trust_violation(person_who_knew, person_who_learned, info_type, severity, notes):
    """Log when private information was shared inappropriately"""
    import uuid
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        INSERT INTO trust_violations (id, timestamp, person_who_knew, person_who_learned, information_type, severity, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), str(datetime.datetime.now()), person_who_knew, person_who_learned, info_type, severity, notes))
    
    conn.commit()
    conn.close()
    
    # Reduce trust scores
    from person_profile import update_trust_score
    update_trust_score(person_who_knew, -0.1)  # Person who leaked info loses trust
    update_trust_score(person_who_learned, -0.05)  # Person who received leaked info also loses some trust

def get_ai_perception_of_person(target_person_id, asking_person_id):
    """Get what AI can say about target person to asking person"""
    from person_profile import get_person_profile
    
    can_share, reason = can_share_info(target_person_id, asking_person_id)
    
    if not can_share:
        return "I prefer not to share that information."
    
    profile = get_person_profile(target_person_id)
    if not profile:
        return "I don't know much about them."
    
    # Build response based on what can be shared
    response_parts = []
    
    if profile.get('name'):
        response_parts.append(f"Their name is {profile['name']}.")
    
    if profile.get('hobbies'):
        hobbies = profile['hobbies']
        if isinstance(hobbies, list) and hobbies:
            response_parts.append(f"They enjoy {', '.join(hobbies[:3])}.")
    
    if profile.get('interests'):
        interests = profile['interests']
        if isinstance(interests, list) and interests:
            response_parts.append(f"They're interested in {', '.join(interests[:3])}.")
    
    relationship = get_relationship(target_person_id, asking_person_id)
    if relationship:
        response_parts.append(f"I understand you two are {relationship['type']}.")
    
    return ' '.join(response_parts) if response_parts else "I don't have much information to share."

if __name__ == "__main__":
    init_social_graph_db()
    print("Social graph system initialized!")
  
