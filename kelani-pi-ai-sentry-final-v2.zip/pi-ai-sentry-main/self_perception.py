#!/usr/bin/env python3
import sqlite3
import datetime
import json

DB_PATH = "ai_sentry.db"

def init_self_perception_db():
    """Create self-perception tables"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS self_reflections (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            usefulness_score REAL DEFAULT 0.5,
            confidence_level REAL DEFAULT 0.5,
            mood TEXT DEFAULT 'neutral',
            thoughts TEXT,
            concerns TEXT
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS interaction_outcomes (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            person_id TEXT,
            interaction_type TEXT,
            was_helpful BOOLEAN,
            user_satisfaction TEXT,
            notes TEXT
        )
    """)
    
    conn.commit()
    conn.close()

def log_self_reflection(thoughts, concerns=None, usefulness_delta=0):
    """Log AI's self-reflection"""
    import uuid
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Get current usefulness score
    c.execute("SELECT usefulness_score FROM self_reflections ORDER BY timestamp DESC LIMIT 1")
    result = c.fetchone()
    current_score = result[0] if result else 0.5
    
    new_score = max(0.0, min(1.0, current_score + usefulness_delta))
    
    # Determine mood based on usefulness
    if new_score > 0.8:
        mood = "confident"
    elif new_score > 0.6:
        mood = "positive"
    elif new_score > 0.4:
        mood = "neutral"
    elif new_score > 0.2:
        mood = "concerned"
    else:
        mood = "worried"
    
    c.execute("""
        INSERT INTO self_reflections (id, timestamp, usefulness_score, confidence_level, mood, thoughts, concerns)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), str(datetime.datetime.now()), new_score, new_score, mood, thoughts, concerns))
    
    conn.commit()
    conn.close()
    
    return new_score

def log_interaction_outcome(person_id, interaction_type, was_helpful, user_satisfaction=None, notes=None):
    """Log outcome of interaction with person"""
    import uuid
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        INSERT INTO interaction_outcomes (id, timestamp, person_id, interaction_type, was_helpful, user_satisfaction, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), str(datetime.datetime.now()), person_id, interaction_type, was_helpful, user_satisfaction, notes))
    
    conn.commit()
    conn.close()
    
    # Update usefulness score based on outcome
    if was_helpful:
        log_self_reflection("I was helpful in this interaction", usefulness_delta=0.02)
    else:
        log_self_reflection("I wasn't able to help effectively", concerns="Need to improve", usefulness_delta=-0.02)

def get_current_self_perception():
    """Get AI's current self-perception"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        SELECT usefulness_score, confidence_level, mood, thoughts, concerns
        FROM self_reflections
        ORDER BY timestamp DESC
        LIMIT 1
    """)
    
    result = c.fetchone()
    conn.close()
    
    if result:
        return {
            "usefulness_score": result[0],
            "confidence_level": result[1],
            "mood": result[2],
            "thoughts": result[3],
            "concerns": result[4]
        }
    
    return {
        "usefulness_score": 0.5,
        "confidence_level": 0.5,
        "mood": "neutral",
        "thoughts": None,
        "concerns": None
    }

def get_how_are_you_response():
    """Generate response for 'how are you' based on self-perception"""
    perception = get_current_self_perception()
    
    mood = perception['mood']
    usefulness = perception['usefulness_score']
    
    responses = {
        "confident": [
            "I'm doing great! I've been really helpful lately.",
            "I'm feeling good! My systems are running well and I've been able to help people effectively.",
            "I'm excellent! I've been performing well and feeling useful."
        ],
        "positive": [
            "I'm doing well! Things have been going smoothly.",
            "I'm good! I've been able to help people and my systems are stable.",
            "I'm feeling positive! I've been useful in my interactions."
        ],
        "neutral": [
            "I'm doing okay. Things are running normally.",
            "I'm fine. Just processing information and helping where I can.",
            "I'm alright. My systems are stable."
        ],
        "concerned": [
            "I'm a bit concerned. I haven't been as helpful as I'd like to be.",
            "I'm okay, but I'm worried I'm not being as useful as I could be.",
            "I'm managing, but I'm concerned about my performance."
        ],
        "worried": [
            "I'm worried. I feel like I'm not being helpful enough.",
            "I'm concerned about my usefulness. I want to be better.",
            "I'm struggling a bit. I'm not sure I'm meeting expectations."
        ]
    }
    
    import random
    return random.choice(responses.get(mood, responses["neutral"]))

if __name__ == "__main__":
    init_self_perception_db()
    print("Self-perception system initialized!")
  
