#!/usr/bin/env python3
"""Music Manager: Downloads, deduplicates, analyzes, and curates music playlists"""
import os
import sqlite3
import datetime
import subprocess
import uuid
import hashlib
from collections import Counter

from config import DB_PATH, MUSIC_DIR, TEMP_DIR
MUSIC_PATH = MUSIC_DIR
TEMP_MUSIC_PATH = os.path.join(TEMP_DIR,"music")

def init_music_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""CREATE TABLE IF NOT EXISTS songs (
        song_id TEXT PRIMARY KEY,
        title TEXT,
        artist TEXT,
        album TEXT,
        file_path TEXT,
        is_explicit BOOLEAN DEFAULT 0,
        lyrics TEXT,
        mood_tags TEXT,
        ai_opinion TEXT,
        added_date TEXT,
        analyzed BOOLEAN DEFAULT 0,
        source TEXT DEFAULT 'user_library'
    )""")
    
    c.execute("""CREATE TABLE IF NOT EXISTS ai_playlists (
        playlist_id TEXT PRIMARY KEY,
        name TEXT UNIQUE,
        created_by TEXT DEFAULT 'AI',
        creation_reason TEXT,
        created_date TEXT
    )""")
    
    c.execute("""CREATE TABLE IF NOT EXISTS playlist_songs (
        playlist_id TEXT,
        song_id TEXT,
        position INTEGER,
        PRIMARY KEY (playlist_id, song_id)
    )""")
    
    c.execute("""CREATE TABLE IF NOT EXISTS user_feedback (
        id TEXT PRIMARY KEY,
        song_id TEXT,
        session_id TEXT,
        feedback_type TEXT,
        comment TEXT,
        timestamp TEXT
    )""")
    
    conn.commit()
    conn.close()

def get_file_hash(filepath):
    hash_md5 = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def download_spotify_link(playlist_url, progress_callback):
    os.makedirs(MUSIC_PATH, exist_ok=True)
    os.makedirs(TEMP_MUSIC_PATH, exist_ok=True)
    progress_callback(0, "Starting download...")
    
    cmd = [
        "yt-dlp", "-x", "--audio-format", "mp3", "--embed-metadata",
        "--no-overwrites", "-o", f"{TEMP_MUSIC_PATH}/%(title)s - %(artist)s.%(ext)s",
        playlist_url
    ]
    
    try:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        total_files = 0
        processed_files = 0
        
        for line in process.stdout:
            if "Downloading" in line or "Merger" in line:
                progress_callback(processed_files, f"Processing: {line.strip()[:50]}...")
            if "has already been downloaded" in line or "Destination" in line:
                total_files += 1
        
        process.wait()
        if process.returncode != 0:
            return False, "Download failed."
            
        progress_callback(total_files, "Deduplicating and organizing files...")
        new_songs_added = 0
        
        for filename in os.listdir(TEMP_MUSIC_PATH):
            if filename.endswith(".mp3"):
                temp_path = os.path.join(TEMP_MUSIC_PATH, filename)
                file_hash = get_file_hash(temp_path)
                existing_path = None
                
                for root, _, files in os.walk(MUSIC_PATH):
                    for f in files:
                        if f.endswith(".mp3"):
                            f_path = os.path.join(root, f)
                            if get_file_hash(f_path) == file_hash:
                                existing_path = f_path
                                break
                    if existing_path: break
                
                if existing_path:
                    os.remove(temp_path)
                    link_name = os.path.join(MUSIC_PATH, filename)
                    os.link(existing_path, link_name)
                else:
                    os.rename(temp_path, os.path.join(MUSIC_PATH, filename))
                
                new_songs_added += 1
                processed_files += 1
                progress_callback(processed_files, f"Organized {processed_files}/{total_files} files")
        
        scan_new_music()
        return True, f"Successfully processed {new_songs_added} songs."
    except Exception as e:
        return False, str(e)

def scan_new_music():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    for filename in os.listdir(MUSIC_PATH):
        if filename.endswith(".mp3"):
            file_path = os.path.join(MUSIC_PATH, filename)
            c.execute("SELECT song_id FROM songs WHERE file_path = ?", (file_path,))
            if not c.fetchone():
                song_id = str(uuid.uuid4())
                parts = filename.replace(".mp3", "").split(" - ")
                title = parts[0].strip() if len(parts) > 0 else filename
                artist = parts[1].strip() if len(parts) > 1 else "Unknown"
                is_explicit = 1 if "explicit" in filename.lower() else 0
                c.execute("""INSERT INTO songs (song_id, title, artist, file_path, is_explicit, added_date)
                             VALUES (?, ?, ?, ?, ?, ?)""",
                          (song_id, title, artist, file_path, is_explicit, str(datetime.datetime.now())))
    conn.commit()
    conn.close()

def get_unanalyzed_songs(limit=1):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""SELECT song_id, title, artist, album, file_path FROM songs 
                 WHERE analyzed = 0 LIMIT ?""", (limit,))
    rows = c.fetchall()
    conn.close()
    return [{"song_id": r[0], "title": r[1], "artist": r[2], "album": r[3], "file_path": r[4]} for r in rows]

def save_song_analysis(song_id, mood_tags, ai_opinion):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""UPDATE songs SET mood_tags = ?, ai_opinion = ?, analyzed = 1 WHERE song_id = ?""", 
              (mood_tags, ai_opinion, song_id))
    conn.commit()
    conn.close()

def create_ai_playlist(name, reason, song_ids):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    playlist_id = str(uuid.uuid4())
    try:
        c.execute("""INSERT INTO ai_playlists (playlist_id, name, created_by, creation_reason, created_date)
                     VALUES (?, ?, 'AI', ?, ?)""",
                  (playlist_id, name, reason, str(datetime.datetime.now())))
        for i, song_id in enumerate(song_ids):
            c.execute("""INSERT OR IGNORE INTO playlist_songs (playlist_id, song_id, position)
                         VALUES (?, ?, ?)""", (playlist_id, song_id, i))
        conn.commit()
    except sqlite3.IntegrityError:
        pass # Playlist name already exists
    finally:
        conn.close()
    return playlist_id

def add_song_to_existing_playlist(playlist_name, song_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT playlist_id FROM ai_playlists WHERE name = ?", (playlist_name,))
    row = c.fetchone()
    if row:
        playlist_id = row[0]
        c.execute("SELECT MAX(position) FROM playlist_songs WHERE playlist_id = ?", (playlist_id,))
        max_pos = c.fetchone()[0] or -1
        c.execute("""INSERT OR IGNORE INTO playlist_songs (playlist_id, song_id, position)
                     VALUES (?, ?, ?)""", (playlist_id, song_id, max_pos + 1))
        conn.commit()
    conn.close()

def log_user_feedback(song_id, session_id, feedback_type, comment=""):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""INSERT INTO user_feedback (id, song_id, session_id, feedback_type, comment, timestamp)
                 VALUES (?, ?, ?, ?, ?, ?)""",
              (str(uuid.uuid4()), song_id, session_id, feedback_type, comment, str(datetime.datetime.now())))
    conn.commit()
    conn.close()

def get_user_preferences(session_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""SELECT s.mood_tags FROM user_feedback f
                 JOIN songs s ON f.song_id = s.song_id
                 WHERE f.session_id = ? AND f.feedback_type = 'liked' AND s.mood_tags IS NOT NULL""", (session_id,))
    rows = c.fetchall()
    conn.close()
    
    liked_tags = []
    for row in rows:
        if row[0]:
            liked_tags.extend([tag.strip() for tag in row[0].split(',')])
    
    return [tag for tag, count in Counter(liked_tags).most_common(3)]

def get_song_recommendations(mood_or_tags, limit=5):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""SELECT title, artist, ai_opinion, song_id FROM songs 
                 WHERE analyzed = 1 AND (mood_tags LIKE ? OR ai_opinion LIKE ?)
                 ORDER BY RANDOM() LIMIT ?""", 
              (f"%{mood_or_tags}%", f"%{mood_or_tags}%", limit))
    rows = c.fetchall()
    conn.close()
    return [{"title": r[0], "artist": r[1], "opinion": r[2], "song_id": r[3]} for r in rows]

def play_song(file_path):
    try:
        subprocess.Popen(["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", file_path])
        return True
    except Exception as e:
        print(f"Playback error: {e}")
        return False

if __name__ == "__main__":
    init_music_db()
    print("✅ Music Manager initialized.")
