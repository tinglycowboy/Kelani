#!/usr/bin/env python3
"""Storage Manager: Monitors disk space and intelligently prunes old data"""
import os
import shutil
import sqlite3
import datetime
import requests

DB_PATH = "ai_sentry.db"
OLLAMA_API = "http://localhost:11434/api/generate"
LIGHT_MODEL = "qwen3:0.6b"

# Thresholds
TRIGGER_THRESHOLD = 98.0  # Start cleaning when storage is this full
TARGET_THRESHOLD = 90.0   # Stop cleaning when storage drops to this

def get_storage_usage():
    """Get current disk usage percentage of the root filesystem"""
    try:
        usage = shutil.disk_usage('/')
        percent_used = (usage.used / usage.total) * 100
        return percent_used, usage.used, usage.total
    except Exception as e:
        print(f"Storage check error: {e}")
        return 0.0, 0, 0

def prune_by_age():
    """Delete old, ephemeral data based on strict retention rules"""
    print("🧹 Storage Manager: Running rule-based age pruning...")
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    now = datetime.datetime.now()
    
    # 1. Delete visual events older than 7 days
    cutoff_7d = (now - datetime.timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
    c.execute("DELETE FROM visual_events WHERE timestamp < ?", (cutoff_7d,))
    visual_deleted = c.rowcount
    
    # 2. Delete audio events older than 7 days
    c.execute("DELETE FROM audio_events WHERE timestamp < ?", (cutoff_7d,))
    audio_deleted = c.rowcount
    
    # 3. Delete system/watchdog logs older than 14 days
    cutoff_14d = (now - datetime.timedelta(days=14)).strftime("%Y-%m-%d %H:%M:%S")
    c.execute("DELETE FROM watchdog_logs WHERE timestamp < ?", (cutoff_14d,))
    c.execute("DELETE FROM safety_logs WHERE timestamp < ?", (cutoff_14d,))
    
    # 4. Delete general chat logs older than 60 days (Keep recent memory)
    cutoff_60d = (now - datetime.timedelta(days=60)).strftime("%Y-%m-%d %H:%M:%S")
    c.execute("DELETE FROM logs WHERE timestamp < ? AND source_tag != 'PROACTIVE_INITIATION'", (cutoff_60d,))
    logs_deleted = c.rowcount
    
    conn.commit()
    conn.close()
    
    print(f"   ✅ Pruned: {visual_deleted} visual, {audio_deleted} audio, {logs_deleted} log entries.")

def ai_evaluate_old_persons():
    """Use AI to decide if old, inactive person profiles should be forgotten"""
    print("🧠 Storage Manager: AI evaluating old person profiles for deletion...")
    conn = sqlite


def manage_storage():
    """Run storage cleanup only when the configured threshold is exceeded."""
    percent, _, _ = get_storage_usage()
    if percent >= TRIGGER_THRESHOLD:
        prune_by_age()
        percent, _, _ = get_storage_usage()
        print(f"Storage after pruning: {percent:.1f}%")
    return percent
