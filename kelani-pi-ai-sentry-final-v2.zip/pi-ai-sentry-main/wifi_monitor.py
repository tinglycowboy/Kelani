#!/usr/bin/env python3
"""WiFi Monitor: Checks connection and attempts reconnection every 5 minutes"""
import subprocess
import time
import sqlite3
import datetime
import uuid
import os

DB_PATH = "ai_sentry.db"
CHECK_INTERVAL = 300  # 5 minutes

def init_wifi_db():
    """Create WiFi log table"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS wifi_logs (
        id TEXT PRIMARY KEY,
        timestamp TEXT,
        status TEXT,
        ssid TEXT,
        signal_strength INTEGER,
        action_taken TEXT
    )""")
    conn.commit()
    conn.close()

def check_wifi_status():
    """Check if WiFi is connected"""
    try:
        result = subprocess.run(['iwgetid', '-r'], capture_output=True, text=True, timeout=10)
        if result.returncode == 0 and result.stdout.strip():
            ssid = result.stdout.strip()
            
            # Get signal strength
            signal_result = subprocess.run(['iwconfig', 'wlan0'], capture_output=True, text=True, timeout=10)
            signal_strength = 0
            for line in signal_result.stdout.split('\n'):
                if 'Signal level' in line:
                    try:
                        signal_strength = int(line.split('Signal level=')[1].split()[0])
                    except:
                        pass
            
            return True, ssid, signal_strength
        return False, None, 0
    except:
        return False, None, 0

def attempt_reconnection():
    """Attempt to reconnect to saved WiFi networks"""
    print("📡 WiFi disconnected. Attempting reconnection...")
    
    try:
        # Try to reconnect using NetworkManager
        result = subprocess.run(['nmcli', 'connection', 'up', 'id', 'preconfigured'], 
                              capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            print("✅ Reconnection successful")
            return True, "nmcli_reconnect"
        
        # Alternative: restart WiFi interface
        subprocess.run(['sudo', 'ifdown', 'wlan0'], capture_output=True, timeout=10)
        time.sleep(2)
        subprocess.run(['sudo', 'ifup', 'wlan0'], capture_output=True, timeout=30)
        
        # Check if reconnected
        time.sleep(5)
        connected, ssid, signal = check_wifi_status()
        if connected:
            print(f"✅ Reconnected to {ssid}")
            return True, "ifup_ifdown"
        
        return False, "reconnection_failed"
    except Exception as e:
        print(f"⚠️ Reconnection error: {e}")
        return False, f"error: {e}"

def log_wifi_event(status, ssid, signal, action):
    """Log WiFi event to database"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""INSERT INTO wifi_logs (id, timestamp, status, ssid, signal_strength, action_taken)
                 VALUES (?, ?, ?, ?, ?, ?)""",
              (str(uuid.uuid4()), str(datetime.datetime.now()), status, ssid, signal, action))
    conn.commit()
    conn.close()

def wifi_monitor_loop():
    """Main WiFi monitoring loop"""
    print("📡 WiFi Monitor started - checking every 5 minutes")
    init_wifi_db()
    
    while True:
        try:
            connected, ssid, signal = check_wifi_status()
            
            if connected:
                print(f"📡 WiFi connected to {ssid} (signal: {signal} dBm)")
                log_wifi_event("connected", ssid, signal, "none")
            else:
                print("📡 WiFi disconnected")
                log_wifi_event("disconnected", None, 0, "attempting_reconnection")
                
                success, action = attempt_reconnection()
                
                if success:
                    connected, ssid, signal = check_wifi_status()
                    log_wifi_event("reconnected", ssid, signal, action)
                else:
                    log_wifi_event("disconnected", None, 0, action)
            
            time.sleep(CHECK_INTERVAL)
        except Exception as e:
            print(f"WiFi monitor error: {e}")
            time.sleep(60)

if __name__ == "__main__":
    wifi_monitor_loop()
