#!/usr/bin/env python3
import sqlite3

DB_PATH = "ai_sentry.db"

def init_slang_db():
    """Create slang_vocabulary table and populate with default entries"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS slang_vocabulary (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            slang_term TEXT UNIQUE,
            meaning TEXT,
            category TEXT,
            source TEXT DEFAULT 'default'
        )
    """)
    
    # Check if already populated
    c.execute("SELECT COUNT(*) FROM slang_vocabulary")
    if c.fetchone()[0] > 0:
        conn.close()
        return
    
    # Default slang vocabulary
    slang_entries = [
        ("bruh", "friend, dude, or expression of disbelief", "greeting", "default"),
        ("cap", "lie or exaggeration", "expression", "default"),
        ("no cap", "truthful, not lying", "expression", "default"),
        ("bet", "okay, agreed, yes", "agreement", "default"),
        ("bussin", "really good, especially food", "positive", "default"),
        ("sus", "suspicious", "negative", "default"),
        ("yeet", "to throw something or expression of excitement", "action", "default"),
        ("drip", "stylish outfit or appearance", "positive", "default"),
        ("slay", "to do something exceptionally well", "positive", "default"),
        ("fr", "for real, seriously", "expression", "default"),
        ("ong", "on god, I swear, seriously", "expression", "default"),
        ("finna", "going to, about to", "action", "default"),
        ("tryna", "trying to", "action", "default"),
        ("ion", "I don't", "expression", "default"),
        ("lowkey", "somewhat, secretly, kind of", "expression", "default"),
        ("highkey", "very much, obviously", "expression", "default"),
        ("mid", "mediocre, average, not good", "negative", "default"),
        ("based", "admirable, agreeable, authentic", "positive", "default"),
        ("cringe", "embarrassing, awkward", "negative", "default"),
        ("goated", "greatest of all time", "positive", "default"),
        ("sheesh", "expression of surprise or impressiveness", "expression", "default"),
        ("rizz", "charisma, charm, ability to attract", "positive", "default"),
        ("gyatt", "expression of surprise at someone's appearance", "expression", "default"),
        ("skibidi", "nonsense word, often used humorously", "expression", "default"),
        ("sigma", "independent, self-reliant person", "positive", "default"),
        ("mewing", "jawline exercise, or looking good", "positive", "default"),
        ("fanum tax", "taking someone's food", "action", "default"),
        ("ohio", "weird or strange", "negative", "default"),
        ("bop", "a good song", "positive", "default"),
        ("ate", "did something really well", "positive", "default"),
        ("left no crumbs", "did something perfectly", "positive", "default"),
        ("it's giving", "it reminds me of, it has the vibe of", "expression", "default"),
        ("slaps", "is really good, especially music", "positive", "default"),
        ("fire", "really good, amazing", "positive", "default"),
        ("dead", "extremely funny, dying of laughter", "positive", "default"),
        ("rent free", "can't stop thinking about something", "expression", "default"),
        ("main character", "someone acting like they're the center of attention", "expression", "default"),
        ("npc", "someone acting robotic or unoriginal", "negative", "default"),
        ("touch grass", "go outside, get off the internet", "action", "default"),
        ("ratio", "to get more replies than likes, or to disagree", "negative", "default"),
        ("vibe check", "assessing someone's mood or energy", "action", "default"),
        ("ick", "something that causes disgust or turns you off", "negative", "default"),
        ("delulu", "delusional", "negative", "default"),
        ("solulu", "solution", "positive", "default"),
        ("era", "a phase or period of someone's life", "expression", "default"),
        ("aesthetic", "visually pleasing style or vibe", "positive", "default"),
        ("glow up", "significant improvement in appearance", "positive", "default"),
        ("tea", "gossip or drama", "expression", "default"),
        ("shade", "subtle disrespect or insult", "negative", "default"),
        ("salty", "bitter, upset, or irritated", "negative", "default"),
    ]
    
    c.executemany("INSERT OR IGNORE INTO slang_vocabulary (slang_term, meaning, category, source) VALUES (?, ?, ?, ?)", slang_entries)
    conn.commit()
    conn.close()
    print(f"📖 Loaded {len(slang_entries)} slang terms into database")

def get_slang_context(text):
    """Check if text contains slang and return definitions"""
    text_lower = text.lower()
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("SELECT slang_term, meaning FROM slang_vocabulary")
    all_slang = c.fetchall()
    conn.close()
    
    found_slang = []
    unknown_slang = []
    
    # Check for known slang
    for term, meaning in all_slang:
        if term in text_lower:
            found_slang.append(f"'{term}' means: {meaning}")
    
    # Check for potential unknown slang (words that look like slang but aren't in database)
    words = text_lower.split()
    for word in words:
        # Clean word of punctuation
        clean_word = ''.join(c for c in word if c.isalnum())
        if clean_word and len(clean_word) > 2 and clean_word not in [term for term, _ in all_slang]:
            # Check if it's not a common English word (simple heuristic)
            if not any(common in clean_word for common in ["the", "and", "for", "are", "but", "not", "you", "all", "can", "had", "her", "was", "one", "our", "out", "day", "get", "has", "him", "his", "how", "man", "new", "now", "old", "see", "two", "way", "who", "boy", "did", "its", "let", "put", "say", "she", "too", "use"]):
                # This might be unknown slang
                unknown_slang.append(clean_word)
    
    context = ""
    if found_slang:
        context = "Slang detected in user message: " + "; ".join(found_slang)
    
    if unknown_slang:
        context += f" | Unknown terms detected: {', '.join(unknown_slang[:3])}. Ask user for definitions."
    
    return context

def add_slang(term, meaning, category="general", source="user"):
    """Add a new slang term to the database"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO slang_vocabulary (slang_term, meaning, category, source) VALUES (?, ?, ?, ?)",
                  (term.lower(), meaning, category, source))
        conn.commit()
        print(f"✓ Added slang: {term} = {meaning} (source: {source})")
        return True
    except sqlite3.IntegrityError:
        print(f"Slang term '{term}' already exists")
        return False
    finally:
        conn.close()

def learn_slang_from_user(term, meaning):
    """Learn new slang from user input"""
    return add_slang(term, meaning, category="user_defined", source="user")

if __name__ == "__main__":
    init_slang_db()
    print("Slang database initialized!")
  
