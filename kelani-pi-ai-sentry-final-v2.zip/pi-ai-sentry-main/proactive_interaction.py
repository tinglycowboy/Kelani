#!/usr/bin/env python3
import sqlite3
import datetime
import json
import random

DB_PATH = "ai_sentry.db"

def init_proactive_db():
    """Create proactive interaction tables"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS proactive_interactions (
            id TEXT PRIMARY KEY,
            person_id TEXT,
            timestamp TEXT,
            interaction_type TEXT,
            message TEXT,
            response TEXT
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS person_presence (
            person_id TEXT PRIMARY KEY,
            first_seen_today TEXT,
            last_seen_today TEXT,
            times_seen_today INTEGER DEFAULT 1,
            date TEXT
        )
    """)
    
    conn.commit()
    conn.close()

def update_person_presence(person_id):
    """Track how many times a person is seen today"""
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    now = str(datetime.datetime.now())
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("SELECT times_seen_today FROM person_presence WHERE person_id = ? AND date = ?", (person_id, today))
    result = c.fetchone()
    
    if result:
        c.execute("""
            UPDATE person_presence 
            SET last_seen_today = ?, times_seen_today = times_seen_today + 1
            WHERE person_id = ? AND date = ?
        """, (now, person_id, today))
    else:
        c.execute("""
            INSERT INTO person_presence (person_id, first_seen_today, last_seen_today, times_seen_today, date)
            VALUES (?, ?, ?, 1, ?)
        """, (person_id, now, now, today))
    
    conn.commit()
    conn.close()

def get_person_presence_count(person_id):
    """Get how many times person has been seen today"""
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("SELECT times_seen_today FROM person_presence WHERE person_id = ? AND date = ?", (person_id, today))
    result = c.fetchone()
    conn.close()
    
    return result[0] if result else 0

def get_last_interaction_time(person_id):
    """Get timestamp of last interaction with person"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        SELECT timestamp FROM proactive_interactions 
        WHERE person_id = ? 
        ORDER BY timestamp DESC 
        LIMIT 1
    """, (person_id,))
    
    result = c.fetchone()
    conn.close()
    
    if result:
        return datetime.datetime.strptime(result[0].split('.')[0], "%Y-%m-%d %H:%M:%S")
    return None

def get_days_since_last_seen(person_id):
    """Get number of days since person was last seen"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("SELECT last_seen FROM persons WHERE id = ?", (person_id,))
    result = c.fetchone()
    conn.close()
    
    if result:
        last_seen = datetime.datetime.strptime(result[0].split('.')[0], "%Y-%m-%d %H:%M:%S")
        days = (datetime.datetime.now() - last_seen).days
        return days
    return 999

def should_initiate_interaction(person_id, frame=None):
    """Determine if AI should proactively interact with person"""
    from person_profile import get_person_profile
    
    profile = get_person_profile(person_id)
    if not profile:
        return False
    
    # Don't interact with suspicious people
    if profile.get('familiarity_level') == 'suspicious':
        return False
    
    # Check how long since last interaction
    last_interaction = get_last_interaction_time(person_id)
    days_since_last_seen = get_days_since_last_seen(person_id)
    
    # If seen multiple times today, might ask if they're staying
    presence_count = get_person_presence_count(person_id)
    update_person_presence(person_id)
    
    # Decision logic
    if days_since_last_seen > 7:
        # Haven't seen in over a week - ask how they've been
        return "long_time_no_see"
    elif presence_count >= 3 and days_since_last_seen == 0:
        # Seen multiple times today - ask if they're staying
        return "staying_around"
    elif profile.get('familiarity_level') in ['stranger', 'acquaintance']:
        # Not very familiar - try to learn more
        return "learn_more"
    elif days_since_last_seen >= 1 and profile.get('familiarity_level') in ['friend', 'close_friend']:
        # Friend not seen recently - casual check-in
        return "casual_checkin"
    
    return False

def generate_proactive_message(interaction_type, person_id):
    """Generate appropriate proactive message based on interaction type"""
    from person_profile import get_person_profile
    from person_recognition import get_person_conversation_history
    
    profile = get_person_profile(person_id)
    name = profile.get('name', 'there') if profile else 'there'
    
    if interaction_type == "long_time_no_see":
        messages = [
            f"Hey {name}! It's been a while. How have you been?",
            f"Hi {name}, long time no see! What have you been up to?",
            f"Hello {name}! I haven't seen you in a bit. How are things?"
        ]
    elif interaction_type == "staying_around":
        messages = [
            f"Hey, I've seen you a few times today. Are you going to be around for a bit?",
            f"Hi again! You've been here a while. Planning to stay?",
            f"Hey, are you settling in for the day?"
        ]
    elif interaction_type == "learn_more":
        # Try to learn about hobbies, interests, work
        history = get_person_conversation_history(person_id, 5)
        
        # Check what we already know
        known_hobbies = profile.get('hobbies', [])
        known_interests = profile.get('interests', [])
        
        if not known_hobbies:
            messages = [
                f"Hey {name}, what do you like to do for fun?",
                f"Hi {name}, what are your hobbies?",
                f"Hello {name}, what do you enjoy doing in your free time?"
            ]
        elif not known_interests:
            messages = [
                f"Hey {name}, what are you interested in?",
                f"Hi {name}, what topics do you find interesting?",
                f"Hello {name}, what kinds of things do you like to learn about?"
            ]
        else:
            messages = [
                f"Hey {name}, how's your day going?",
                f"Hi {name}, what are you working on lately?",
                f"Hello {name}, anything interesting happening?"
            ]
    elif interaction_type == "casual_checkin":
        # Check on projects, general well-being
        messages = [
            f"Hey {name}, how's it going? What have you been working on?",
            f"Hi {name}, how are things? Anything new since I last saw you?",
            f"Hello {name}, good to see you again. How's everything?"
        ]
    else:
        messages = [f"Hey {name}!"]
    
    return random.choice(messages)

def log_proactive_interaction(person_id, interaction_type, message, response=None):
    """Log proactive interaction to database"""
    import uuid
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        INSERT INTO proactive_interactions (id, person_id, timestamp, interaction_type, message, response)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), person_id, str(datetime.datetime.now()), interaction_type, message, response))
    
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_proactive_db()
    print("Proactive interaction system initialized!")
