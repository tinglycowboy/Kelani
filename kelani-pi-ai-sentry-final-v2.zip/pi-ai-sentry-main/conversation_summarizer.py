#!/usr/bin/env python3
"""Conversation summarizer: creates brief summaries of conversations"""
import re
import sqlite3

DB_PATH = "ai_sentry.db"

def extract_key_sentences(text, max_sentences=3):
    """Extract most important sentences using simple scoring"""
    # Split into sentences
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 10]
    
    if not sentences:
        return text[:200]
    
    # Score sentences by length and keyword presence
    important_keywords = ["important", "key", "main", "critical", "essential", "remember", "note"]
    
    scored = []
    for sent in sentences:
        score = len(sent) / 100  # Length factor
        for keyword in important_keywords:
            if keyword in sent.lower():
                score += 0.5
        scored.append((sent, score))
    
    # Sort by score and take top N
    scored.sort(key=lambda x: x[1], reverse=True)
    top_sentences = [s[0] for s in scored[:max_sentences]]
    
    return ". ".join(top_sentences) + "."

def summarize_conversation(messages, max_length=200):
    """Summarize a conversation from message list"""
    if not messages:
        return ""
    
    # Combine messages
    combined = " ".join([m.get("message", "") for m in messages])
    
    # Extract key sentences
    summary = extract_key_sentences(combined, max_sentences=2)
    
    # Truncate if too long
    if len(summary) > max_length:
        summary = summary[:max_length].rsplit(" ", 1)[0] + "..."
    
    return summary

def summarize_person_conversation(person_id, limit=10):
    """Summarize recent conversation with a specific person"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        SELECT role, message
        FROM person_conversations
        WHERE person_id = ?
        ORDER BY timestamp DESC
        LIMIT ?
    """, (person_id, limit))
    
    messages = [{"role": r[0], "message": r[1]} for r in reversed(c.fetchall())]
    conn.close()
    
    if not messages:
        return ""
    
    return summarize_conversation(messages)

def get_topic_summary(messages):
    """Identify main topics in conversation"""
    combined = " ".join([m.get("message", "") for m in messages]).lower()
    
    # Simple topic detection
    topics = {
        "work": ["work", "job", "project", "meeting", "boss", "colleague", "deadline"],
        "school": ["school", "class", "homework", "exam", "teacher", "student", "study"],
        "personal": ["family", "friend", "relationship", "home", "life"],
        "technical": ["code", "programming", "computer", "software", "bug", "error"],
        "entertainment": ["movie", "music", "game", "show", "book", "video"],
        "health": ["health", "doctor", "sick", "exercise", "diet", "medicine"]
    }
    
    topic_scores = {}
    for topic, keywords in topics.items():
        score = sum(1 for kw in keywords if kw in combined)
        if score > 0:
            topic_scores[topic] = score
    
    if topic_scores:
        main_topic = max(topic_scores, key=topic_scores.get)
        return main_topic
    
    return "general"

if __name__ == "__main__":
    # Test
    test_messages = [
        {"role": "user", "message": "I need help with my project deadline"},
        {"role": "assistant", "message": "When is your deadline?"},
        {"role": "user", "message": "It's tomorrow at 5pm"},
        {"role": "assistant", "message": "That's urgent. What do you need help with?"}
    ]
    
    print("Summary:", summarize_conversation(test_messages))
    print("Topic:", get_topic_summary(test_messages))
