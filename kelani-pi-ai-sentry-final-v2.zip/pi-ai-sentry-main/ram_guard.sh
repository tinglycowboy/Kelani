#!/bin/bash
set -u
LIMIT="${AI_SENTRY_RAM_HARD_LIMIT:-92}"; INTERVAL="${AI_SENTRY_RAM_CHECK_INTERVAL:-5}"; LOG=/var/log/ai-sentry-ram-guard.log
while true; do
 total=$(awk '/MemTotal:/{print $2}' /proc/meminfo); avail=$(awk '/MemAvailable:/{print $2}' /proc/meminfo); pct=$(( (total-avail)*100/total ))
 if [ "$pct" -ge "${LIMIT%.*}" ]; then
  echo "$(date -Is) RAM ${pct}% >= ${LIMIT}%; stopping AI/Ollama and rebooting" >> "$LOG"
  systemctl stop ai-sentry.service 2>/dev/null || true; systemctl stop ollama.service 2>/dev/null || true
  pkill -TERM -f '/ai_sentry/.*python' 2>/dev/null || true; pkill -TERM -x ollama 2>/dev/null || true
  sync; sleep 2; systemctl reboot; exit 0
 fi
 sleep "$INTERVAL"
done
