#!/usr/bin/env python3
import sqlite3
import datetime
import threading
import time
import os
import sys

DB_PATH = "ai_sentry.db"
VOSK_MODEL_PATH = os.path.expanduser(os.environ.get("VOSK_MODEL_PATH", "~/ai_sentry/vosk-model-small-en-us-0.15"))
VOSK_SPK_MODEL_PATH = os.path.expanduser(os.environ.get("VOSK_SPK_MODEL_PATH", "~/ai_sentry/vosk-model-spk-0.4"))
_vosk_model = None
_vosk_spk_model = None
_vosk_lock = threading.Lock()

def init_audio_db():
    """Create audio_events table if it doesn't exist"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS audio_events (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            transcribed_text TEXT,
            confidence REAL,
            is_speech BOOLEAN,
            person_id TEXT,
            voice_features TEXT
        )
    """)
    conn.commit()
    conn.close()

def transcribe_audio_details(audio_file):
    """Offline Vosk transcription plus a speaker embedding when the 13 MB speaker model is installed."""
    try:
        import json, wave
        from vosk import Model, KaldiRecognizer, SpkModel
        global _vosk_model, _vosk_spk_model
        with _vosk_lock:
            if _vosk_model is None:
                _vosk_model = Model(VOSK_MODEL_PATH)
            if _vosk_spk_model is None and os.path.isdir(VOSK_SPK_MODEL_PATH):
                _vosk_spk_model = SpkModel(VOSK_SPK_MODEL_PATH)
            model, spk_model = _vosk_model, _vosk_spk_model
        wf = wave.open(audio_file, 'rb')
        rec = KaldiRecognizer(model, wf.getframerate())
        if spk_model is not None:
            rec.SetSpkModel(spk_model)
        text, confidence, speaker = '', 0.0, None
        while True:
            data = wf.readframes(4000)
            if not data:
                break
            if rec.AcceptWaveform(data):
                result = json.loads(rec.Result())
                if result.get('text'):
                    text = result['text']
                confidence = float(result.get('confidence', confidence) or confidence)
                if result.get('spk'):
                    speaker = result['spk']
        final = json.loads(rec.FinalResult())
        if final.get('text'):
            text = final['text']
        confidence = float(final.get('confidence', confidence) or confidence)
        if final.get('spk'):
            speaker = final['spk']
        wf.close()
        return text, confidence, speaker
    except Exception as e:
        print(f"Transcription error: {e}")
        return '', 0.0, None

def transcribe_audio(audio_file):
    text, confidence, _ = transcribe_audio_details(audio_file)
    return text, confidence

def log_audio_event(text, confidence, is_speech=True, person_id=None, voice_features=None):
    """Log audio transcription to SQLite"""
    import uuid
    import json
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        INSERT INTO audio_events (id, timestamp, transcribed_text, confidence, is_speech, person_id, voice_features)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), str(datetime.datetime.now()), text, confidence, is_speech,
          person_id, json.dumps(voice_features) if voice_features else None))
    
    conn.commit()
    conn.close()

def mic_loop(stop_event, queue_callback):
    """Continuous microphone loop with intent filtering and voice recognition"""
    try:
        import pyaudio
        import wave
        import numpy as np
        from intent_filter import should_ai_respond
        from person_recognition import extract_voice_features, ensure_person_profile_from_voice, identify_voice
        from identity_manager import get_recent_person_candidates, pending_identity_question, answer_identity_question, note_unresolved_names, link_name_from_conversation, link_third_party_name, contradict_name, extract_name_candidates
        
        CHUNK = 1024
        FORMAT = pyaudio.paInt16
        CHANNELS = 1
        RATE = 16000
        RECORD_SECONDS = 5
        SILENCE_THRESHOLD = 500
        
        p = pyaudio.PyAudio()
        stream = p.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, frames_per_buffer=CHUNK)
        
        print("🎤 Microphone initialized with intent filtering and voice recognition...")
        
        while not stop_event.is_set():
            frames = []
            is_speech = False
            
            for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
                data = stream.read(CHUNK, exception_on_overflow=False)
                frames.append(data)
                
                audio_data = np.frombuffer(data, dtype=np.int16)
                if np.abs(audio_data).mean() > SILENCE_THRESHOLD:
                    is_speech = True
            
            temp_file = "/tmp/mic_recording.wav"
            wf = wave.open(temp_file, 'wb')
            wf.setnchannels(CHANNELS)
            wf.setsampwidth(p.get_sample_size(FORMAT))
            wf.setframerate(RATE)
            wf.writeframes(b''.join(frames))
            wf.close()
            
            if is_speech:
                text, confidence, speaker_vector = transcribe_audio_details(temp_file)
                
                if text and len(text.strip()) > 0:
                    # Extract voice features
                    voice_features = extract_voice_features(temp_file)
                    
                    person_id = None
                    voice_confidence = 0.0
                    if speaker_vector:
                        person_id, voice_confidence = identify_voice(speaker_vector)
                        if person_id is None:
                            person_id, voice_confidence, _ = ensure_person_profile_from_voice(speaker_vector, 0.50)
                    elif voice_features:
                        person_id, voice_confidence = identify_voice(voice_features)
                        if person_id is None:
                            person_id, voice_confidence, _ = ensure_person_profile_from_voice(voice_features, 0.45)
                    # If a camera saw someone moments ago, associate the speech with the
                    # nearest recent face only as a hypothesis; the confidence remains separate.
                    if person_id is None:
                        recent = get_recent_person_candidates(8, 1)
                        if recent:
                            person_id = recent[0]['person_id']
                    log_audio_event(text, max(confidence, voice_confidence), is_speech=True, person_id=person_id,
                                    voice_features={"basic": voice_features, "speaker_vector": speaker_vector, "speaker_confidence": voice_confidence})

                    # Names heard in unrelated conversation live in a temporary cache.
                    note_unresolved_names(text, f"heard near person {person_id or 'unknown'}")
                    # If the system had just asked this nearby person for their name, an
                    # explicit answer becomes strong identity evidence.
                    if person_id:
                        qid = pending_identity_question(person_id)
                        if qid is not None:
                            answer_identity_question(qid, text)
                        else:
                            link_name_from_conversation(person_id, text, 'heard_conversation')

                    # A nearby person may identify somebody else: e.g. "that's Bob".
                    # Keep this as probabilistic evidence rather than immediately renaming the profile.
                    recent_faces = get_recent_person_candidates(8, 3)
                    names_in_text = list(extract_name_candidates(text))
                    lowered = text.lower()
                    for candidate in recent_faces:
                        target = candidate['person_id']
                        if target == person_id and len(recent_faces) == 1:
                            continue
                        for name in names_in_text:
                            if "that's" in lowered or "that is" in lowered or "his name is" in lowered or "her name is" in lowered:
                                link_third_party_name(target, name, 0.55, text)
                            if f"not {name.lower()}" in lowered or f"isn't {name.lower()}" in lowered:
                                contradict_name(target, name, 0.60, text)
                    
                    # Use intent filter to decide if AI should respond
                    should_respond, reason, _ = should_ai_respond()
                    
                    if should_respond and queue_callback:
                        print(f"🎯 Intent detected: {reason}")
                        queue_callback(text, person_id)
                    else:
                        print(f"🔇 Ignoring audio: {reason}")
            
            if os.path.exists(temp_file):
                os.remove(temp_file)
        
        stream.stop_stream()
        stream.close()
        p.terminate()
        print("🎤 Microphone stopped")
    
    except Exception as e:
        print(f"⚠️ Microphone error: {e}")
        print("⚠️ Continuing in visual-only mode")

def get_recent_audio(limit=5):
    """Get recent audio transcriptions for AI context"""
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""
            SELECT timestamp, transcribed_text, confidence, person_id
            FROM audio_events
            WHERE is_speech = 1
            ORDER BY timestamp DESC
            LIMIT ?
        """, (limit,))
        results = c.fetchall()
        conn.close()
        return [{"timestamp": r[0], "text": r[1], "confidence": r[2], "person_id": r[3]} for r in results]
    except Exception as e:
        print(f"Audio query error: {e}")
        return []

def is_mic_available():
    """Check if microphone is working"""
    try:
        import pyaudio
        p = pyaudio.PyAudio()
        stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True)
        stream.close()
        p.terminate()
        return True
    except:
        return False
