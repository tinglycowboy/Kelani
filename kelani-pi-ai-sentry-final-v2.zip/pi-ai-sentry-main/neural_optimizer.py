#!/usr/bin/env python3
"""Neural Optimizer: Uses neural network during idle time to reorganize SQLite data for efficient retrieval"""
import sqlite3
import numpy as np
import time
import subprocess
import datetime
import os

DB_PATH = "ai_sentry.db"
WIKI_DB_PATH = "wiki_search.db"
KNOWLEDGE_DB_PATH = "knowledge_base.db"

# Neural network parameters
INPUT_SIZE = 50    # Features about data patterns
HIDDEN_SIZE = 32
OUTPUT_SIZE = 10   # Optimization actions

class SimpleNeuralNet:
    """Lightweight neural network for data optimization decisions"""
    
    def __init__(self):
        # Initialize weights
        np.random.seed(42)
        self.W1 = np.random.randn(INPUT_SIZE, HIDDEN_SIZE) * 0.1
        self.b1 = np.zeros(HIDDEN_SIZE)
        self.W2 = np.random.randn(HIDDEN_SIZE, OUTPUT_SIZE) * 0.1
        self.b2 = np.zeros(OUTPUT_SIZE)
    
    def relu(self, x):
        return np.maximum(0, x)
    
    def softmax(self, x):
        exp_x = np.exp(x - np.max(x))
        return exp_x / exp_x.sum()
    
    def forward(self, x):
        """Forward pass through network"""
        self.z1 = np.dot(x, self.W1) + self.b1
        self.a1 = self.relu(self.z1)
        self.z2 = np.dot(self.a1, self.W2) + self.b2
        self.a2 = self.softmax(self.z2)
        return self.a2
    
    def extract_features(self, db_stats):
        """Extract features from database statistics"""
        features = np.zeros(INPUT_SIZE)
        
        # Database size features (0-9)
        features[0] = min(db_stats.get('logs_count', 0) / 10000, 1.0)
        features[1] = min(db_stats.get('persons_count', 0) / 100, 1.0)
        features[2] = min(db_stats.get('conversations_count', 0) / 5000, 1.0)
        features[3] = min(db_stats.get('visual_events_count', 0) / 10000, 1.0)
        features[4] = min(db_stats.get('audio_events_count', 0) / 10000, 1.0)
        
        # Time-based features (10-19)
        features[5] = db_stats.get('avg_queries_per_hour', 0) / 100
        features[6] = db_stats.get('recent_activity_score', 0)
        features[7] = db_stats.get('time_since_last_query', 0) / 3600
        
        # Fragmentation indicators (20-29)
        features[8] = db_stats.get('db_file_size_mb', 0) / 1000
        features[9] = db_stats.get('estimated_fragmentation', 0)
        
        # Access patterns (30-49)
        for i, key in enumerate(['wiki_searches', 'memory_searches', 'person_lookups', 
                                  'slang_lookups', 'emotion_queries', 'recent_visual_access',
                                  'recent_audio_access', 'knowledge_base_access',
                                  'psychology_lookups', 'history_access']):
            features[10 + i] = min(db_stats.get(key, 0) / 100, 1.0)
        
        return features

def get_system_idle_status():
    """Check if system is idle (low CPU usage)"""
    try:
        result = subprocess.run(['vmstat', '1', '2'], capture_output=True, text=True)
        lines = result.stdout.strip().split('\n')
        if len(lines) >= 3:
            # Get CPU idle percentage from last line
            parts = lines[-1].split()
            idle = int(parts[-1])
            return idle > 85  # System is idle if >85% CPU idle
    except:
        pass
    return False

def get_db_statistics():
    """Gather statistics about databases"""
    stats = {}
    
    try:
        # Main database stats
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        c.execute("SELECT COUNT(*) FROM logs")
        stats['logs_count'] = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM persons")
        stats['persons_count'] = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM person_conversations")
        stats['conversations_count'] = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM visual_events")
        stats['visual_events_count'] = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM audio_events")
        stats['audio_events_count'] = c.fetchone()[0]
        
        # Database file size
        if os.path.exists(DB_PATH):
            stats['db_file_size_mb'] = os.path.getsize(DB_PATH) / (1024 * 1024)
        
        # Recent activity (last hour)
        one_hour_ago = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
        c.execute("SELECT COUNT(*) FROM logs WHERE timestamp > ?", (one_hour_ago,))
        stats['recent_activity_score'] = c.fetchone()[0] / 100
        
        # Time since last query
        c.execute("SELECT timestamp FROM logs ORDER BY timestamp DESC LIMIT 1")
        result = c.fetchone()
        if result:
            last_time = datetime.datetime.strptime(result[0].split('.')[0], "%Y-%m-%d %H:%M:%S")
            stats['time_since_last_query'] = (datetime.datetime.now() - last_time).total_seconds()
        else:
            stats['time_since_last_query'] = 999999
        
        conn.close()
    except Exception as e:
        print(f"Error gathering DB stats: {e}")
    
    return stats

def optimize_databases(action_index):
    """Execute optimization action based on neural network decision"""
    actions = [
        "vacuum_main_db",
        "vacuum_wiki_db",
        "vacuum_knowledge_db",
        "reindex_logs",
        "reindex_person_conversations",
        "reindex_visual_events",
        "reindex_audio_events",
        "archive_old_data",
        "optimize_fts_index",
        "no_action"
    ]
    
    if action_index >= len(actions):
        return
    
    action = actions[action_index]
    print(f"🧠 Neural Optimizer executing: {action}")
    
    try:
        if action == "vacuum_main_db":
            conn = sqlite3.connect(DB_PATH)
            conn.execute("VACUUM")
            conn.close()
            print("   ✅ Main database vacuumed")
            
        elif action == "vacuum_wiki_db":
            conn = sqlite3.connect(WIKI_DB_PATH)
            conn.execute("VACUUM")
            conn.close()
            print("   ✅ Wiki database vacuumed")
            
        elif action == "vacuum_knowledge_db":
            conn = sqlite3.connect(KNOWLEDGE_DB_PATH)
            conn.execute("VACUUM")
            conn.close()
            print("   ✅ Knowledge database vacuumed")
            
        elif action.startswith("reindex_"):
            table = action.replace("reindex_", "")
            conn = sqlite3.connect(DB_PATH)
            conn.execute(f"CREATE INDEX IF NOT EXISTS idx_{table}_timestamp ON {table}(timestamp)")
            conn.close()
            print(f"   ✅ Index created on {table}")
            
        elif action == "archive_old_data":
            # Move data older than 180 days to archive table
            cutoff = (datetime.datetime.now() - datetime.timedelta(days=180)).strftime("%Y-%m-%d %H:%M:%S")
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("CREATE TABLE IF NOT EXISTS logs_archive AS SELECT * FROM logs WHERE timestamp < ?", (cutoff,))
            c.execute("DELETE FROM logs WHERE timestamp < ?", (cutoff,))
            conn.commit()
            conn.close()
            print("   ✅ Old data archived")
            
        elif action == "optimize_fts_index":
            conn = sqlite3.connect(WIKI_DB_PATH)
            conn.execute("INSERT INTO wiki(wiki) VALUES('optimize')")
            conn.close()
            print("   ✅ FTS index optimized")
            
        elif action == "no_action":
            print("   ℹ️ No optimization needed")
    
    except Exception as e:
        print(f"   ⚠️ Optimization error: {e}")

def neural_optimizer_loop(stop_event):
    """Main neural optimizer loop - runs during idle time"""
    print("🧠 Neural Optimizer started - will optimize during idle periods")
    
    net = SimpleNeuralNet()
    optimization_count = 0
    
    while not stop_event.is_set():
        try:
            # Check if system is idle
            if not get_system_idle_status():
                time.sleep(30)  # Check again in 30 seconds
                continue
            
            print("💤 System idle detected - running neural optimization...")
            
            # Gather database statistics
            stats = get_db_statistics()
            
            # Extract features
            features = net.extract_features(stats)
            
            # Get neural network prediction
            predictions = net.forward(features)
            
            # Choose action with highest probability
            action_index = np.argmax(predictions)
            
            # Execute optimization
            optimize_databases(action_index)
            
            optimization_count += 1
            print(f"   📊 Optimization cycle #{optimization_count} complete")
            
            # Wait before next optimization (don't over-optimize)
            time.sleep(300)  # 5 minutes between optimizations
            
        except Exception as e:
            print(f"Neural optimizer error: {e}")
            time.sleep(60)

if __name__ == "__main__":
    import threading
    stop_event = threading.Event()
    neural_optimizer_loop(stop_event)
