#!/usr/bin/env python3
"""Scene descriptor: generates natural language descriptions of camera view"""
import re

def describe_scene(objects, object_count, person_id=None, frame_description=None):
    """Generate natural language description of scene"""
    if object_count == 0:
        return "No objects detected in the scene."
    
    # Parse objects
    people_count = sum(1 for obj in objects if obj.startswith("person_"))
    faces_count = sum(1 for obj in objects if obj.startswith("face_"))
    other_objects = [obj for obj in objects if not obj.startswith("person_") and not obj.startswith("face_")]
    
    description_parts = []
    
    # Describe people
    if people_count > 0:
        if people_count == 1:
            person_desc = "One person"
        else:
            person_desc = f"{people_count} people"
        
        if person_id:
            description_parts.append(f"{person_desc} detected (recognized as known person)")
        else:
            description_parts.append(f"{person_desc} detected")
    
    # Describe faces
    if faces_count > 0:
        if faces_count == 1:
            description_parts.append("one face visible")
        else:
            description_parts.append(f"{faces_count} faces visible")
    
    # Describe other objects
    if other_objects:
        obj_list = ", ".join(other_objects[:5])  # Limit to 5
        description_parts.append(f"other objects: {obj_list}")
    
    # Combine
    if len(description_parts) == 1:
        description = description_parts[0]
    else:
        description = "; ".join(description_parts[:-1]) + ", and " + description_parts[-1]
    
    # Add context about scene composition
    if people_count > 0 and faces_count > 0:
        if faces_count >= people_count:
            description += ". People appear to be facing the camera."
        else:
            description += ". Some people may be facing away from the camera."
    
    return description

def describe_activity(objects, recent_visuals):
    """Infer activity from object patterns over time"""
    if not recent_visuals or len(recent_visuals) < 3:
        return "Activity unclear (insufficient data)"
    
    # Count people across recent frames
    people_counts = []
    for visual in recent_visuals:
        objects_str = visual.get("objects", "")
        people_count = len([obj for obj in objects_str.split(", ") if obj.startswith("person_")])
        people_counts.append(people_count)
    
    avg_people = sum(people_counts) / len(people_counts)
    
    # Determine activity
    if avg_people == 0:
        return "Room appears empty"
    elif avg_people == 1:
        if all(c == 1 for c in people_counts):
            return "One person present and stationary"
        else:
            return "One person moving around"
    elif avg_people > 1:
        if max(people_counts) - min(people_counts) <= 1:
            return "Group of people present, relatively stable"
        else:
            return "People coming and going"
    
    return "Activity detected"

def generate_context_summary(recent_visuals, limit=3):
    """Generate concise summary of recent visual context"""
    if not recent_visuals:
        return ""
    
    summaries = []
    for visual in recent_visuals[:limit]:
        desc = describe_scene(
            visual.get("objects", "").split(", ") if visual.get("objects") else [],
            visual.get("object_count", 0),
            visual.get("person_id"),
            visual.get("description")
        )
        timestamp = visual.get("timestamp", "")
        if timestamp:
            # Just show time, not full datetime
            time_part = timestamp.split(" ")[1][:8] if " " in timestamp else timestamp
            summaries.append(f"[{time_part}] {desc}")
        else:
            summaries.append(desc)
    
    return "\n".join(summaries)

if __name__ == "__main__":
    # Test
    test_objects = ["person_1", "person_2", "face_1", "face_2"]
    print(describe_scene(test_objects, 4, person_id="abc123"))
    
    test_objects2 = ["person_1"]
    print(describe_scene(test_objects2, 1, person_id=None))
    
    test_objects3 = []
    print(describe_scene(test_objects3, 0))
  
