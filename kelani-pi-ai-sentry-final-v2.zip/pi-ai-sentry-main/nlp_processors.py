#!/usr/bin/env python3
"""Lightweight NLP processors: intent, entity, urgency, keyword, sentiment"""
import re
import sqlite3
from collections import Counter

DB_PATH = "ai_sentry.db"

# Intent categories
INTENT_PATTERNS = {
    "greeting": [r"^hello", r"^hi\b", r"^hey\b", r"^good (morning|afternoon|evening)"],
    "farewell": [r"^bye", r"^goodbye", r"see you", r"talk later"],
    "question": [r"\?$", r"^(what|who|where|when|why|how|is|are|do|does|can|could|will|would)\b"],
    "command": [r"^(please )?(tell|show|find|search|calculate|remind|set|create|delete)\b"],
    "complaint": [r"(frustrat|annoy|angry|hate|terrible|awful|worst|suck)"],
    "compliment": [r"(thank|thanks|great|awesome|amazing|love|excellent|perfect|good job)"],
    "request": [r"(can you|could you|would you|please|I need|I want)"],
    "casual_chat": [r"(lol|haha|yeah|sure|okay|cool|nice|interesting)"]
}

# Entity patterns
ENTITY_PATTERNS = {
    "person": [r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b"],  # Capitalized names
    "number": [r"\b(\d+(?:\.\d+)?)\b"],
    "time": [r"\b(\d{1,2}:\d{2}(?:\s*[ap]m)?)\b", r"\b(\d{1,2}\s*(?:am|pm))\b"],
    "date": [r"\b(\d{1,2}/\d{1,2}/\d{2,4})\b", r"\b((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\s+\d{1,2})\b"],
    "email": [r"\b([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\b"],
    "phone": [r"\b(\d{3}[-.\s]?\d{3}[-.\s]?\d{4})\b"],
    "money": [r"\$\s*(\d+(?:\.\d{2})?)", r"(\d+(?:\.\d{2})?)\s*(?:dollars|bucks|USD)"],
    "location": [r"\b(in|at|near|from)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b"]
}

# Urgency indicators
URGENCY_KEYWORDS = {
    "critical": ["emergency", "asap", "urgent", "immediately", "right now", "critical", "life or death"],
    "high": ["soon", "quickly", "fast", "hurry", "deadline", "important", "priority"],
    "medium": ["when you can", "today", "this week", "sometime"],
    "low": ["whenever", "no rush", "later", "eventually", "someday"]
}

# Stop words for keyword extraction
STOP_WORDS = set(["the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "of", "with", 
                  "by", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "do",
                  "does", "did", "will", "would", "could", "should", "may", "might", "can", "this",
                  "that", "these", "those", "i", "you", "he", "she", "it", "we", "they", "me", "him",
                  "her", "us", "them", "my", "your", "his", "its", "our", "their", "what", "which",
                  "who", "when", "where", "why", "how", "all", "each", "every", "both", "few", "more",
                  "most", "other", "some", "such", "no", "not", "only", "own", "same", "so", "than",
                  "too", "very", "just", "about", "up", "out", "if", "then", "else", "as", "into"])

# Simple sentiment lexicon
SENTIMENT_LEXICON = {
    "positive": ["good", "great", "awesome", "amazing", "love", "happy", "excellent", "wonderful", 
                 "fantastic", "brilliant", "perfect", "nice", "cool", "best", "beautiful", "fun",
                 "enjoy", "like", "appreciate", "thank", "grateful", "excited", "pleased", "glad"],
    "negative": ["bad", "terrible", "awful", "hate", "angry", "sad", "horrible", "worst", "ugly",
                 "stupid", "boring", "annoying", "frustrating", "disappointing", "disgusting", 
                 "furious", "miserable", "depressed", "upset", "disgusted", "annoyed", "irritated"]
}

def classify_intent(text):
    """Classify the intent of the text"""
    text_lower = text.lower().strip()
    scores = {}
    
    for intent, patterns in INTENT_PATTERNS.items():
        score = 0
        for pattern in patterns:
            if re.search(pattern, text_lower, re.IGNORECASE):
                score += 1
        scores[intent] = score
    
    # Get highest scoring intent
    if scores:
        best_intent = max(scores, key=scores.get)
        confidence = scores[best_intent] / max(sum(scores.values()), 1)
        return {"intent": best_intent, "confidence": min(confidence, 1.0), "all_scores": scores}
    
    return {"intent": "unknown", "confidence": 0.0, "all_scores": scores}

def extract_entities(text):
    """Extract entities from text"""
    entities = {}
    
    for entity_type, patterns in ENTITY_PATTERNS.items():
        matches = []
        for pattern in patterns:
            found = re.findall(pattern, text)
            matches.extend(found)
        
        # Clean up matches (remove empty strings, dedupe)
        matches = [m for m in matches if m and len(m.strip()) > 0]
        matches = list(set(matches))
        
        if matches:
            entities[entity_type] = matches
    
    return entities

def detect_urgency(text):
    """Detect urgency level of the text"""
    text_lower = text.lower()
    
    for level, keywords in URGENCY_KEYWORDS.items():
        for keyword in keywords:
            if keyword in text_lower:
                return {"urgency": level, "keyword": keyword}
    
    # Check for exclamation marks as urgency indicator
    if text.count('!') >= 2:
        return {"urgency": "high", "keyword": "multiple_exclamations"}
    
    return {"urgency": "low", "keyword": None}

def extract_keywords(text, top_n=5):
    """Extract most important keywords using simple TF approach"""
    # Tokenize and clean
    words = re.findall(r'\b\w+\b', text.lower())
    
    # Remove stop words and short words
    filtered = [w for w in words if w not in STOP_WORDS and len(w) > 2]
    
    if not filtered:
        return []
    
    # Count frequencies
    word_counts = Counter(filtered)
    
    # Return top N
    return [{"word": word, "count": count} for word, count in word_counts.most_common(top_n)]

def analyze_sentiment(text):
    """Analyze sentiment of text"""
    text_lower = text.lower()
    words = re.findall(r'\b\w+\b', text_lower)
    
    pos_count = sum(1 for word in words if word in SENTIMENT_LEXICON["positive"])
    neg_count = sum(1 for word in words if word in SENTIMENT_LEXICON["negative"])
    
    total = pos_count + neg_count
    if total == 0:
        return {"sentiment": "neutral", "score": 0.0, "positive": 0, "negative": 0}
    
    score = (pos_count - neg_count) / total
    
    if score > 0.3:
        sentiment = "positive"
    elif score < -0.3:
        sentiment = "negative"
    else:
        sentiment = "neutral"
    
    return {
        "sentiment": sentiment,
        "score": round(score, 2),
        "positive": pos_count,
        "negative": neg_count
    }

def process_all(text):
    """Run all NLP processors on text"""
    return {
        "intent": classify_intent(text),
        "entities": extract_entities(text),
        "urgency": detect_urgency(text),
        "keywords": extract_keywords(text),
        "sentiment": analyze_sentiment(text)
    }

if __name__ == "__main__":
    # Test
    test_text = "Hey AI, can you urgently tell me what John said about the project deadline tomorrow?"
    result = process_all(test_text)
    
    print(f"Text: {test_text}")
    print(f"Intent: {result['intent']}")
    print(f"Entities: {result['entities']}")
    print(f"Urgency: {result['urgency']}")
    print(f"Keywords: {result['keywords']}")
    print(f"Sentiment: {result['sentiment']}")
