#!/usr/bin/env python3
import sqlite3
import datetime
import json

DB_PATH = "ai_sentry.db"

def init_profile_db():
    """Create person profile tables"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS person_profiles (
            person_id TEXT PRIMARY KEY,
            hobbies TEXT,
            interests TEXT,
            personality_traits TEXT,
            trust_score REAL DEFAULT 0.5,
            familiarity_level TEXT DEFAULT 'stranger',
            moral_alignment TEXT DEFAULT 'neutral',
            notes TEXT,
            name TEXT,
            psychological_traits TEXT,
            FOREIGN KEY (person_id) REFERENCES persons(id)
        )
    """)
    
    conn.commit()
    conn.close()

def get_trust_score(person_id):
    """Get trust score for a person"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("SELECT trust_score FROM person_profiles WHERE person_id = ?", (person_id,))
    result = c.fetchone()
    conn.close()
    
    return result[0] if result else 0.5

def update_trust_score(person_id, delta):
    """Update trust score (positive or negative delta)"""
    current = get_trust_score(person_id)
    new_score = max(0.0, min(1.0, current + delta))
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        UPDATE person_profiles 
        SET trust_score = ?, familiarity_level = ?
        WHERE person_id = ?
    """, (new_score, calculate_familiarity_level(new_score), person_id))
    
    conn.commit()
    conn.close()

def calculate_familiarity_level(trust_score):
    """Calculate familiarity level based on trust score"""
    if trust_score >= 0.9:
        return "close_friend"
    elif trust_score >= 0.7:
        return "friend"
    elif trust_score >= 0.5:
        return "acquaintance"
    elif trust_score >= 0.3:
        return "stranger"
    else:
        return "suspicious"

def update_person_profile(person_id, field, value):
    """Update a specific field in person's profile"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Check if profile exists
    c.execute("SELECT person_id FROM person_profiles WHERE person_id = ?", (person_id,))
    if not c.fetchone():
        # Create profile
        c.execute("""
            INSERT INTO person_profiles (person_id, hobbies, interests, personality_traits, trust_score, familiarity_level, moral_alignment, notes, name, psychological_traits)
            VALUES (?, '[]', '[]', '[]', 0.5, 'stranger', 'neutral', '[]', NULL, '[]')
        """, (person_id,))
    
    c.execute(f"UPDATE person_profiles SET {field} = ? WHERE person_id = ?", (json.dumps(value), person_id))
    
    conn.commit()
    conn.close()

def get_person_profile(person_id):
    """Get complete person profile"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        SELECT p.name, p.total_interactions, p.first_seen, p.last_seen,
               pr.hobbies, pr.interests, pr.personality_traits, pr.trust_score,
               pr.familiarity_level, pr.moral_alignment, pr.notes, pr.name, pr.psychological_traits
        FROM persons p
        LEFT JOIN person_profiles pr ON p.id = pr.person_id
        WHERE p.id = ?
    """, (person_id,))
    
    result = c.fetchone()
    conn.close()
    
    if result:
        return {
            "name": result[11] or result[0],
            "total_interactions": result[1],
            "first_seen": result[2],
            "last_seen": result[3],
            "hobbies": json.loads(result[4]) if result[4] else [],
            "interests": json.loads(result[5]) if result[5] else [],
            "personality_traits": json.loads(result[6]) if result[6] else [],
            "trust_score": result[7] if result[7] else 0.5,
            "familiarity_level": result[8] if result[8] else "stranger",
            "moral_alignment": result[9] if result[9] else "neutral",
            "notes": json.loads(result[10]) if result[10] else [],
            "psychological_traits": json.loads(result[12]) if result[12] else []
        }
    
    return None

def get_introduction_questions(person_id):
    """Get questions to ask when meeting someone new"""
    profile = get_person_profile(person_id)
    
    if not profile or profile['familiarity_level'] == 'stranger':
        return [
            "What's your name?",
            "What are your hobbies?",
            "What do you do for work or school?",
            "What are you interested in?",
            "What's your favorite thing to do in your free time?"
        ]
    
    return []

def analyze_moral_alignment(person_id, conversation_text):
    """Analyze conversation for moral/ethical indicators"""
    text_lower = conversation_text.lower()
    
    positive_indicators = ["help", "kind", "share", "care", "respect", "honest", "truth"]
    negative_indicators = ["hate", "hurt", "lie", "steal", "cheat", "harm", "destroy"]
    
    pos_count = sum(1 for word in positive_indicators if word in text_lower)
    neg_count = sum(1 for word in negative_indicators if word in text_lower)
    
    if pos_count > neg_count * 2:
        return "good"
    elif neg_count > pos_count * 2:
        return "concerning"
    else:
        return "neutral"

def update_moral_alignment(person_id, new_alignment):
    """Update person's moral alignment"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        UPDATE person_profiles 
        SET moral_alignment = ?
        WHERE person_id = ?
    """, (new_alignment, person_id))
    
    conn.commit()
    conn.close()

def classify_psychological_traits(person_id, conversation_history):
    """Analyze conversation patterns to classify psychological traits"""
    from knowledge_base import search_psychology
    
    if not conversation_history or len(conversation_history) < 3:
        return None
    
    # Combine all user messages
    all_text = " ".join([msg['message'] for msg in conversation_history if msg['role'] == 'user']).lower()
    
    classifications = []
    
    # Check for personality indicators
    if any(word in all_text for word in ['i think', 'maybe', 'perhaps', 'let me consider', 'hmm', 'i suppose']):
        classifications.append("introvert")
    elif any(word in all_text for word in ['!', 'omg', 'awesome', 'let\'s', 'we should', 'yay']):
        classifications.append("extrovert")
    
    # Check for analytical vs creative
    if any(word in all_text for word in ['data', 'statistics', 'evidence', 'facts', 'analysis', 'logical']):
        classifications.append("analytical")
    elif any(word in all_text for word in ['imagine', 'what if', 'maybe we could', 'creative', 'idea']):
        classifications.append("creative")
    
    # Check for communication style
    if any(word in all_text for word in ['please', 'could you', 'can you', 'i need']):
        classifications.append("assertive")
    elif any(word in all_text for word in ["sorry", "if it's okay", "maybe", "i guess"]):
        classifications.append("passive")

    # Store classifications without pretending these are clinical diagnoses.
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("UPDATE person_profiles SET psychological_traits = ? WHERE person_id = ?", (json.dumps(classifications), person_id))
        conn.commit(); conn.close()
    except Exception as e:
        print(f"Psychological trait storage error: {e}")
    return classifications

def get_psychological_context(person_id):
    profile = get_person_profile(person_id)
    if not profile or not profile.get("psychological_traits"):
        return ""
    traits = ", ".join(profile["psychological_traits"])
    return f"Observed conversation traits (non-clinical): {traits}."
