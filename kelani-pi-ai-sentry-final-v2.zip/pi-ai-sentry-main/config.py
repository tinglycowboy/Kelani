import os
APP_DIR=os.path.expanduser(os.environ.get('AI_SENTRY_HOME','~/ai_sentry'))
DB_PATH=os.path.join(APP_DIR,'ai_sentry.db'); LIBRARIES_DIR=os.path.join(APP_DIR,'libraries')
BOOKS_DIR=os.path.join(LIBRARIES_DIR,'books'); MUSIC_DIR=os.path.join(LIBRARIES_DIR,'music'); WIKI_DIR=os.path.join(LIBRARIES_DIR,'wikipedia'); BIBLE_DIR=os.path.join(LIBRARIES_DIR,'bible'); OTHER_DIR=os.path.join(LIBRARIES_DIR,'other'); TEMP_DIR=os.path.join(APP_DIR,'temp')
RAM_HARD_LIMIT_PERCENT=float(os.environ.get('AI_SENTRY_RAM_HARD_LIMIT','92'))
RAM_MODEL_LOAD_LIMIT_PERCENT=float(os.environ.get('AI_SENTRY_RAM_MODEL_LIMIT','78'))
RAM_BACKGROUND_LIMIT_PERCENT=float(os.environ.get('AI_SENTRY_RAM_BACKGROUND_LIMIT','72'))
RAM_CHECK_INTERVAL=int(os.environ.get('AI_SENTRY_RAM_CHECK_INTERVAL','5'))
for p in (APP_DIR,LIBRARIES_DIR,BOOKS_DIR,MUSIC_DIR,WIKI_DIR,BIBLE_DIR,OTHER_DIR,TEMP_DIR): os.makedirs(p,exist_ok=True)

# Adaptive reasoning controls
REASONING_MAX_DEPTH=int(os.environ.get('AI_SENTRY_REASONING_MAX_DEPTH','4'))
REASONING_MAX_RESEARCH_ROUNDS=int(os.environ.get('AI_SENTRY_REASONING_MAX_RESEARCH_ROUNDS','3'))
REASONING_MAX_PARTS=int(os.environ.get('AI_SENTRY_REASONING_MAX_PARTS','4'))
