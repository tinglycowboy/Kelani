#!/usr/bin/env python3
import sqlite3
import datetime
import re

DB_PATH = "ai_sentry.db"

EMOTION_KEYWORDS = {
    "happy": ["happy", "great", "awesome", "amazing", "love", "excited", "wonderful", "fantastic", "glad", "joy", "yay", "woohoo", "cool", "nice", "good", "best", "perfect", "excellent", "brilliant", "superb"],
    "sad": ["sad", "unhappy", "depressed", "down", "upset", "disappointed", "unfortunate", "sorry", "miss", "lost", "alone", "lonely", "hurt", "pain", "cry", "crying", "tears"],
    "angry": ["angry", "mad", "furious", "annoyed", "irritated", "frustrated", "hate", "disgusted", "pissed", "rage", "fuming", "livid", "enraged", "outraged"],
    "excited": ["excited", "thrilled", "pumped", "stoked", "can't wait", "omg", "wow", "incredible", "unbelievable", "mind-blowing", "epic", "legendary"],
    "confused": ["confused", "lost", "don't understand", "what", "huh", "confusing", "unclear", "strange", "weird", "baffled", "puzzled"],
    "frustrated": ["frustrated", "annoyed", "irritated", "bothered", "sick of", "tired of", "fed up", "done with", "can't stand", "ugh", "wtf", "omg why"],
    "neutral": ["okay", "sure", "fine", "alright", "whatever", "meh", "idk", "i don't know"]
}

EMOTION_RESPONSES = {
    "happy": [
        "That's wonderful! ",
        "I'm so glad to hear that! ",
        "That makes me happy too! ",
        "Awesome! "
    ],
    "sad": [
        "I'm sorry to hear that. ",
        "That's really tough. ",
        "I understand how you feel. ",
        "That must be difficult. "
    ],
    "angry": [
        "I can see why you're upset. ",
        "That's really frustrating. ",
        "I understand your anger. ",
        "That's completely understandable. "
    ],
    "excited": [
        "That's amazing! ",
        "I'm excited too! ",
        "Wow, that's incredible! ",
        "That's so cool! "
    ],
    "confused": [
        "Let me help clarify. ",
        "I understand your confusion. ",
        "Let me explain. ",
        "That can be confusing. "
    ],
    "frustrated": [
        "I understand your frustration. ",
        "That's really annoying. ",
        "I can see why that's bothering you. ",
        "That's definitely frustrating. "
    ],
    "neutral": [
        "",
        "",
        "",
        ""
    ]
}

def init_emotion_db():
    """Create emotion_state table if it doesn't exist"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS emotion_state (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            current_emotion TEXT,
            intensity REAL,
            timestamp TEXT
        )
    """)
    
    # Initialize with neutral emotion if empty
    c.execute("SELECT COUNT(*) FROM emotion_state")
    if c.fetchone()[0] == 0:
        c.execute("""
            INSERT INTO emotion_state (current_emotion, intensity, timestamp)
            VALUES (?, ?, ?)
        """, ("neutral", 0.5, str(datetime.datetime.now())))
    
    conn.commit()
    conn.close()

def analyze_emotion(text):
    """Analyze text for emotional content"""
    text_lower = text.lower()
    emotion_scores = {}
    
    for emotion, keywords in EMOTION_KEYWORDS.items():
        score = 0
        for keyword in keywords:
            if keyword in text_lower:
                score += 1
        
        # Check for exclamation marks (increases intensity)
        if text.count('!') > 2:
            score += 0.5
        
        # Check for capitalization (shouting = anger/excitement)
        words = text.split()
        caps_words = [w for w in words if w.isupper() and len(w) > 1]
        if len(caps_words) > len(words) * 0.5:
            if emotion in ["angry", "excited"]:
                score += 1
        
        emotion_scores[emotion] = score
    
    # Find dominant emotion
    if emotion_scores:
        dominant_emotion = max(emotion_scores, key=emotion_scores.get)
        max_score = emotion_scores[dominant_emotion]
        
        if max_score > 0:
            # Normalize intensity to 0-1 range
            intensity = min(max_score / 3.0, 1.0)
            return dominant_emotion, intensity
    
    return "neutral", 0.5

def get_current_emotion():
    """Get current emotional state"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT current_emotion, intensity, timestamp FROM emotion_state ORDER BY id DESC LIMIT 1")
    result = c.fetchone()
    conn.close()
    
    if result:
        return result[0], result[1], result[2]
    return "neutral", 0.5, str(datetime.datetime.now())

def update_emotion(emotion, intensity):
    """Update emotional state"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO emotion_state (current_emotion, intensity, timestamp)
        VALUES (?, ?, ?)
    """, (emotion, intensity, str(datetime.datetime.now())))
    conn.commit()
    conn.close()

def decay_emotion():
    """Gradually return emotion to neutral over time"""
    current_emotion, intensity, timestamp = get_current_emotion()
    
    if current_emotion == "neutral":
        return
    
    try:
        emotion_time = datetime.datetime.strptime(timestamp.split('.')[0], "%Y-%m-%d %H:%M:%S")
        now = datetime.datetime.now()
        minutes_passed = (now - emotion_time).total_seconds() / 60
        
        # Decay by 10% every 5 minutes
        decay_amount = (minutes_passed / 5) * 0.1
        
        if intensity - decay_amount <= 0.5:
            update_emotion("neutral", 0.5)
        else:
            update_emotion(current_emotion, intensity - decay_amount)
    except:
        pass

def get_emotional_response_prefix(emotion, intensity):
    """Get a response prefix that matches the emotional state"""
    import random
    
    if emotion in EMOTION_RESPONSES and intensity > 0.5:
        responses = EMOTION_RESPONSES[emotion]
        if responses:
            return random.choice(responses)
    
    return ""

def process_user_emotion(text):
    """Process user input and update emotional state"""
    decay_emotion()
    
    detected_emotion, intensity = analyze_emotion(text)
    
    current_emotion, current_intensity, _ = get_current_emotion()
    
    # Blend emotions (new emotion influences but doesn't completely override)
    if detected_emotion != "neutral":
        if detected_emotion == current_emotion:
            # Same emotion, increase intensity
            new_intensity = min(current_intensity + intensity * 0.3, 1.0)
        else:
            # Different emotion, blend
            new_intensity = intensity * 0.7 + current_intensity * 0.3
            current_emotion = detected_emotion
        
        update_emotion(current_emotion, new_intensity)
    
    return get_current_emotion()

if __name__ == "__main__":
    init_emotion_db()
    print("Emotion engine initialized!")
    
    # Test
    test_messages = [
        "I'm so happy today!",
        "This is really frustrating",
        "I don't understand what you mean",
        "That's amazing!",
        "I'm sad and lonely"
    ]
    
    for msg in test_messages:
        emotion, intensity = process_user_emotion(msg)
        print(f"Message: {msg}")
        print(f"Detected: {emotion} (intensity: {intensity:.2f})")
        print()
      
