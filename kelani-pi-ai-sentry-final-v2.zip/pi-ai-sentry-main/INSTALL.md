# One-command installation

This package is designed for a fresh 64-bit Raspberry Pi OS Lite installation on a Raspberry Pi 4B with 8 GB RAM.

## From your Windows PowerShell after SSH

If this repository is hosted at `https://github.com/tinglycowboy/pi-ai-sentry.git`, run:

```bash
git clone https://github.com/tinglycowboy/pi-ai-sentry.git && cd pi-ai-sentry && chmod +x setup.sh && ./setup.sh
```

The command downloads the repository, enters it, makes the installer executable, and runs the unattended installer.

The installer asks for the normal `sudo` password when Raspberry Pi OS needs administrative access. After that, it does not require interactive configuration for the AI software.

## If installing from the ZIP

```bash
unzip pi-ai-sentry-complete.zip
cd pi-ai-sentry-main
chmod +x setup.sh
./setup.sh
```

## Default acquisition target

The raw acquisition phase is deliberately bounded so a 128 GB SD card is not filled by an unlimited archive:

- FMA Small: about 7.2 GiB of audio plus metadata
- Wikipedia: current English abstract dump, stored as raw XML
- Public-domain Bible collection
- WordNet 3.0
- First 500 Project Gutenberg books from the configured catalog

The Gutenberg limit can be changed before installation:

```bash
AI_SENTRY_GUTENBERG_MAX_BOOKS=1000 ./setup.sh
```

The scheduler will not begin library analysis until every configured acquisition stream reaches its configured completion condition.

## After installation

`ai-sentry.service` starts automatically and runs continuously. The independent RAM guard starts with it and survives a Python failure.

The system automatically resumes after a reboot. SQLite uses WAL mode and the library scheduler checkpoints work so completed downloads/analysis stages are not intentionally repeated.

Useful status commands:

```bash
systemctl status ai-sentry
journalctl -u ai-sentry -f
systemctl status ai-sentry-ram-guard
```

The main application is under:

```text
~/ai_sentry/
```

Raw libraries are under:

```text
~/ai_sentry/libraries/
```

Identity and memory data are stored locally in:

```text
~/ai_sentry/ai_sentry.db
```
