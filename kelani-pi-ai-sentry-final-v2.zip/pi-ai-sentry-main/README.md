# Pi AI Sentry - Raspberry Pi 4 sequential library build

This build is designed for a Raspberry Pi 4B 8 GB / 64-bit Raspberry Pi OS Lite.

## Runtime order

### Phase 1 — raw acquisition

The scheduler downloads/collects configured raw libraries while the system is idle:

1. FMA Small music library
2. Project Gutenberg book text collection
3. Wikipedia raw abstract dump
4. Public-domain Bible texts
5. WordNet lexical reference data

**No AI library analysis occurs during this phase.**

Downloads are resumable where possible. The scheduler records acquisition state in SQLite.

### Phase 2 — sequential analysis

Only after every required acquisition stream reports `complete` does analysis begin.

The scheduler:

1. scores unfinished information
2. chooses the highest-scoring item
3. performs one analysis stage
4. checkpoints its position
5. yields to users/stimuli
6. resumes later from the checkpoint
7. records the result in SQLite
8. rescoring determines what gets processed next

The system supports multiple streams (`music`, `books`, `wikipedia`, `bible`, `other`) without requiring a separate AI process for each.

## Raw libraries vs memory

Raw files remain in:

```text
~/ai_sentry/libraries/
```

SQLite stores indexes, chunks, analysis, scores, and derived memories. Raw files are never replaced by AI summaries.

## Music pipeline

For each FMA track:

```text
MP3
 ├─ audio/tone feature analysis
 └─ Vosk transcription
          ↓
      Qwen synthesis
          ↓
    observations + opinion
          ↓
        SQLite
```

Audio evidence and transcription are kept as separate inputs before synthesis.

FMA Small is the intended collection: 8,000 30-second tracks, about 7.2 GiB.

## RAM safety

Ollama is configured for one loaded model at a time.

The independent RAM guard reboots the Pi when the configured hard RAM limit is exceeded.

Default hard limit: 92%.

Environment variables:

```text
AI_SENTRY_RAM_HARD_LIMIT=92
AI_SENTRY_RAM_MODEL_LIMIT=78
AI_SENTRY_RAM_BACKGROUND_LIMIT=72
AI_SENTRY_IDLE_SECONDS=30
AI_SENTRY_BOOK_BATCH=1
```

The scheduler also stops background acquisition/analysis whenever the AI is busy or RAM is above the background threshold.

## Important storage note

The configured raw libraries must fit the available storage. "Acquisition complete" means all configured targets have completed; it does not mean an unlimited internet archive should be downloaded regardless of available disk space.

On a 128 GB card, use a bounded Gutenberg collection or additional storage rather than attempting an unlimited full archive.

## Installation

Run the repaired `setup.sh` on the Pi. It installs dependencies, Ollama, the three Qwen models, Vosk, and systemd services. Library acquisition starts from the AI Sentry runtime when the system is idle.

Do not run the old repository's setup script over this build.

## Identity and recognition pipeline

The identity subsystem is intentionally separate from Qwen. It has four layers:

```text
Camera -> OpenCV face gate -> Qengineering RetinaFace/ArcFace bridge -> SQLite identity profile
Mic    -> Vosk STT + Vosk speaker model -------------------------------> SQLite identity profile
                                      \-> event/evidence -> Qwen when reasoning is needed
```

### Unknown people can exist without speaking

A face or voice that is not recognized creates an `unknown` profile immediately. The profile can accumulate:

- ArcFace face embeddings / recognition observations
- Vosk speaker vectors / voice observations
- observation counts and timestamps
- confidence scores for face, voice, name, and combined identity
- explicitly supplied or observable facts
- interaction history

The system does **not** require a person to state a name before a profile exists.

### Names are evidence, not automatic truth

Names heard in surrounding conversation enter `identity_name_cache` first. They expire after the configured cache period (`AI_SENTRY_NAME_CACHE_DAYS`, default 14 days) unless repeatedly encountered or associated with a profile.

Statements such as:

```text
"That's Bob."
"His name is Bob."
"No, that's not Bob."
```

are stored as positive or negative evidence against a profile hypothesis. A direct answer to the system's identity question is treated as explicit confirmation.

Confidence is deliberately gradual. A single weak observation does not permanently rename a person, while repeated independent evidence can raise the confidence. Contradictory evidence can lower it without deleting the historical evidence.

### Qengineering backend

The installer downloads Qengineering's Raspberry Pi face-recognition project and builds a small bridge around its RetinaFace + ArcFace pipeline. Qengineering documents this stack for Raspberry Pi 4 64-bit systems and reports separate timing for RetinaFace and ArcFace. citeturn1search0turn1search3

OpenCV remains the first-stage gate, so the heavier recognition backend is not invoked on frames where no face is detected.

### Vosk speaker identification

The installer also downloads Vosk's 13 MB speaker-identification model. Vosk supports speaker vectors in its recognizer in addition to offline speech recognition, so the same microphone pipeline can maintain both transcription and speaker evidence. citeturn5search0turn6search0

### Privacy boundary

Identity profiles are local SQLite data. The system should restrict profile data to identification, interaction history, and information explicitly supplied by people or directly observable from the configured sensors. It should not automatically infer sensitive personal characteristics from faces or voices.
