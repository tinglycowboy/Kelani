#!/usr/bin/env python3
"""RAM watchdog: monitors and manages memory usage with smart cooldown"""
import subprocess
import threading
import time
import sqlite3
import datetime
import os

DB_PATH = "ai_sentry.db"

# Configuration
RAM_WARNING_THRESHOLD = 75
RAM_CRITICAL_THRESHOLD = 85
from config import RAM_HARD_LIMIT_PERCENT
RAM_EMERGENCY_THRESHOLD = RAM_HARD_LIMIT_PERCENT
CHECK_INTERVAL = 30
COOLDOWN_AFTER_UNLOAD = 120  # Don't reload for 2 minutes after emergency unload
MAX_CRITICAL_DURATION = 300  # Reboot if critical for 5 minutes straight

OLLAMA_KEEP_ALIVE_NORMAL = "10m"
OLLAMA_KEEP_ALIVE_LOW_MEMORY = "2m"
OLLAMA_KEEP_ALIVE_CRITICAL = "0"

# State tracking
_last_unload_time = 0
_critical_since = None
_model_unloaded = False

def init_watchdog_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS watchdog_logs (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            ram_used_mb INTEGER,
            ram_total_mb INTEGER,
            ram_percent REAL,
            cpu_temp REAL,
            action_taken TEXT,
            notes TEXT
        )
    """)
    conn.commit()
    conn.close()

def get_ram_usage():
    try:
        result = subprocess.run(['free', '-m'], capture_output=True, text=True)
        lines = result.stdout.strip().split('\n')
        mem_line = lines[1].split()
        total = int(mem_line[1])
        used = int(mem_line[2])
        percent = (used / total) * 100
        return used, total, percent
    except:
        return 0, 0, 0

def get_cpu_temp():
    try:
        result = subprocess.run(['vcgencmd', 'measure_temp'], capture_output=True, text=True)
        temp_str = result.stdout.strip()
        return float(temp_str.replace('temp=', '').replace("'C", ''))
    except:
        return 0.0

def set_ollama_keep_alive(duration):
    """Adjust keep-alive for models already resident; never loads a new model."""
    try:
        import requests
        models=requests.get("http://localhost:11434/api/ps", timeout=5).json().get("models", [])
        for item in models:
            model=item.get("name") or item.get("model")
            if model:
                requests.post("http://localhost:11434/api/generate", json={"model":model,"prompt":"","stream":False,"keep_alive":duration}, timeout=15)
    except Exception as e:
        print(f"Ollama keep-alive warning: {e}")

def force_gc():
    try:
        import gc
        return gc.collect()
    except:
        return 0

def speak_warning(text):
    try:
        subprocess.run(["amixer", "set", "PCM", "100%"], capture_output=True)
        subprocess.run(["espeak", "-v", "en", "-s", "130", text], capture_output=True)
    except:
        pass

def log_watchdog_event(ram_used, ram_total, ram_percent, cpu_temp, action, notes=""):
    import uuid
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO watchdog_logs (id, timestamp, ram_used_mb, ram_total_mb, ram_percent, cpu_temp, action_taken, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), str(datetime.datetime.now()), ram_used, ram_total, ram_percent, cpu_temp, action, notes))
    conn.commit()
    conn.close()

def take_action(ram_percent, cpu_temp):
    global _last_unload_time, _critical_since, _model_unloaded
    
    actions = []
    now = time.time()
    
    if ram_percent >= RAM_EMERGENCY_THRESHOLD:
        if not _model_unloaded:
            set_ollama_keep_alive(OLLAMA_KEEP_ALIVE_CRITICAL)
            collected = force_gc()
            _last_unload_time = now
            _model_unloaded = True
            actions.append(f"EMERGENCY: Unloaded Ollama model, freed {collected} objects")
            log_watchdog_event(*get_ram_usage(), cpu_temp, "emergency_unload", f"Freed {collected} objects")
            speak_warning("System memory is critically low. I have freed up resources. Responses may be slower for a few minutes.")
        
        if _critical_since is None:
            _critical_since = now
        elif (now - _critical_since) > MAX_CRITICAL_DURATION:
            actions.append("REBOOT: Critical RAM for 5+ minutes, rebooting to recover")
            try:
                from task_orchestrator import record_boot_cycle
                record_boot_cycle("RAM_EMERGENCY")
            except Exception as e:
                print(f"Could not persist reasoning boot cycle: {e}")
            log_watchdog_event(*get_ram_usage(), cpu_temp, "reboot", "Critical RAM sustained for 5+ minutes")
            speak_warning("System memory has been critically low for too long. Rebooting now to recover.")
            time.sleep(3)
            subprocess.run(['systemctl', 'reboot'])
            return actions
    
    elif ram_percent >= RAM_CRITICAL_THRESHOLD:
        if _critical_since is None:
            _critical_since = now
        
        if not _model_unloaded:
            set_ollama_keep_alive(OLLAMA_KEEP_ALIVE_LOW_MEMORY)
            collected = force_gc()
            actions.append(f"CRITICAL: Reduced Ollama keep-alive to 2min, freed {collected} objects")
            log_watchdog_event(*get_ram_usage(), cpu_temp, "critical_reduce", f"Freed {collected} objects")
    
    elif ram_percent >= RAM_WARNING_THRESHOLD:
        _critical_since = None
        
        if _model_unloaded and (now - _last_unload_time) < COOLDOWN_AFTER_UNLOAD:
            actions.append("WARNING: In cooldown period, keeping model unloaded")
        else:
            collected = force_gc()
            actions.append(f"WARNING: Garbage collected {collected} objects")
            log_watchdog_event(*get_ram_usage(), cpu_temp, "warning_gc", f"Freed {collected} objects")
    
    else:
        _critical_since = None
        
        if _model_unloaded:
            if (now - _last_unload_time) >= COOLDOWN_AFTER_UNLOAD:
                set_ollama_keep_alive(OLLAMA_KEEP_ALIVE_NORMAL)
                _model_unloaded = False
                actions.append("NORMAL: Cooldown complete, restored Ollama keep-alive to 10min")
                log_watchdog_event(*get_ram_usage(), cpu_temp, "restore_normal", "Cooldown complete, model will reload on next query")
                speak_warning("System memory has recovered. I am back to full speed.")
            else:
                remaining = int(COOLDOWN_AFTER_UNLOAD - (now - _last_unload_time))
                actions.append(f"NORMAL: Cooldown active, {remaining}s remaining")
        else:
            set_ollama_keep_alive(OLLAMA_KEEP_ALIVE_NORMAL)
    
    if cpu_temp > 80:
        actions.append(f"HIGH TEMP: CPU at {cpu_temp}C, throttling may occur")
        log_watchdog_event(*get_ram_usage(), cpu_temp, "high_temp_warning", f"CPU temp {cpu_temp}C")
    
    return actions

def watchdog_loop(stop_event, status_callback=None):
    global _critical_since
    print("🔍 RAM Watchdog started")
    
    while not stop_event.is_set():
        try:
            ram_used, ram_total, ram_percent = get_ram_usage()
            cpu_temp = get_cpu_temp()
            
            actions = take_action(ram_percent, cpu_temp)
            
            if ram_percent >= RAM_EMERGENCY_THRESHOLD:
                status = "emergency"
            elif ram_percent >= RAM_CRITICAL_THRESHOLD:
                status = "critical"
            elif ram_percent >= RAM_WARNING_THRESHOLD:
                status = "warning"
            else:
                status = "normal"
            
            status_data = {
                "ram_used": ram_used,
                "ram_total": ram_total,
                "ram_percent": round(ram_percent, 1),
                "cpu_temp": round(cpu_temp, 1),
                "actions": actions,
                "status": status,
                "model_unloaded": _model_unloaded,
                "critical_duration": int(time.time() - _critical_since) if _critical_since else 0
            }
            
            if status_callback:
                status_callback(status_data)
            
            if actions:
                for action in actions:
                    print(f"🔍 Watchdog: {action}")
        
        except Exception as e:
            print(f"Watchdog error: {e}")
        
        time.sleep(CHECK_INTERVAL)

def get_current_status():
    ram_used, ram_total, ram_percent = get_ram_usage()
    cpu_temp = get_cpu_temp()
    
    if ram_percent >= RAM_EMERGENCY_THRESHOLD:
        status = "emergency"
    elif ram_percent >= RAM_CRITICAL_THRESHOLD:
        status = "critical"
    elif ram_percent >= RAM_WARNING_THRESHOLD:
        status = "warning"
    else:
        status = "normal"
    
    return {
        "ram_used": ram_used,
        "ram_total": ram_total,
        "ram_percent": round(ram_percent, 1),
        "cpu_temp": round(cpu_temp, 1),
        "status": status,
        "model_unloaded": _model_unloaded
    }

if __name__ == "__main__":
    init_watchdog_db()
    print("RAM Watchdog initialized!")
    print(f"Current status: {get_current_status()}")
