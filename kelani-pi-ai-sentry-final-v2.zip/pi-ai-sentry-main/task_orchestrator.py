#!/usr/bin/env python3
"""Kelani adaptive reasoning controller.

The orchestrator owns the task. Qwen only performs checkpointed reasoning attempts.
It starts every normal AI task with qwen3:0.6b, escalates when needed, can pause for
local knowledge retrieval, recursively decomposes work, and records checkpoints in SQLite.
"""
import datetime, json, os, re, sqlite3, subprocess, time, uuid
from typing import Callable, Dict, List, Optional, Tuple

from config import DB_PATH, RAM_HARD_LIMIT_PERCENT, RAM_MODEL_LOAD_LIMIT_PERCENT, REASONING_MAX_PARTS
from model_manager import LIGHT_MODEL, MEDIUM_MODEL, EXTREME_MODEL, generate, switch_model

SCHEMA = """
CREATE TABLE IF NOT EXISTS reasoning_tasks (
 id TEXT PRIMARY KEY,
 parent_id TEXT,
 root_id TEXT,
 prompt TEXT NOT NULL,
 status TEXT NOT NULL,
 model TEXT,
 depth INTEGER DEFAULT 0,
 piece_index INTEGER DEFAULT 0,
 total_pieces INTEGER DEFAULT 1,
 attempts INTEGER DEFAULT 0,
 research_rounds INTEGER DEFAULT 0,
 decomposition_rounds INTEGER DEFAULT 0,
 boot_cycle_count INTEGER DEFAULT 0,
 result TEXT,
 checkpoint_json TEXT,
 failure_reason TEXT,
 created_at TEXT,
 updated_at TEXT,
 FOREIGN KEY(parent_id) REFERENCES reasoning_tasks(id)
);
CREATE TABLE IF NOT EXISTS reasoning_adaptations (
 id INTEGER PRIMARY KEY,
 task_type TEXT,
 strategy TEXT,
 outcome TEXT,
 attempts INTEGER DEFAULT 1,
 successes INTEGER DEFAULT 0,
 failures INTEGER DEFAULT 0,
 avg_depth REAL DEFAULT 0,
 last_used TEXT,
 UNIQUE(task_type,strategy)
);
CREATE TABLE IF NOT EXISTS reasoning_events (
 id INTEGER PRIMARY KEY,
 task_id TEXT,
 timestamp TEXT,
 event TEXT,
 model TEXT,
 ram_percent REAL,
 details TEXT
);
CREATE INDEX IF NOT EXISTS idx_reasoning_tasks_status ON reasoning_tasks(status,updated_at);
CREATE INDEX IF NOT EXISTS idx_reasoning_tasks_root ON reasoning_tasks(root_id);
"""

REFUSAL_MARKERS = (
    "i don't know", "i do not know", "i'm not sure", "i am not sure",
    "i cannot answer", "i can't answer", "i cannot help", "i can't help",
    "not enough information", "insufficient information", "i don't have enough",
    "unable to determine", "cannot determine", "no information available"
)
RESEARCH_MARKER = re.compile(r"RESEARCH_REQUEST\s*:\s*(.+)", re.I)


def _now():
    return datetime.datetime.now().isoformat()


def _ram_percent():
    try:
        parts = subprocess.check_output(["free", "-m"], text=True).splitlines()[1].split()
        return float(parts[2]) * 100.0 / float(parts[1])
    except Exception:
        return 0.0


def init_reasoning_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with sqlite3.connect(DB_PATH) as c:
        c.executescript(SCHEMA)


def _event(task_id, event, model="", details=""):
    try:
        with sqlite3.connect(DB_PATH) as c:
            c.execute(
                "INSERT INTO reasoning_events(task_id,timestamp,event,model,ram_percent,details) VALUES(?,?,?,?,?,?)",
                (task_id, _now(), event, model, _ram_percent(), details[:4000]),
            )
    except Exception as exc:
        print(f"Reasoning event log error: {exc}")


def _task(row):
    with sqlite3.connect(DB_PATH) as c:
        c.execute("INSERT INTO reasoning_tasks(id,parent_id,root_id,prompt,status,depth,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                  (row["id"], row.get("parent_id"), row["root_id"], row["prompt"], row.get("status", "queued"),
                   row.get("depth", 0), _now(), _now()))


def _update(task_id, **fields):
    if not fields:
        return
    fields["updated_at"] = _now()
    keys = list(fields)
    with sqlite3.connect(DB_PATH) as c:
        c.execute(f"UPDATE reasoning_tasks SET {','.join(k+'=?' for k in keys)} WHERE id=?",
                  [fields[k] for k in keys] + [task_id])


def record_boot_cycle(reason="RAM_EMERGENCY"):
    """Persist a retry count before a watchdog-triggered reboot."""
    init_reasoning_db()
    try:
        with sqlite3.connect(DB_PATH) as c:
            rows = c.execute("SELECT id,boot_cycle_count FROM reasoning_tasks WHERE status IN ('running','decomposing','waiting_for_knowledge','checkpointed')").fetchall()
            for task_id, count in rows:
                new_count = int(count or 0) + 1
                c.execute("UPDATE reasoning_tasks SET boot_cycle_count=?,status='checkpointed',failure_reason=?,updated_at=? WHERE id=?",
                          (new_count, reason, _now(), task_id))
                c.execute("INSERT INTO reasoning_events(task_id,timestamp,event,model,ram_percent,details) VALUES(?,?,?,?,?,?)",
                          (task_id, _now(), "boot_cycle", "", _ram_percent(), f"count={new_count}; reason={reason}"))
    except Exception as exc:
        print(f"Boot-cycle persistence error: {exc}")

def recover_after_boot():
    """Recover interrupted reasoning tasks after a reboot; abandon tasks after 3 cycles."""
    init_reasoning_db()
    recovered = []
    try:
        with sqlite3.connect(DB_PATH) as c:
            c.row_factory = sqlite3.Row
            rows = c.execute("SELECT * FROM reasoning_tasks WHERE status='checkpointed' ORDER BY updated_at").fetchall()
            for row in rows:
                task_id = row["id"]
                count = int(row["boot_cycle_count"] or 0)
                if count >= 3:
                    c.execute("UPDATE reasoning_tasks SET status='abandoned',checkpoint_json=NULL,result=NULL,failure_reason=?,updated_at=? WHERE id=?",
                              ("three boot-cycle failures; temporary computation discarded", _now(), task_id))
                    c.execute("INSERT INTO reasoning_events(task_id,timestamp,event,model,ram_percent,details) VALUES(?,?,?,?,?,?)",
                              (task_id, _now(), "task_abandoned_after_boot_loop", "", _ram_percent(), "temporary reasoning checkpoint cleared"))
                    recovered.append((task_id, "abandoned"))
                else:
                    c.execute("UPDATE reasoning_tasks SET status='queued',updated_at=? WHERE id=?", (_now(), task_id))
                    recovered.append((task_id, "queued"))
    except Exception as exc:
        print(f"Reasoning boot recovery error: {exc}")
    return recovered

def _load(task_id):
    with sqlite3.connect(DB_PATH) as c:
        c.row_factory = sqlite3.Row
        r = c.execute("SELECT * FROM reasoning_tasks WHERE id=?", (task_id,)).fetchone()
        return dict(r) if r else None


def _task_kind(prompt: str) -> str:
    p = prompt.lower()
    if any(x in p for x in ("code", "program", "script", "debug", "python")):
        return "technical"
    if any(x in p for x in ("compare", "contrast", "versus", "difference")):
        return "comparison"
    if any(x in p for x in ("research", "history", "analyze", "analysis", "comprehensive")):
        return "research"
    if any(x in p for x in ("what is", "define", "meaning", "dictionary", "thesaurus")):
        return "reference"
    return "general"


def _adaptive_hint(prompt: str) -> str:
    kind = _task_kind(prompt)
    try:
        with sqlite3.connect(DB_PATH) as c:
            r = c.execute("SELECT strategy, successes, failures FROM reasoning_adaptations WHERE task_type=? ORDER BY successes DESC, failures ASC LIMIT 1", (kind,)).fetchone()
        if r:
            return f"Previous successful strategy for {kind}: {r[0]}."
    except Exception:
        pass
    return ""


def _record_adaptation(prompt: str, strategy: str, success: bool, depth: int):
    kind = _task_kind(prompt)
    try:
        with sqlite3.connect(DB_PATH) as c:
            c.execute("""INSERT INTO reasoning_adaptations(task_type,strategy,outcome,attempts,successes,failures,avg_depth,last_used)
                         VALUES(?,?,?,?,?,?,?,?)
                         ON CONFLICT(task_type,strategy) DO UPDATE SET
                         attempts=attempts+1, successes=successes+excluded.successes,
                         failures=failures+excluded.failures,
                         avg_depth=((avg_depth*(attempts-1))+excluded.avg_depth)/attempts,
                         outcome=excluded.outcome,last_used=excluded.last_used""",
                      (kind, strategy, "success" if success else "failure", 1, int(success), int(not success), float(depth), _now()))
    except Exception as exc:
        print(f"Adaptation log error: {exc}")


def _looks_usable(answer: str, prompt: str) -> bool:
    if not answer or len(answer.strip()) < 8:
        return False
    low = answer.lower().strip()
    if RESEARCH_MARKER.search(answer):
        return False
    if any(m in low for m in REFUSAL_MARKERS):
        return False
    # A long/multi-operation task producing only a sentence is a likely shallow failure.
    complexity = len(prompt.split()) + sum(prompt.lower().count(x) for x in (" and ", "compare", "analyze", "explain", "why", "how")) * 15
    if complexity > 130 and len(answer) < 80:
        return False
    return True


def _research_from_callback(query: str, research_callback: Optional[Callable[[str], str]]) -> str:
    if not research_callback:
        return ""
    try:
        return research_callback(query) or ""
    except Exception as exc:
        print(f"Research callback error: {exc}")
        return ""


def _extract_research(answer: str) -> Optional[str]:
    m = RESEARCH_MARKER.search(answer or "")
    return m.group(1).strip() if m else None


def _decompose_with_light(prompt: str, context: str, max_parts=None) -> List[str]:
    max_parts = max_parts or REASONING_MAX_PARTS
    instruction = (
        "Break the following task into 2 to 4 independent, answerable work units. "
        "Do not solve them. Preserve the original goal. Each line must begin with TASK:. "
        "Do not invent missing facts. If the task is already atomic, return TASK: the original task.\n\n"
        f"TASK:\n{prompt}\n\nCONTEXT:\n{context[:5000]}"
    )
    try:
        switch_model(LIGHT_MODEL)
        out = generate(instruction, system="You are Kelani's task decomposition controller. Output only TASK: lines.",
                       num_predict=350, temperature=0.1, timeout=45, model=LIGHT_MODEL, keep_alive="2m")
        parts = [m.group(1).strip() for m in re.finditer(r"^TASK\s*:\s*(.+)$", out or "", re.I | re.M)]
        parts = [p for p in parts if len(p) > 8]
        if 1 < len(parts) <= max_parts:
            return parts
    except Exception as exc:
        print(f"Task decomposition model error: {exc}")
    # Deterministic fallback: split explicit numbered/semicolon/conjunctive operations.
    raw = re.split(r"\s*(?:\n+|;|\bthen\b|\band then\b)\s*", prompt, flags=re.I)
    parts = [p.strip(" .") for p in raw if len(p.strip()) > 12]
    if len(parts) <= 1:
        clauses = re.split(r"\s*,\s*(?=(?:explain|compare|analyze|find|identify|describe|determine|summarize)\b)", prompt, flags=re.I)
        parts = [p.strip(" .") for p in clauses if len(p.strip()) > 12]
    return parts[:max_parts] if len(parts) > 1 else [prompt]


def _synthesis_prompt(original: str, results: List[Dict], context: str) -> str:
    blocks = []
    for i, r in enumerate(results, 1):
        blocks.append(f"PART {i}\nTask: {r['task']}\nResult: {r['result']}\nSources: {r.get('sources','')}")
    return (
        "Produce the final answer to the original request using ONLY the verified task results below and the supplied context. "
        "Do not invent facts. If the evidence is genuinely insufficient, say exactly: I honestly don't know. "
        "Do not mention internal task decomposition unless useful to explain uncertainty.\n\n"
        f"ORIGINAL REQUEST:\n{original}\n\nCONTEXT:\n{context[:6000]}\n\n" + "\n\n".join(blocks)
    )


def _attempt(model: str, prompt: str, system: str, timeout: int, num_predict: int, research_callback, task_id: str, context: str):
    ram = _ram_percent()
    if ram >= RAM_HARD_LIMIT_PERCENT or (model == EXTREME_MODEL and ram >= RAM_MODEL_LOAD_LIMIT_PERCENT):
        return "", "ram_blocked", context
    _update(task_id, status="running", model=model, attempts=(_load(task_id) or {}).get("attempts", 0) + 1)
    _event(task_id, "model_attempt", model, f"RAM={ram:.1f}%")
    try:
        answer = generate(prompt, system=system, num_predict=num_predict, temperature=0.6,
                          timeout=timeout, model=model, keep_alive="5m") or ""
    except Exception as exc:
        return "", "generation_error", context
    research_query = _extract_research(answer)
    if research_query:
        _update(task_id, status="waiting_for_knowledge", research_rounds=((_load(task_id) or {}).get("research_rounds", 0) + 1))
        _event(task_id, "research_requested", model, research_query)
        evidence = _research_from_callback(research_query, research_callback)
        if evidence:
            context = (context + "\n\nLOCAL RESEARCH:\n" + evidence)[-12000:]
            _update(task_id, checkpoint_json=json.dumps({"context": context, "research_query": research_query}))
            answer = generate(prompt, system=system + "\n\nUse the LOCAL RESEARCH below to continue your answer. Do not ask for more research unless necessary.\n" + context,
                             num_predict=num_predict, temperature=0.6, timeout=timeout, model=model, keep_alive="5m") or ""
        else:
            return "", "research_unavailable", context
    if _looks_usable(answer, prompt):
        return answer, "success", context
    return answer, "insufficient", context


def run_reasoning_task(original_prompt: str, system_instruction: str = "", context: str = "",
                       research_callback: Optional[Callable[[str], str]] = None,
                       socketio=None, max_depth: int = 4, max_research_rounds: int = 3) -> Dict:
    """Run a task using light→medium→large→recursive decomposition.

    Returns result, status, task_id, model, and diagnostic metadata.
    """
    init_reasoning_db()
    root_id = str(uuid.uuid4())
    _task({"id": root_id, "root_id": root_id, "prompt": original_prompt, "status": "running"})
    _event(root_id, "task_started", LIGHT_MODEL, _adaptive_hint(original_prompt))

    def progress(msg, task_id=root_id):
        if socketio:
            socketio.emit("thinking_update", {"message": msg, "task_id": task_id})

    def solve(task_id: str, prompt: str, base_context: str, depth: int) -> Tuple[str, str, List[Dict]]:
        if depth > max_depth:
            _update(task_id, status="failed", failure_reason="maximum decomposition depth reached")
            return "", "insufficient", []
        context_now = base_context
        base = system_instruction + "\nYou are Kelani. Be accurate. If local information is missing, request it with RESEARCH_REQUEST: <query>. Do not invent facts."
        adaptive = _adaptive_hint(prompt)
        if adaptive:
            base += "\n" + adaptive

        # Always start this task/piece with the light model.
        attempts = [(LIGHT_MODEL, 45, 180), (MEDIUM_MODEL, 90, 500), (EXTREME_MODEL, 180, 900)]
        for idx, (model, timeout, tokens) in enumerate(attempts):
            label = "light" if idx == 0 else ("medium" if idx == 1 else "large")
            progress(f"{label.title()} reasoning attempt in progress.")
            answer, reason, context_now = _attempt(model, prompt, base, timeout, tokens, research_callback, task_id, context_now)
            if reason == "success":
                _update(task_id, status="completed", model=model, result=answer, checkpoint_json=json.dumps({"context": context_now[-12000:]}))
                _record_adaptation(prompt, f"direct_{model}", True, depth)
                return answer, "success", [{"task": prompt, "result": answer}]
            if reason == "ram_blocked" and model == EXTREME_MODEL:
                _event(task_id, "large_model_blocked_by_ram", model, "decompose instead")
                break
            if reason in ("research_unavailable",) and idx < 2:
                continue
            if idx == 0:
                _event(task_id, "light_failed_escalating", model, reason)
            elif idx == 1:
                _event(task_id, "medium_failed_escalating", model, reason)
            else:
                _event(task_id, "large_failed_decomposing", model, reason)

        if depth >= max_depth:
            _update(task_id, status="failed", failure_reason="insufficient information after maximum supported reasoning")
            _record_adaptation(prompt, "decompose_depth_limit", False, depth)
            return "", "insufficient", []

        progress(f"Decomposing the task into smaller reasoning units (level {depth + 1}).")
        _update(task_id, status="decomposing", decomposition_rounds=((_load(task_id) or {}).get("decomposition_rounds", 0) + 1))
        parts = _decompose_with_light(prompt, context_now)
        parts = [p for p in parts if p.strip() and p.strip() != prompt.strip()]
        if not parts:
            _update(task_id, status="failed", failure_reason="task could not be usefully decomposed")
            return "", "insufficient", []
        results = []
        for i, part in enumerate(parts, 1):
            child_id = str(uuid.uuid4())
            _task({"id": child_id, "parent_id": task_id, "root_id": root_id, "prompt": part, "status": "queued", "depth": depth + 1})
            _update(child_id, piece_index=i, total_pieces=len(parts))
            child_context = (context_now + "\n\nPREVIOUS COMPLETED PARTS:\n" +
                             "\n".join(f"{r['task']}: {r['result']}" for r in results))[-12000:]
            result, status, nested = solve(child_id, part, child_context, depth + 1)
            if status == "success" and result:
                results.append({"task": part, "result": result})
            else:
                _event(child_id, "piece_failed", "", "No reliable result")

        if not results:
            _update(task_id, status="failed", failure_reason="all decomposed pieces failed")
            _record_adaptation(prompt, "recursive_decomposition", False, depth)
            return "", "insufficient", []

        synth_prompt = _synthesis_prompt(prompt, results, context_now)
        progress("Reconstructing the parent task from completed pieces.")
        # Synthesis also starts at light, then escalates/decomposes if necessary.
        synth, synth_status, _ = solve_synthesis(task_id, synth_prompt, base, context_now)
        if synth_status == "success":
            _update(task_id, status="completed", result=synth, checkpoint_json=json.dumps({"pieces": results, "context": context_now[-8000:]}))
            _record_adaptation(prompt, "recursive_decomposition", True, depth)
            return synth, "success", results
        _update(task_id, status="failed", failure_reason="synthesis remained insufficient")
        _record_adaptation(prompt, "recursive_decomposition", False, depth)
        return "", "insufficient", results

    def solve_synthesis(task_id, prompt, base, context_now):
        for model, timeout, tokens in ((LIGHT_MODEL, 45, 220), (MEDIUM_MODEL, 90, 550), (EXTREME_MODEL, 180, 1000)):
            answer, reason, context_now = _attempt(model, prompt, base, timeout, tokens, research_callback, task_id, context_now)
            if reason == "success":
                return answer, "success", context_now
            if reason == "ram_blocked" and model == EXTREME_MODEL:
                break
        return "", "insufficient", context_now

    result, status, pieces = solve(root_id, original_prompt, context, 0)
    if status != "success":
        result = "I honestly don't know based on the information available to me."
        _update(root_id, status="insufficient_information", result=result)
    else:
        _update(root_id, status="completed", result=result)
    _event(root_id, "task_finished", get_model_safe(), status)
    return {"task_id": root_id, "status": status, "result": result, "pieces": pieces, "model": get_model_safe()}


def get_model_safe():
    try:
        from model_manager import get_current_model
        return get_current_model()
    except Exception:
        return ""


if __name__ == "__main__":
    init_reasoning_db()
    print("Kelani reasoning orchestrator database initialized.")
