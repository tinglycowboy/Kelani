#!/usr/bin/env python3
import pyudev
import subprocess
import time
import os

def on_device_event(action, device):
    """Called when a USB device is added or removed"""
    if action == 'add':
        print(f"🔌 USB device added: {device.get('ID_VENDOR', 'Unknown')} {device.get('ID_MODEL', 'Unknown')}")
        
        # Check if it's a camera or microphone
        device_class = device.get('ID_USB_CLASS', '')
        
        # Video device (camera)
        if device_class == '0e' or 'video' in str(device).lower():
            print("📷 Camera detected, triggering reboot...")
            trigger_reboot()
        
        # Audio device (microphone)
        elif device_class == '01' or 'audio' in str(device).lower():
            print("🎤 Microphone detected, triggering reboot...")
            trigger_reboot()
        
        # Generic USB device - check after a delay
        else:
            print("🔍 Generic USB device detected, checking in 2 seconds...")
            time.sleep(2)
            check_and_reboot()

def trigger_reboot():
    """Reboot the system to initialize new hardware"""
    print("🔄 Rebooting in 3 seconds to initialize new hardware...")
    time.sleep(3)
    subprocess.run(['sudo', 'reboot'])

def check_and_reboot():
    """Check if new hardware was added and reboot if needed"""
    from hardware_detect import detect_new_hardware
    
    if detect_new_hardware():
        trigger_reboot()

def main():
    """Main monitoring loop"""
    print("👀 Starting USB hardware monitor...")
    
    context = pyudev.Context()
    monitor = pyudev.Monitor.from_netlink(context)
    monitor.filter_by(subsystem='usb')
    
    # Start monitoring
    for action, device in monitor:
        if device.get('DEVTYPE') == 'usb_device':
            on_device_event(action, device)

if __name__ == "__main__":
    main()
  
