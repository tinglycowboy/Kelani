#!/usr/bin/env python3
"""Main preprocessor: orchestrates all preprocessing modules"""
import sys
import importlib

# Lazy-loaded modules
_modules = {}

def _load_module(name):
    """Lazy load a module"""
    if name not in _modules:
        try:
            _modules[name] = importlib.import_module(name)
        except ImportError as e:
            print(f"Warning: Could not load {name}: {e}")
            _modules[name] = None
    return _modules[name]

def preprocess(text, person_id=None, context=None):
    """
    Run full preprocessing pipeline on input text
    
    Returns dict with:
    - processed_text: text after safety filters
    - safe_to_process: bool
    - warning: optional warning message
    - nlp: NLP analysis results
    - route: routing decision
    - entities: extracted entities
    - sentiment: sentiment analysis
    - urgency: urgency detection
    - keywords: extracted keywords
    - anomalies: detected anomalies (if any)
    """
    result = {
        "original_text": text,
        "processed_text": text,
        "safe_to_process": True,
        "warning": None,
        "nlp": None,
        "route": None,
        "entities": {},
        "sentiment": None,
        "urgency": None,
        "keywords": [],
        "anomalies": None,
        "preferences": None
    }
    
    # 1. Safety filters
    safety = _load_module("safety_filters")
    if safety:
        safety_result = safety.process_safety(text, person_id)
        result["processed_text"] = safety_result["redacted"]
        result["safe_to_process"] = safety_result["safe_to_process"]
        
        if not safety_result["safe_to_process"]:
            result["warning"] = safety.get_safety_warning(safety_result)
            return result
        
        if safety_result["action"] in ["redact", "redact_and_warn"]:
            result["warning"] = safety.get_safety_warning(safety_result)
    
    # 2. NLP processors
    nlp = _load_module("nlp_processors")
    if nlp:
        nlp_result = nlp.process_all(result["processed_text"])
        result["nlp"] = nlp_result
        result["entities"] = nlp_result["entities"]
        result["sentiment"] = nlp_result["sentiment"]
        result["urgency"] = nlp_result["urgency"]
        result["keywords"] = nlp_result["keywords"]
    
    # 3. Smart routing
    router = _load_module("smart_router")
    if router:
        route_result = router.determine_route(result["processed_text"], nlp_result)
        result["route"] = route_result
    
    # 4. Anomaly detection (if person_id provided)
    if person_id:
        analytics = _load_module("analytics")
        if analytics:
            anomalies = analytics.detect_anomaly(person_id, result["processed_text"])
            if anomalies:
                result["anomalies"] = anomalies
                # Log anomalies
                for anomaly in anomalies:
                    analytics.log_anomaly(person_id, anomaly["type"], anomaly["description"], anomaly["severity"])
        
        # Get user preferences
        if analytics:
            prefs = analytics.get_preferences(person_id)
            if prefs:
                result["preferences"] = prefs
    
    return result

def get_route_handler(route_result):
    """Get the handler function name for a route"""
    router = _load_module("smart_router")
    if router:
        return router.get_route_handler(route_result.get("route", "ai_general"))
    return "handle_ai_general"

if __name__ == "__main__":
    # Test
    test_inputs = [
        "My SSN is 123-45-6789",
        "what is 15 * 7",
        "hello",
        "tell me about skiing",
        "URGENT: what time is it?"
    ]
    
    for text in test_inputs:
        result = preprocess(text)
        print(f"\nInput: {text}")
        print(f"Safe: {result['safe_to_process']}")
        print(f"Route: {result['route']['route'] if result['route'] else 'none'}")
        print(f"Warning: {result['warning']}")
        print(f"Entities: {result['entities']}")
