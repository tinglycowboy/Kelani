#!/usr/bin/env python3
"""Analytics: user preferences, behavioral patterns, anomaly detection"""
import sqlite3
import datetime
import json
from collections import Counter, defaultdict

DB_PATH = "ai_sentry.db"

def init_analytics_db():
    """Create analytics tables"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS user_preferences (
            person_id TEXT PRIMARY KEY,
            preferred_response_length TEXT DEFAULT 'medium',
            preferred_topics TEXT,
            disliked_topics TEXT,
            interaction_style TEXT DEFAULT 'neutral',
            last_updated TEXT
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS behavioral_patterns (
            id TEXT PRIMARY KEY,
            person_id TEXT,
            pattern_type TEXT,
            pattern_data TEXT,
            confidence REAL,
            first_observed TEXT,
            last_observed TEXT,
            occurrence_count INTEGER DEFAULT 1
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS anomalies (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            person_id TEXT,
            anomaly_type TEXT,
            description TEXT,
            severity TEXT
        )
    """)
    
    conn.commit()
    conn.close()

# User Preferences
def update_preferences(person_id, interaction_data):
    """Update user preferences based on interaction"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Check if preferences exist
    c.execute("SELECT person_id FROM user_preferences WHERE person_id = ?", (person_id,))
    if not c.fetchone():
        c.execute("""
            INSERT INTO user_preferences (person_id, last_updated)
            VALUES (?, ?)
        """, (person_id, str(datetime.datetime.now())))
    
    # Analyze response length preference
    response_length = interaction_data.get("response_length", "medium")
    c.execute("""
        UPDATE user_preferences 
        SET preferred_response_length = ?, last_updated = ?
        WHERE person_id = ?
    """, (response_length, str(datetime.datetime.now()), person_id))
    
    conn.commit()
    conn.close()

def get_preferences(person_id):
    """Get user preferences"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("SELECT * FROM user_preferences WHERE person_id = ?", (person_id,))
    result = c.fetchone()
    conn.close()
    
    if result:
        return {
            "person_id": result[0],
            "preferred_response_length": result[1],
            "preferred_topics": json.loads(result[2]) if result[2] else [],
            "disliked_topics": json.loads(result[3]) if result[3] else [],
            "interaction_style": result[4]
        }
    return None

# Behavioral Patterns
def detect_patterns(person_id):
    """Detect behavioral patterns for a person"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Get recent conversations
    c.execute("""
        SELECT timestamp, message, role
        FROM person_conversations
        WHERE person_id = ?
        ORDER BY timestamp DESC
        LIMIT 50
    """, (person_id,))
    
    conversations = c.fetchall()
    conn.close()
    
    if len(conversations) < 5:
        return []
    
    patterns = []
    
    # Pattern 1: Time of day preferences
    hours = []
    for conv in conversations:
        if conv[2] == "user":  # Only user messages
            try:
                ts = datetime.datetime.strptime(conv[0].split('.')[0], "%Y-%m-%d %H:%M:%S")
                hours.append(ts.hour)
            except:
                pass
    
    if hours:
        hour_counts = Counter(hours)
        most_common_hour = hour_counts.most_common(1)[0][0]
        if hour_counts[most_common_hour] >= 3:
            time_of_day = "morning" if 5 <= most_common_hour < 12 else \
                         "afternoon" if 12 <= most_common_hour < 17 else \
                         "evening" if 17 <= most_common_hour < 21 else "night"
            patterns.append({
                "type": "preferred_time",
                "data": {"time_of_day": time_of_day, "hour": most_common_hour},
                "confidence": hour_counts[most_common_hour] / len(hours)
            })
    
    # Pattern 2: Topic preferences
    from conversation_summarizer import get_topic_summary
    topics = []
    for i in range(0, len(conversations) - 1, 2):
        if i + 1 < len(conversations):
            msgs = [{"role": conversations[i][2], "message": conversations[i][1]},
                    {"role": conversations[i+1][2], "message": conversations[i+1][1]}]
            topic = get_topic_summary(msgs)
            topics.append(topic)
    
    if topics:
        topic_counts = Counter(topics)
        top_topic = topic_counts.most_common(1)[0]
        if top_topic[1] >= 3:
            patterns.append({
                "type": "preferred_topic",
                "data": {"topic": top_topic[0], "frequency": top_topic[1]},
                "confidence": top_topic[1] / len(topics)
            })
    
    # Pattern 3: Question frequency
    question_count = sum(1 for conv in conversations if conv[2] == "user" and "?" in conv[1])
    user_msg_count = sum(1 for conv in conversations if conv[2] == "user")
    
    if user_msg_count > 0:
        question_ratio = question_count / user_msg_count
        if question_ratio > 0.7:
            patterns.append({
                "type": "question_heavy",
                "data": {"ratio": question_ratio},
                "confidence": question_ratio
            })
        elif question_ratio < 0.3:
            patterns.append({
                "type": "statement_heavy",
                "data": {"ratio": question_ratio},
                "confidence": 1 - question_ratio
            })
    
    return patterns

# Anomaly Detection
def detect_anomaly(person_id, current_message):
    """Detect if current message is anomalous"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Get recent messages from this person
    c.execute("""
        SELECT timestamp, message
        FROM person_conversations
        WHERE person_id = ? AND role = 'user'
        ORDER BY timestamp DESC
        LIMIT 20
    """, (person_id,))
    
    recent = c.fetchall()
    conn.close()
    
    if len(recent) < 5:
        return None
    
    anomalies = []
    
    # Anomaly 1: Unusual time
    try:
        now = datetime.datetime.now()
        current_hour = now.hour
        
        # Get typical hours
        typical_hours = []
        for msg in recent:
            try:
                ts = datetime.datetime.strptime(msg[0].split('.')[0], "%Y-%m-%d %H:%M:%S")
                typical_hours.append(ts.hour)
            except:
                pass
        
        if typical_hours:
            avg_hour = sum(typical_hours) / len(typical_hours)
            hour_diff = abs(current_hour - avg_hour)
            
            if hour_diff > 6:  # More than 6 hours from typical
                anomalies.append({
                    "type": "unusual_time",
                    "description": f"Message at {current_hour}:00, typically active around {int(avg_hour)}:00",
                    "severity": "medium"
                })
    except:
        pass
    
    # Anomaly 2: Unusual message length
    recent_lengths = [len(msg[1]) for msg in recent]
    current_length = len(current_message)
    avg_length = sum(recent_lengths) / len(recent_lengths)
    
    if current_length > avg_length * 3 or current_length < avg_length * 0.3:
        anomalies.append({
            "type": "unusual_length",
            "description": f"Message length {current_length}, average is {int(avg_length)}",
            "severity": "low"
        })
    
    # Anomaly 3: Sentiment shift
    from nlp_processors import analyze_sentiment
    current_sentiment = analyze_sentiment(current_message)["score"]
    
    recent_sentiments = []
    for msg in recent[:10]:
        sent = analyze_sentiment(msg[1])["score"]
        recent_sentiments.append(sent)
    
    if recent_sentiments:
        avg_sentiment = sum(recent_sentiments) / len(recent_sentiments)
        sentiment_shift = abs(current_sentiment - avg_sentiment)
        
        if sentiment_shift > 1.0:
            anomalies.append({
                "type": "sentiment_shift",
                "description": f"Sentiment shifted from {avg_sentiment:.2f} to {current_sentiment:.2f}",
                "severity": "medium"
            })
    
    return anomalies if anomalies else None

def log_anomaly(person_id, anomaly_type, description, severity):
    """Log detected anomaly"""
    import uuid
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        INSERT INTO anomalies (id, timestamp, person_id, anomaly_type, description, severity)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), str(datetime.datetime.now()), person_id, anomaly_type, description, severity))
    
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_analytics_db()
    print("Analytics system initialized!")
