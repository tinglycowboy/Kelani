#!/usr/bin/env python3
"""USB Blocker: Detects and blocks unauthorized USB devices (only cameras and mics allowed)"""
import pyudev
import subprocess
import time
import os
import sqlite3
import datetime
import uuid

DB_PATH = "ai_sentry.db"

# USB device classes
USB_CLASS_VIDEO = '0e'      # Cameras
USB_CLASS_AUDIO = '01'      # Audio devices (mics)
USB_CLASS_HID = '03'        # Human Interface (keyboards, mice)
USB_CLASS_MASS_STORAGE = '08'  # USB drives
USB_CLASS_HUB = '09'        # USB hubs

def init_usb_log():
    """Create USB event log table"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS usb_events (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            device_name TEXT,
            device_class TEXT,
            vendor TEXT,
            model TEXT,
            action TEXT,
            blocked BOOLEAN,
            reason TEXT
        )
    """)
    conn.commit()
    conn.close()

def log_usb_event(device_name, device_class, vendor, model, action, blocked, reason):
    """Log USB event to database"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO usb_events (id, timestamp, device_name, device_class, vendor, model, action, blocked, reason)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), str(datetime.datetime.now()), device_name, device_class, vendor, model, action, blocked, reason))
    conn.commit()
    conn.close()

def is_allowed_device(device):
    """Check if device is a camera or microphone (allowed)"""
    device_class = device.get('ID_USB_CLASS', '')
    device_desc = str(device).lower()
    model = device.get('ID_MODEL', '').lower()
    
    # Allow cameras
    if device_class == USB_CLASS_VIDEO:
        return True
    if 'video' in device_desc or 'camera' in model or 'webcam' in model:
        return True
    
    # Allow audio devices (microphones)
    if device_class == USB_CLASS_AUDIO:
        return True
    if 'audio' in device_desc or 'mic' in model or 'microphone' in model:
        return True
    
    return False

def is_keyboard_or_mouse(device):
    """Check if device is a keyboard or mouse"""
    device_class = device.get('ID_USB_CLASS', '')
    device_desc = str(device).lower()
    model = device.get('ID_MODEL', '').lower()
    
    if device_class == USB_CLASS_HID:
        return True
    if 'keyboard' in model or 'mouse' in model or 'keybd' in model:
        return True
    if 'hid' in device_desc and ('input' in device_desc or 'keyboard' in device_desc):
        return True
    
    return False

def block_device(device):
    """Block a USB device by unbinding its driver"""
    try:
        # Get device path
        device_path = device.get('DEVPATH', '')
        if not device_path:
            return False
        
        # Try to unbind the driver
        sys_path = f"/sys{device_path}"
        driver_path = f"{sys_path}/driver"
        
        if os.path.exists(driver_path):
            # Unbind device from driver
            subprocess.run(['sudo', 'sh', '-c', f'echo "{device_path.split("/")[-1]}" > {driver_path}/unbind'], 
                         capture_output=True, timeout=5)
            return True
        
        return False
    except Exception as e:
        print(f"⚠️ Failed to block device: {e}")
        return False

def queue_security_message(device_type, vendor, model):
    """Queue an annoyed security message to the AI"""
    from main import msg_queue, socketio
    import uuid
    
    device_name = f"{vendor} {model}".strip()
    
    if device_type == "keyboard_mouse":
        message = f"Hey, what are you trying to pull? I detected a {device_name} being plugged in. Just so you know, I've blocked all USB ports except for cameras and microphones. What's the deal?"
    else:
        message = f"Excuse me, I detected an unauthorized USB device ({device_name}). I've blocked it since only cameras and microphones are allowed. What were you trying to do?"
    
    log_id = str(uuid.uuid4())
    conn = sqlite3.connect(DB_PATH)
    conn.cursor().execute("INSERT INTO logs VALUES (?,?,?,?,?)", 
                         (log_id, str(datetime.datetime.now()), "SECURITY_ALERT", "assistant", message))
    conn.commit()
    conn.close()
    
    socketio.emit("new_message", {"id": log_id, "role": "assistant", "message": message})
    
    # Speak the message
    try:
        subprocess.run(["amixer", "set", "PCM", "100%"], capture_output=True)
        subprocess.run(["espeak", "-v", "en", "-s", "140", message], capture_output=True)
    except Exception as e:
        print(f"TTS Error: {e}")

def on_usb_event(action, device):
    """Handle USB device events"""
    if device.get('DEVTYPE') != 'usb_device':
        return
    
    vendor = device.get('ID_VENDOR', 'Unknown')
    model = device.get('ID_MODEL', 'Unknown')
    device_class = device.get('ID_USB_CLASS', 'unknown')
    device_name = f"{vendor} {model}"
    
    if action == 'add':
        print(f"🔌 USB device detected: {device_name} (class: {device_class})")
        
        if is_allowed_device(device):
            print(f"✅ Allowed device: {device_name}")
            log_usb_event(device_name, device_class, vendor, model, 'add', False, 'Allowed device (camera/mic)')
        else:
            print(f"🚫 Blocking unauthorized device: {device_name}")
            blocked = block_device(device)
            
            if is_keyboard_or_mouse(device):
                log_usb_event(device_name, device_class, vendor, model, 'add', True, 'Keyboard/mouse blocked')
                queue_security_message("keyboard_mouse", vendor, model)
            else:
                log_usb_event(device_name, device_class, vendor, model, 'add', True, 'Unauthorized device blocked')
                queue_security_message("other", vendor, model)
    
    elif action == 'remove':
        print(f"❌ USB device removed: {device_name}")
        log_usb_event(device_name, device_class, vendor, model, 'remove', False, 'Device removed')

def usb_monitor_loop(stop_event):
    """Main USB monitoring loop"""
    print("🔒 USB Security Monitor started - blocking unauthorized devices")
    
    init_usb_log()
    
    context = pyudev.Context()
    monitor = pyudev.Monitor.from_netlink(context)
    monitor.filter_by(subsystem='usb')
    
    for action, device in monitor:
        if stop_event.is_set():
            break
        try:
            on_usb_event(action, device)
        except Exception as e:
            print(f"USB monitor error: {e}")

if __name__ == "__main__":
    import threading
    stop_event = threading.Event()
    usb_monitor_loop(stop_event)
