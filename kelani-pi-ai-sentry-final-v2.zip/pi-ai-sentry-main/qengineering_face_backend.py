#!/usr/bin/env python3
"""Adapter boundary for Qengineering's Raspberry Pi face-recognition backend.

Qengineering's published application is a C++ RetinaFace/MTCNN + ArcFace +
optional anti-spoofing program. This adapter keeps our Python identity database
independent of its on-disk face database. A machine-readable bridge can be
configured with QENGINEERING_FACE_BRIDGE; it must accept an image path and
return JSON: {"matched": true/false, "external_id": "...", "confidence": 0..1}.
"""
import json
import os
import subprocess
from typing import Any, Dict, Optional

BRIDGE = os.environ.get("QENGINEERING_FACE_BRIDGE", "")


def available() -> bool:
    return bool(BRIDGE and os.path.exists(BRIDGE) and os.access(BRIDGE, os.X_OK))


def recognize(image_path: str) -> Optional[Dict[str, Any]]:
    if not available():
        return None
    try:
        proc = subprocess.run([BRIDGE, image_path], capture_output=True, text=True, timeout=8, check=False, cwd=os.path.dirname(BRIDGE))
        if proc.returncode != 0:
            return None
        data = json.loads(proc.stdout.strip().splitlines()[-1])
        if not isinstance(data, dict):
            return None
        return data
    except Exception:
        return None
