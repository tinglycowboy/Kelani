#!/usr/bin/env python3
"""Safe single-model Ollama manager for Raspberry Pi."""
import threading, time, requests, subprocess

OLLAMA_BASE = "http://localhost:11434"
OLLAMA_API = f"{OLLAMA_BASE}/api/generate"
OLLAMA_PS = f"{OLLAMA_BASE}/api/ps"
LIGHT_MODEL = "qwen3:0.6b"
MEDIUM_MODEL = "qwen2.5:3b"
EXTREME_MODEL = "qwen2.5:7b"
_current_model = LIGHT_MODEL
MODEL_LOCK = threading.RLock()

def get_current_model(): return _current_model

def _loaded_models():
    try:
        r=requests.get(OLLAMA_PS, timeout=5); r.raise_for_status()
        return [m.get("name") or m.get("model") for m in r.json().get("models", [])]
    except Exception as e:
        print(f"Ollama status error: {e}"); return []

def _unload(model):
    try:
        requests.post(OLLAMA_API, json={"model":model,"prompt":"","stream":False,"keep_alive":0}, timeout=15)
    except Exception as e: print(f"Unload warning for {model}: {e}")

def unload_all_except(target=None):
    for model in _loaded_models():
        if target is None or model != target:
            _unload(model)

def _ram_percent():
 try:
  a=subprocess.check_output(["free","-m"],text=True).splitlines()[1].split(); return int(a[2])*100/int(a[1])
 except: return 0.0
def _safe_to_load(target):
 from config import RAM_MODEL_LOAD_LIMIT_PERCENT,RAM_HARD_LIMIT_PERCENT
 p=_ram_percent(); return p<RAM_HARD_LIMIT_PERCENT and not (target==EXTREME_MODEL and p>=RAM_MODEL_LOAD_LIMIT_PERCENT)

def switch_model(target_model):
    global _current_model
    with MODEL_LOCK:
        if not _safe_to_load(target_model):
            print(f"⚠️ RAM preflight blocked {target_model} at {_ram_percent():.1f}%")
            return False
        if _current_model == target_model and target_model in _loaded_models():
            unload_all_except(target_model); return True
        print(f"🔄 Switching AI model: {_current_model} -> {target_model}")
        # Never intentionally keep two models resident.
        for model in _loaded_models():
            if model != target_model: _unload(model)
        try:
            r=requests.post(OLLAMA_API, json={"model":target_model,"prompt":"","stream":False,"keep_alive":"10m"}, timeout=180)
            if r.status_code != 200:
                print(f"❌ Failed to load {target_model}: {r.text[:500]}"); return False
            _current_model=target_model
            # Give Ollama a moment to update /api/ps, then clean any unexpected extra model.
            time.sleep(0.25); unload_all_except(target_model)
            return True
        except Exception as e:
            print(f"❌ Error loading {target_model}: {e}"); return False

def generate(prompt, system=None, num_predict=256, temperature=0.7, timeout=120, model=None, keep_alive="10m"):
    """Generate while holding the global model lock; guarantees one active model at a time."""
    global _current_model
    target=model or _current_model
    with MODEL_LOCK:
        if not switch_model(target): return ""
        payload={"model":target,"prompt":prompt,"stream":False,"keep_alive":keep_alive,"options":{"temperature":temperature,"num_predict":num_predict}}
        if system: payload["system"]=system
        try:
            r=requests.post(OLLAMA_API,json=payload,timeout=timeout); r.raise_for_status()
            unload_all_except(target)
            return r.json().get("response","").strip()
        except Exception as e:
            print(f"Ollama generation error: {e}"); return ""

def evaluate_complexity(text, nlp_result=None):
    text_lower=text.lower(); word_count=len(text.split())
    extreme_keywords=["deeply analyze","comprehensive analysis","write a full application","complex philosophical","multi-step reasoning","detailed architectural design","extreme detail","write a complete script","advanced debugging","step-by-step guide"]
    if any(k in text_lower for k in extreme_keywords):
        k=next(k for k in extreme_keywords if k in text_lower); return "extreme",f"Extreme complexity keyword: '{k}'",60
    if word_count>150: return "extreme",f"Very long query ({word_count} words)",60
    medium_keywords=["analyze","compare","contrast","explain in detail","write a story","write code","debug","summarize this","hypothesis","translate this entire","refactor","brainstorm","what do you think about"]
    if any(k in text_lower for k in medium_keywords):
        k=next(k for k in medium_keywords if k in text_lower); return "medium",f"Complex keyword: '{k}'",20
    if word_count>50: return "medium",f"Moderately long query ({word_count} words)",20
    return "light","Standard query",2
