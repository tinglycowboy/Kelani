#!/usr/bin/env python3
"""Follow-up Engine: Determines when to ask follow-up questions and generates them"""
import sqlite3
import datetime
import random
import re

DB_PATH = "ai_sentry.db"

def init_followup_db():
    """Create follow-up tracking tables"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS followup_questions (
            id TEXT PRIMARY KEY,
            person_id TEXT,
            timestamp TEXT,
            original_message TEXT,
            ai_response TEXT,
            followup_question TEXT,
            asked BOOLEAN DEFAULT 0,
            asked_timestamp TEXT
        )
    """)
    
    c.execute("""
        CREATE TABLE IF NOT EXISTS followup_timing (
            person_id TEXT PRIMARY KEY,
            last_followup_timestamp TEXT,
            followup_count INTEGER DEFAULT 0
        )
    """)
    
    conn.commit()
    conn.close()

def should_ask_followup(person_id, original_message, ai_response, conversation_history):
    """
    Determine if AI should ask a follow-up question
    
    Returns: (should_ask: bool, reason: str)
    """
    if not person_id:
        return False, "No person identified"
    
    # Check timing - don't ask too frequently
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT last_followup_timestamp, followup_count FROM followup_timing WHERE person_id = ?", (person_id,))
    result = c.fetchone()
    
    if result:
        last_timestamp, count = result
        try:
            last_time = datetime.datetime.strptime(last_timestamp.split('.')[0], "%Y-%m-%d %H:%M:%S")
            minutes_since = (datetime.datetime.now() - last_time).total_seconds() / 60
            
            # Don't ask more than once every 5 minutes
            if minutes_since < 5:
                conn.close()
                return False, f"Too soon ({minutes_since:.1f} min since last follow-up)"
            
            # Don't ask more than 3 follow-ups in a row
            if count >= 3:
                conn.close()
                return False, "Too many follow-ups already"
        except:
            pass
    
    conn.close()
    
    # Check if response was incomplete or ambiguous
    response_lower = ai_response.lower()
    
    # Signs of incomplete response
    incomplete_indicators = [
        "i'm not sure", "i don't know", "maybe", "possibly", "i can't recall",
        "sorry, i can't", "i don't have", "unclear", "ambiguous"
    ]
    
    if any(indicator in response_lower for indicator in incomplete_indicators):
        return True, "Response was incomplete or uncertain"
    
    # Check if original message was vague
    original_lower = original_message.lower()
    vague_indicators = ["something", "thing", "stuff", "whatever", "you know"]
    
    if any(indicator in original_lower for indicator in vague_indicators):
        return True, "Original message was vague"
    
    # Check conversation length - longer conversations benefit from follow-ups
    if len(conversation_history) >= 3:
        # Check if conversation is still active (recent messages)
        if conversation_history:
            last_msg_time = conversation_history[-1].get('timestamp', '')
            if last_msg_time:
                try:
                    last_time = datetime.datetime.strptime(last_msg_time.split('.')[0], "%Y-%m-%d %H:%M:%S")
                    minutes_since = (datetime.datetime.now() - last_time).total_seconds() / 60
                    
                    # If conversation is still recent (< 2 min), follow-up is appropriate
                    if minutes_since < 2:
                        return True, "Active conversation"
                except:
                    pass
    
    # Check psychological profile
    from person_profile import get_person_profile
    profile = get_person_profile(person_id)
    
    if profile:
        psych_traits = profile.get('psychological_traits', [])
        
        # Extroverts and affiliation-motivated people are more open to follow-ups
        if 'extrovert' in psych_traits or 'affiliation_motivated' in psych_traits:
            return True, "Person is open to conversation"
        
        # Introverts and avoidant types might not want follow-ups
        if 'introvert' in psych_traits or 'avoidant_attachment' in psych_traits:
            return False, "Person prefers less interaction"
    
    # Default: 30% chance to ask follow-up for general engagement
    if random.random() < 0.3:
        return True, "Random engagement"
    
    return False, "No follow-up needed"

def generate_followup_question(person_id, original_message, ai_response, conversation_history):
    """Generate a relevant follow-up question"""
    
    # Get person's name and interests
    from person_profile import get_person_profile
    profile = get_person_profile(person_id)
    name = profile.get('name', 'there') if profile else 'there'
    interests = profile.get('interests', []) if profile else []
    
    # Analyze the conversation context
    original_lower = original_message.lower()
    response_lower = ai_response.lower()
    
    # Different types of follow-ups based on context
    
    # 1. If AI gave incomplete answer, ask for clarification
    if any(phrase in response_lower for phrase in ["i'm not sure", "i don't know", "maybe"]):
        clarifications = [
            f"Can you tell me more about what you meant, {name}?",
            f"I want to make sure I understand. Could you elaborate on that?",
            f"What specifically were you looking for, {name}?"
        ]
        return random.choice(clarifications)
    
    # 2. If conversation is about a specific topic, ask related questions
    topic_keywords = {
        "work": ["job", "work", "project", "boss", "colleague"],
        "school": ["class", "homework", "exam", "teacher", "study"],
        "hobby": ["hobby", "fun", "enjoy", "like to"],
        "family": ["family", "mom", "dad", "sister", "brother"],
        "travel": ["travel", "trip", "vacation", "visit"]
    }
    
    for topic, keywords in topic_keywords.items():
        if any(kw in original_lower for kw in keywords):
            topic_questions = {
                "work": [
                    f"How's that project going, {name}?",
                    f"Are you enjoying your work lately?",
                    f"What's the most interesting part of your job?"
                ],
                "school": [
                    f"How are your classes going, {name}?",
                    f"What's your favorite subject right now?",
                    f"Any big exams coming up?"
                ],
                "hobby": [
                    f"How often do you get to do that, {name}?",
                    f"What got you interested in that?",
                    f"Have you tried anything new with that lately?"
                ],
                "family": [
                    f"How's your family doing, {name}?",
                    f"Do you see them often?",
                    f"Any fun family plans coming up?"
                ],
                "travel": [
                    f"Where are you planning to go, {name}?",
                    f"Have you been there before?",
                    f"What are you most excited about?"
                ]
            }
            return random.choice(topic_questions.get(topic, [f"Tell me more about that, {name}?"]))
    
    # 3. If person mentioned interests, ask about them
    if interests and random.random() < 0.5:
        interest = random.choice(interests)
        interest_questions = [
            f"By the way {name}, how's your {interest} going?",
            f"Have you done anything with {interest} lately?",
            f"What's new with {interest}?"
        ]
        return random.choice(interest_questions)
    
    # 4. General engagement questions
    general_questions = [
        f"How's your day going, {name}?",
        f"Anything interesting happening lately?",
        f"What have you been up to, {name}?",
        f"Is there anything else on your mind?",
        f"Want to talk about anything specific?"
    ]
    
    return random.choice(general_questions)

def log_followup_question(person_id, original_message, ai_response, followup_question):
    """Log a follow-up question to database"""
    import uuid
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        INSERT INTO followup_questions (id, person_id, timestamp, original_message, ai_response, followup_question, asked)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), person_id, str(datetime.datetime.now()), original_message, ai_response, followup_question, False))
    
    conn.commit()
    conn.close()

def mark_followup_asked(followup_id):
    """Mark a follow-up question as asked"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        UPDATE followup_questions 
        SET asked = 1, asked_timestamp = ?
        WHERE id = ?
    """, (str(datetime.datetime.now()), followup_id))
    
    conn.commit()
    conn.close()

def update_followup_timing(person_id):
    """Update timing tracking for follow-ups"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Check if entry exists
    c.execute("SELECT person_id FROM followup_timing WHERE person_id = ?", (person_id,))
    if c.fetchone():
        c.execute("""
            UPDATE followup_timing 
            SET last_followup_timestamp = ?, followup_count = followup_count + 1
            WHERE person_id = ?
        """, (str(datetime.datetime.now()), person_id))
    else:
        c.execute("""
            INSERT INTO followup_timing (person_id, last_followup_timestamp, followup_count)
            VALUES (?, ?, 1)
        """, (person_id, str(datetime.datetime.now())))
    
    conn.commit()
    conn.close()

def get_pending_followups(person_id, limit=1):
    """Get pending follow-up questions for a person"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        SELECT id, followup_question
        FROM followup_questions
        WHERE person_id = ? AND asked = 0
        ORDER BY timestamp DESC
        LIMIT ?
    """, (person_id, limit))
    
    results = c.fetchall()
    conn.close()
    
    return [{"id": r[0], "question": r[1]} for r in results]

def reset_followup_count(person_id):
    """Reset follow-up count after a period of no follow-ups"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        UPDATE followup_timing 
        SET followup_count = 0
        WHERE person_id = ?
    """, (person_id,))
    
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_followup_db()
    print("Follow-up engine initialized!")
