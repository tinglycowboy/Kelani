#!/usr/bin/env python3
import subprocess
import os
import sqlite3
import datetime

DB_PATH = "ai_sentry.db"

def init_system_monitor_db():
    """Create system awareness table"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS system_snapshots (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            cpu_temp REAL,
            ram_used_mb INTEGER,
            ram_total_mb INTEGER,
            ram_percent REAL,
            running_processes TEXT
        )
    """)
    conn.commit()
    conn.close()

def get_cpu_temp():
    """Get CPU temperature"""
    try:
        result = subprocess.run(['vcgencmd', 'measure_temp'], capture_output=True, text=True)
        temp_str = result.stdout.strip()
        temp = float(temp_str.replace('temp=', '').replace("'C", ''))
        return temp
    except:
        return 0.0

def get_ram_usage():
    """Get RAM usage in MB"""
    try:
        result = subprocess.run(['free', '-m'], capture_output=True, text=True)
        lines = result.stdout.strip().split('\n')
        mem_line = lines[1].split()
        
        total = int(mem_line[1])
        used = int(mem_line[2])
        percent = (used / total) * 100
        
        return used, total, percent
    except:
        return 0, 0, 0.0

def get_running_processes():
    """Get list of running processes"""
    try:
        result = subprocess.run(['ps', 'aux', '--sort=-%mem'], capture_output=True, text=True)
        lines = result.stdout.strip().split('\n')[:10]  # Top 10 by memory
        return '\n'.join(lines)
    except:
        return "Unable to retrieve process list"

def take_system_snapshot():
    """Take a snapshot of current system state"""
    import uuid
    
    temp = get_cpu_temp()
    ram_used, ram_total, ram_percent = get_ram_usage()
    processes = get_running_processes()
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute("""
        INSERT INTO system_snapshots (id, timestamp, cpu_temp, ram_used_mb, ram_total_mb, ram_percent, running_processes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), str(datetime.datetime.now()), temp, ram_used, ram_total, ram_percent, processes))
    
    conn.commit()
    conn.close()
    
    return {
        "temp": temp,
        "ram_used": ram_used,
        "ram_total": ram_total,
        "ram_percent": ram_percent,
        "processes": processes
    }

def get_system_status():
    """Get current system status for AI awareness"""
    temp = get_cpu_temp()
    ram_used, ram_total, ram_percent = get_ram_usage()
    
    status = f"CPU temperature: {temp:.1f}°C, RAM usage: {ram_used}MB / {ram_total}MB ({ram_percent:.1f}%)"
    
    if temp > 70:
        status += " | WARNING: CPU is running hot!"
    elif ram_percent > 80:
        status += " | WARNING: RAM usage is high!"
    
    return status

def get_system_health_description():
    """Get human-readable system health"""
    temp = get_cpu_temp()
    ram_used, ram_total, ram_percent = get_ram_usage()
    
    health = []
    
    if temp < 50:
        health.append("running cool")
    elif temp < 70:
        health.append("running warm")
    else:
        health.append("running hot")
    
    if ram_percent < 50:
        health.append("plenty of memory available")
    elif ram_percent < 80:
        health.append("memory usage is moderate")
    else:
        health.append("memory is getting full")
    
    return " and ".join(health)

if __name__ == "__main__":
    init_system_monitor_db()
    print("System monitor initialized!")
    
    # Test
    status = get_system_status()
    print(status)

