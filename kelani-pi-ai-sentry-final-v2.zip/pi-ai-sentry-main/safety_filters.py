#!/usr/bin/env python3
"""Safety filters: PII detection/redaction and content moderation"""
import re
import sqlite3
import datetime

DB_PATH = "ai_sentry.db"

# PII patterns
PII_PATTERNS = {
    "ssn": {
        "pattern": r"\b\d{3}-\d{2}-\d{4}\b",
        "replacement": "[SSN REDACTED]",
        "severity": "critical"
    },
    "credit_card": {
        "pattern": r"\b(?:\d{4}[-\s]?){3}\d{4}\b",
        "replacement": "[CREDIT CARD REDACTED]",
        "severity": "critical"
    },
    "email": {
        "pattern": r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b",
        "replacement": "[EMAIL REDACTED]",
        "severity": "medium"
    },
    "phone": {
        "pattern": r"\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b",
        "replacement": "[PHONE REDACTED]",
        "severity": "medium"
    },
    "password": {
        "pattern": r"(password|passwd|pwd)\s*[:=]\s*\S+",
        "replacement": "[PASSWORD REDACTED]",
        "severity": "critical"
    },
    "api_key": {
        "pattern": r"(api[_-]?key|token|secret)\s*[:=]\s*['\"]?[a-zA-Z0-9]{20,}['\"]?",
        "replacement": "[API KEY REDACTED]",
        "severity": "critical"
    },
    "ip_address": {
        "pattern": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
        "replacement": "[IP REDACTED]",
        "severity": "low"
    },
    "address": {
        "pattern": r"\b\d+\s+[A-Z][a-z]+\s+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Way|Court|Ct|Place|Pl)\b",
        "replacement": "[ADDRESS REDACTED]",
        "severity": "medium"
    }
}

# Toxic content patterns (basic offline filter)
TOXIC_PATTERNS = {
    "hate_speech": [
        r"\b(kill all|death to|exterminate)\s+\w+s?\b",
        r"\b(you (all|people) (should|need to) die)\b"
    ],
    "threats": [
        r"\b(i('ll| will) (kill|hurt|harm) you)\b",
        r"\b(i('m| am) (going to|gonna) (kill|hurt) you)\b"
    ],
    "self_harm": [
        r"\b(i want to (die|kill myself|end it all))\b",
        r"\b(i('m| am) (going to|gonna) (kill|hurt) myself)\b"
    ],
    "harassment": [
        r"\b(you('re| are) (pathetic|worthless|useless|stupid))\b"
    ]
}

def init_safety_db():
    """Create safety log table"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS safety_logs (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            person_id TEXT,
            original_text TEXT,
            redacted_text TEXT,
            pii_detected TEXT,
            toxicity_detected TEXT,
            action_taken TEXT
        )
    """)
    conn.commit()
    conn.close()

def detect_pii(text):
    """Detect PII in text, return list of findings"""
    findings = []
    
    for pii_type, config in PII_PATTERNS.items():
        matches = re.findall(config["pattern"], text, re.IGNORECASE)
        if matches:
            findings.append({
                "type": pii_type,
                "count": len(matches),
                "severity": config["severity"],
                "matches": matches[:3]  # Limit for logging
            })
    
    return findings

def redact_pii(text):
    """Redact PII from text"""
    redacted = text
    redacted_types = []
    
    for pii_type, config in PII_PATTERNS.items():
        if re.search(config["pattern"], redacted, re.IGNORECASE):
            redacted = re.sub(config["pattern"], config["replacement"], redacted, flags=re.IGNORECASE)
            redacted_types.append(pii_type)
    
    return redacted, redacted_types

def detect_toxicity(text):
    """Detect toxic content"""
    text_lower = text.lower()
    findings = []
    
    for category, patterns in TOXIC_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, text_lower):
                findings.append({
                    "category": category,
                    "pattern": pattern,
                    "severity": "high"
                })
    
    return findings

def process_safety(text, person_id=None):
    """Full safety processing"""
    import uuid
    
    # Detect PII
    pii_findings = detect_pii(text)
    
    # Detect toxicity
    toxicity_findings = detect_toxicity(text)
    
    # Redact PII
    redacted_text, redacted_types = redact_pii(text)
    
    # Determine action
    action = "allow"
    if toxicity_findings:
        action = "block"
    elif pii_findings:
        critical_pii = [f for f in pii_findings if f["severity"] == "critical"]
        if critical_pii:
            action = "redact_and_warn"
        else:
            action = "redact"
    
    # Log to database
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT INTO safety_logs (id, timestamp, person_id, original_text, redacted_text, pii_detected, toxicity_detected, action_taken)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        str(uuid.uuid4()),
        str(datetime.datetime.now()),
        person_id,
        text[:500],
        redacted_text[:500],
        str(pii_findings)[:500],
        str(toxicity_findings)[:500],
        action
    ))
    conn.commit()
    conn.close()
    
    return {
        "original": text,
        "redacted": redacted_text,
        "pii": pii_findings,
        "toxicity": toxicity_findings,
        "action": action,
        "safe_to_process": action != "block"
    }

def get_safety_warning(result):
    """Generate warning message for user"""
    if result["action"] == "block":
        return "I can't process that message due to safety concerns."
    elif result["action"] == "redact_and_warn":
        return "I've redacted sensitive information from your message. Please avoid sharing passwords, SSNs, or API keys."
    elif result["action"] == "redact":
        return "I've redacted some personal information from your message for your safety."
    return None

if __name__ == "__main__":
    init_safety_db()
    print("Safety filters initialized!")
    
    # Test
    test_texts = [
        "My SSN is 123-45-6789",
        "Email me at test@example.com",
        "My password is: supersecret123",
        "I will kill you",
        "Normal message about the weather"
    ]
    
    for text in test_texts:
        result = process_safety(text)
        print(f"\nOriginal: {text}")
        print(f"Action: {result['action']}")
        print(f"Redacted: {result['redacted']}")
        print(f"PII: {result['pii']}")
        print(f"Toxicity: {result['toxicity']}")
