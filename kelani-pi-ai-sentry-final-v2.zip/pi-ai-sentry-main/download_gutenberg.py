#!/usr/bin/env python3
"""Download Project Gutenberg collection as .txt files"""
import os
import subprocess
import time
import sqlite3
import datetime

DB_PATH = "ai_sentry.db"
from config import BOOKS_DIR
LIBRARY_PATH = BOOKS_DIR
BATCH_SIZE = int(os.environ.get("AI_SENTRY_BOOK_BATCH", "5"))
MAX_BOOKS = int(os.environ.get("AI_SENTRY_GUTENBERG_MAX_BOOKS", "500"))
GUTENBERG_MIRROR = "https://www.gutenberg.org/cache/epub"

def init_download_tracker():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS gutenberg_catalog (
        book_id INTEGER PRIMARY KEY,
        title TEXT,
        downloaded BOOLEAN DEFAULT 0,
        attempts INTEGER DEFAULT 0,
        skipped BOOLEAN DEFAULT 0
    )""")
    for col, typ in (("attempts", "INTEGER DEFAULT 0"), ("skipped", "BOOLEAN DEFAULT 0")):
        try: c.execute(f"ALTER TABLE gutenberg_catalog ADD COLUMN {col} {typ}")
        except sqlite3.OperationalError: pass
    conn.commit()
    conn.close()

def download_catalog():
    catalog_path = os.path.join(LIBRARY_PATH, "pg_catalog.csv")
    if os.path.exists(catalog_path) and os.path.getsize(catalog_path) > 1000:
        return catalog_path
    
    print("📚 Downloading Project Gutenberg catalog (this may take a minute)...")
    url = "https://www.gutenberg.org/cache/epub/feeds/pg_catalog.csv"
    try:
        subprocess.run(["wget", "-q", "-O", catalog_path, url], timeout=120)
        return catalog_path
    except Exception as e:
        print(f"⚠️ Catalog download failed: {e}")
        return None

def parse_catalog(catalog_path):
    books = []
    try:
        with open(catalog_path, 'r', encoding='utf-8', errors='ignore') as f:
            header = f.readline()
            for line in f:
                parts = line.strip().split('","')
                if len(parts) >= 3:
                    book_id = parts[0].strip('"')
                    title = parts[1].strip('"')
                    if book_id.isdigit() and int(book_id) > 0:
                        # Only grab books with actual titles
                        if len(title) > 5 and title != "Title":
                            books.append((int(book_id), title))
    except Exception as e:
        print(f"Error parsing catalog: {e}")
    return books

def download_book_text(book_id, title):
    safe_title = "".join(c for c in title if c.isalnum() or c in " _-")[:60]
    filename = f"{book_id}_{safe_title}.txt"
    filepath = os.path.join(LIBRARY_PATH, filename)
    
    # Skip if already downloaded and valid size
    if os.path.exists(filepath) and os.path.getsize(filepath) > 500:
        return filepath
    
    url = f"{GUTENBERG_MIRROR}/{book_id}/pg{book_id}.txt"
    
    try:
        result = subprocess.run(
            ["wget", "-q", "-O", filepath, url, "--timeout=30", "--tries=2"],
            capture_output=True, timeout=60
        )
        
        if result.returncode == 0 and os.path.exists(filepath) and os.path.getsize(filepath) > 500:
            return filepath
        
        # Fallback URL pattern
        url2 = f"{GUTENBERG_MIRROR}/{book_id}/{book_id}-0.txt"
        result2 = subprocess.run(
            ["wget", "-q", "-O", filepath, url2, "--timeout=30", "--tries=2"],
            capture_output=True, timeout=60
        )
        if result2.returncode == 0 and os.path.exists(filepath) and os.path.getsize(filepath) > 500:
            return filepath
            
        if os.path.exists(filepath):
            os.remove(filepath)
        return None
    except:
        if os.path.exists(filepath):
            os.remove(filepath)
        return None

def _successful_count(conn):
    return int(conn.execute("SELECT COUNT(*) FROM gutenberg_catalog WHERE downloaded=1").fetchone()[0])

def acquisition_complete():
    """The Gutenberg stream is a bounded configured collection, not the whole archive."""
    init_download_tracker()
    conn = sqlite3.connect(DB_PATH)
    try:
        return _successful_count(conn) >= MAX_BOOKS
    finally:
        conn.close()

def download_batch(batch_size=BATCH_SIZE):
    os.makedirs(LIBRARY_PATH, exist_ok=True)
    init_download_tracker()
    if acquisition_complete():
        return 0
    catalog_path = download_catalog()
    if not catalog_path:
        return 0
    books = parse_catalog(catalog_path)
    conn = sqlite3.connect(DB_PATH)
    try:
        downloaded_ids = {r[0] for r in conn.execute("SELECT book_id FROM gutenberg_catalog WHERE downloaded=1")}
        skipped_ids = {r[0] for r in conn.execute("SELECT book_id FROM gutenberg_catalog WHERE skipped=1")}
        remaining = max(0, MAX_BOOKS - _successful_count(conn))
    finally:
        conn.close()
    pending_books = [(bid, title) for bid, title in books if bid not in downloaded_ids and bid not in skipped_ids]
    batch = pending_books[:min(batch_size, remaining)]
    if not batch:
        return 0
    print(f"📥 Gutenberg: downloading {len(batch)} books toward configured target {MAX_BOOKS}...")
    success_count = 0
    for book_id, title in batch:
        if os.path.exists(os.path.join(os.path.expanduser(os.environ.get("AI_SENTRY_HOME", "~/ai_sentry")), ".ai_busy")):
            break
        filepath = download_book_text(book_id, title)
        conn = sqlite3.connect(DB_PATH)
        try:
            if filepath:
                conn.execute("""INSERT INTO gutenberg_catalog(book_id,title,downloaded,attempts,skipped) VALUES(?,?,1,0,0)
                                ON CONFLICT(book_id) DO UPDATE SET title=excluded.title,downloaded=1,skipped=0""", (book_id, title))
                from library_manager import add_book_to_library
                add_book_to_library(str(book_id), title, filepath)
                success_count += 1
            else:
                row = conn.execute("SELECT attempts FROM gutenberg_catalog WHERE book_id=?", (book_id,)).fetchone()
                attempts = (int(row[0]) if row else 0) + 1
                skipped = 1 if attempts >= 3 else 0
                conn.execute("""INSERT INTO gutenberg_catalog(book_id,title,downloaded,attempts,skipped) VALUES(?,?,0,?,?)
                                ON CONFLICT(book_id) DO UPDATE SET attempts=?,skipped=?""", (book_id,title,attempts,skipped,attempts,skipped))
            conn.commit()
        finally:
            conn.close()
        time.sleep(0.5)
    return success_count

def download_all_blocking():
    print(f"🚀 Starting bounded Project Gutenberg acquisition: {MAX_BOOKS} books.")
    init_download_tracker()
    while not acquisition_complete():
        count = download_batch(batch_size=BATCH_SIZE)
        if count == 0:
            time.sleep(5)
        else:
            print(f"   Progress: {count} new books this batch.")
    print(f"✅ Configured Gutenberg target reached: {MAX_BOOKS} books.")

if __name__ == "__main__":
    download_all_blocking()


def download_all_background(stop_event, batch_size=20):
    """Download a small background batch repeatedly; never blocks startup."""
    init_download_tracker()
    while not stop_event.is_set():
        try:
            count=download_batch(batch_size=batch_size)
            if count == 0:
                return
        except Exception as e:
            print(f"Gutenberg background error: {e}")
            return
        for _ in range(60):
            if stop_event.is_set(): return
            time.sleep(1)
