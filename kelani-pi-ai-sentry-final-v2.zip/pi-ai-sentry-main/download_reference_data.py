#!/usr/bin/env python3
"""Raw reference-library acquisition: public-domain/free lexical and religious sources."""
import os, subprocess, zipfile, tarfile, sqlite3, shutil
from config import OTHER_DIR, BIBLE_DIR, DB_PATH

WORDNET_URL="https://wordnetcode.princeton.edu/3.0/WordNet-3.0.tar.gz"
BIBLE_ZIP_URL="https://github.com/nigelmsipa/public-domain-bibles/archive/refs/heads/master.zip"

def _download(url,dest):
    os.makedirs(os.path.dirname(dest),exist_ok=True)
    return subprocess.run(["wget","-c","--timeout=120","--tries=5","-O",dest,url],check=False).returncode==0

def download_wordnet():
    marker=os.path.join(OTHER_DIR,"WORDNET_COMPLETE")
    if os.path.exists(marker): return True
    archive=os.path.join(OTHER_DIR,"WordNet-3.0.tar.gz")
    if not _download(WORDNET_URL,archive): return False
    dest=os.path.join(OTHER_DIR,"wordnet")
    os.makedirs(dest,exist_ok=True)
    try:
        with tarfile.open(archive,"r:gz") as tf: tf.extractall(dest)
        os.remove(archive)
        open(marker,"w").write("WordNet 3.0 acquisition complete\n")
        return True
    except Exception as e:
        print("WordNet extraction:",e); return False

def download_bibles():
    marker=os.path.join(BIBLE_DIR,"DOWNLOAD_COMPLETE")
    if os.path.exists(marker): return True
    archive=os.path.join(BIBLE_DIR,"public-domain-bibles.zip")
    if not _download(BIBLE_ZIP_URL,archive): return False
    dest=os.path.join(BIBLE_DIR,"public-domain-bibles")
    os.makedirs(dest,exist_ok=True)
    try:
        with zipfile.ZipFile(archive) as z: z.extractall(dest)
        os.remove(archive)
        open(marker,"w").write("Public-domain Bible acquisition complete\n")
        return True
    except Exception as e:
        print("Bible extraction:",e); return False

def download_other():
    return download_wordnet()
