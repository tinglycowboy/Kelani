# Kelani Adaptive Reasoning

Kelani owns reasoning tasks; Qwen performs individual checkpointed operations.

## Flow

1. Every new AI task starts with `qwen3:0.6b`.
2. If the result is incomplete, unavailable, or explicitly requests research, Kelani can pause, search local databases/raw libraries, and resume.
3. If the light attempt cannot complete the task, Kelani tries `qwen2.5:3b`, then `qwen2.5:7b`. Only one model is resident.
4. If the largest model still cannot reliably complete the task, Kelani recursively decomposes it into smaller tasks. Every child task returns through the same filter/router/model-selection process.
5. Completed child results become parent context and are synthesized into the final answer.
6. If the available local sources and all supported reasoning paths remain insufficient, the final response is `I honestly don't know based on the information available to me.` rather than an invented answer.

## Persistence and recovery

`reasoning_tasks`, `reasoning_events`, and `reasoning_adaptations` are stored in SQLite. Checkpoints survive normal process restarts. The RAM watchdog records a boot cycle before a RAM-emergency reboot. A task is retried after the first two boot cycles; after the third cycle its temporary reasoning checkpoint is discarded and the task is marked abandoned. Original source data and diagnostics remain intact.

## Adaptive learning

Kelani records task type, strategy, success/failure, and decomposition depth. Repeated successful strategies can influence future routing hints. This is workflow learning; it does not retrain Qwen weights.

## Local knowledge

The reasoning controller can request local research. The callback searches the Wikipedia index, the dictionary/thesaurus reference data, and indexed raw library chunks. Wikipedia results retain the exact local raw source path so a result can be traced back to the source file.
