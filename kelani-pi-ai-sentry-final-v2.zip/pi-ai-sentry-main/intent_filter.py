#!/usr/bin/env python3
import sqlite3
import datetime

DB_PATH = "ai_sentry.db"

def init_intent_db():
    """Create intent_decisions table if it doesn't exist"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS intent_decisions (
            id TEXT PRIMARY KEY,
            timestamp TEXT,
            visual_data TEXT,
            audio_data TEXT,
            should_respond BOOLEAN,
            reason TEXT
        )
    """)
    conn.commit()
    conn.close()

def get_recent_visual_audio(seconds=30):
    """Get recent visual and audio events within time window"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    cutoff = str(datetime.datetime.now() - datetime.timedelta(seconds=seconds))
    
    c.execute("""
        SELECT timestamp, objects_detected, frame_description
        FROM visual_events
        WHERE timestamp > ?
        ORDER BY timestamp DESC
        LIMIT 5
    """, (cutoff,))
    visuals = c.fetchall()
    
    c.execute("""
        SELECT timestamp, transcribed_text, confidence
        FROM audio_events
        WHERE timestamp > ? AND is_speech = 1
        ORDER BY timestamp DESC
        LIMIT 5
    """, (cutoff,))
    audio = c.fetchall()
    
    conn.close()
    
    return {
        "visuals": [{"timestamp": v[0], "objects": v[1], "description": v[2]} for v in visuals],
        "audio": [{"timestamp": a[0], "text": a[1], "confidence": a[2]} for a in audio]
    }

def analyze_intent(visual_data, audio_data):
    """
    Analyze combined visual+audio data to determine if AI should respond
    
    Returns: (should_respond: bool, reason: str)
    """
    # No audio = no one is talking
    if not audio_data or len(audio_data) == 0:
        return False, "No speech detected"
    
    # Get most recent audio
    latest_audio = audio_data[0]
    audio_text = latest_audio['text'].lower().strip()
    
    # Ignore very short or low confidence audio
    if len(audio_text) < 3 or latest_audio['confidence'] < 0.5:
        return False, "Audio too short or low confidence"
    
    # Check for wake words or direct address
    wake_words = ["hey ai", "hey sentry", "ai", "sentry", "computer", "hey computer"]
    for wake in wake_words:
        if wake in audio_text:
            return True, f"Wake word detected: '{wake}'"
    
    # Check if it's a question (ends with ?)
    if audio_text.endswith('?'):
        return True, "Question detected"
    
    # Check for question words
    question_words = ["what", "who", "where", "when", "why", "how", "can you", "could you", "do you", "are you"]
    for q in question_words:
        if audio_text.startswith(q):
            return True, f"Question word detected: '{q}'"
    
    # Check for commands
    command_words = ["tell me", "show me", "calculate", "what is", "who is", "search", "find"]
    for cmd in command_words:
        if cmd in audio_text:
            return True, f"Command detected: '{cmd}'"
    
    # Check visual data - is someone facing the camera?
    has_person = False
    for visual in visual_data:
        if "person" in visual['objects'] or "face" in visual['objects']:
            has_person = True
            break
    
    # If there's a person AND audio, more likely to be addressing AI
    if has_person and len(audio_text) > 10:
        # Check if it sounds like a statement to someone
        if any(word in audio_text for word in ["yeah", "okay", "sure", "alright", "thanks", "bye"]):
            return False, "Casual conversation detected (not to AI)"
        
        # Longer speech with person present = likely addressing AI
        return True, "Person detected with substantial speech"
    
    # Default: don't respond to ambient noise
    return False, "Ambient noise or conversation not directed at AI"

def log_intent_decision(visual_data, audio_data, should_respond, reason):
    """Log the intent decision to database"""
    import uuid
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    visual_str = str(visual_data)[:500]  # Truncate for storage
    audio_str = str(audio_data)[:500]
    
    c.execute("""
        INSERT INTO intent_decisions (id, timestamp, visual_data, audio_data, should_respond, reason)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (str(uuid.uuid4()), str(datetime.datetime.now()), visual_str, audio_str, should_respond, reason))
    
    conn.commit()
    conn.close()

def should_ai_respond():
    """Main function: analyze recent data and decide if AI should respond"""
    data = get_recent_visual_audio(seconds=10)
    
    should_respond, reason = analyze_intent(data['visuals'], data['audio'])
    
    log_intent_decision(data['visuals'], data['audio'], should_respond, reason)
    
    return should_respond, reason, data

if __name__ == "__main__":
    init_intent_db()
    print("Intent filter initialized!")
    
    # Test
    should, reason, data = should_ai_respond()
    print(f"Should respond: {should}")
    print(f"Reason: {reason}")
    print(f"Visual data: {len(data['visuals'])} events")
    print(f"Audio data: {len(data['audio'])} events")
